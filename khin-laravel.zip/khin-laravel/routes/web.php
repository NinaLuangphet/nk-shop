<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomerController;

Route::resource('customers', CustomerController::class);
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login.index');
});

Route::get('about',function(){
return view('about');
});



//ກໍລະນີທີ່ ໄຟສ ຢູ່ໃນສ່ວນຂອງ ໂຟເດີ ຂອງ view
Route::get('/users/{fname}/{lname}' , function($fname, $lname){
    echo "<h1>ຊື່ $fname</h1>";
    echo "<h1>ນາມສະກຸນ $lname</h1>";
});

//ກໍລະນີສ້າງໂຟເດີໃນ View ເພີື່ອແຍກສ່ວນຂອງໄຟສ ເອົາໄຟສທີ່ຕ້ອງການແຍກໄປໄວ້ໃນໂຟເດີ ທີ່ເຮົາສ້າງຂື້ນມາໃໝ່ 
Route::get('/ຊື່ໂຟເດີທີ່ເຮົາຈະເຂົ້າເຖິງ' , function(){
   return view('ຊື່ໂຟເດີ.ຊື່ໄຟສທີ່ຢູ່ໃນໂຟເດີ');
});




Route::get('/addmin', function(){
    return View('addmin.addmin');
});


Route::get('/khin', function(){
    return View('index');
});


Route::get('/register', function(){
return view('companies.index');
});

Route::get('/login', function(){
    return View('login.index');
});

Route::get('/index', function(){
    return View('index');
});


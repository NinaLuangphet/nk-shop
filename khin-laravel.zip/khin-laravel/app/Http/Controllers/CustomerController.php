<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;

class CustomerController extends Controller
{
    //Customer 
    public function index(){
        $data['customers']= Customer::orderBy('id','desc')->paginate(5);
        return View('customers.index',$data);


    }
    public function create(){
        return View('customers.create');
    }

    
}

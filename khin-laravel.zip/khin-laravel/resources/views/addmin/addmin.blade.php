<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>
<body>
<?php  
$user ="nakhin";
$arr = array("Home","Member","About","Contact");
?>

  
    
    @if($user == "nakhin")
    <h1 style="font-family: saysettha OT;">>ຍີນດີຕ້ອນຮັບແອັດມີນ {{$user}}</h1>
@else
<h1 style="font-family: saysettha OT;">>ຜູ້ໃຊ້ຄົນນີ້ບໍ່ໄດ້ເປັນແອັດມີນ</h1>
@endif



<ul>
@for($i=1;$i<=5;$i++)
<li><p>{{$i}}</p></li>
@endfor
</ul>


@foreach($arr as $menu)
<a href="">{{$menu}}</a>
@endforeach
</body>
</html>


<!doctype html>
<html id="ecwid_html" lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="height=device-height, width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=1.0, viewport-fit=cover"/>
        <meta name="referrer" content="origin"/>
        <meta name="generator" content="ec-instant-site"/>
        <title>NK-Store Online</title>
        <link rel="manifest" href="/manifest.json"/>
        <meta name="theme-color" content="#FFFFFF"/>
        <meta http-equiv="x-dns-prefetch-control" content="on">
        <link rel="dns-prefetch" href="d34ikvsdm2rlij.cloudfront.net/startersite"/>
        <link rel="dns-prefetch" href="//don16obqbay2c.cloudfront.net"/>
        <link rel="dns-prefetch" href="//fonts.googleapis.com"/>
        <link rel="dns-prefetch" href="//maps.googleapis.com"/>
        <link rel="dns-prefetch" href="//fonts.gstatic.com"/>
        <link rel="preconnect" href="//fonts.gstatic.com" crossorigin="anonymous"/>
        <link rel="preload" href="//fonts.googleapis.com/css?family=Nunito:400,700|Cabin:400,700|Cabin:400,700&display=swap" crossorigin="anonymous"/>
        <link rel="preload" href="https://d1oxsl77a1kjht.cloudfront.net/css/new?hc=426078107&ownerid=83623760&frontendV2=true" as="style">
        <script>
            const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
            if (!isSafari) {
                const preloadLink = document.createElement("link");
                preloadLink.href = "https://app.ecwid.com/script.js?83623760&data_platform=startersite_v2";
                preloadLink.rel = "preload";
                preloadLink.as = "script";
                document.head.appendChild(preloadLink);
            }
        </script>
        <link rel="preload" href="https://d34ikvsdm2rlij.cloudfront.net/startersite/static/2023/2023-8756-gd2473c8129b35d/js/store.bundle.js" as="script"/>
        <link rel="shortcut icon" href="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg" type="image/jpg">
        <link rel="icon" href="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg" type="image/jpg">
        <link rel="apple-touch-icon" href="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg">
        <script>
            (function() {
                var isTouchDevice = false;
                var staticId = null;
                var staticContentClass = 'static-content';
                var dynamicId = null;
                var ecwidPageOpened = false;
                var autoSwitchStaticToDynamicWhenReady = false;
                var autoSwitchStaticToDynamicWhenReadyDefault = false;
                var invisibleDynamicContainerStyle = "display: block !important; height: 0 !important; max-height: 0 !important; min-height: 0 !important; overflow-y: auto !important;";
                var mainCategoryId = 0;
                var initialCategoryOffset = 0;

                function find(selector) {
                    return document.querySelector(selector);
                }

                function isDynamicMode() {
                    function isVisible(elem) {
                        return !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
                    }

                    var staticHtml = find('#' + staticId);
                    return !staticHtml || !isVisible(staticHtml);
                }

                function isRootCategory() {
                    var urlHash = window.location.hash;
                    return urlHash === '' || (urlHash.indexOf("#!/c/0/") === -1 && urlHash.indexOf("#!//c/0/") === -1);
                }

                function loadScriptJs(onScriptJsLoadedCallback) {
                    var scriptJs = document.createElement('script');
                    scriptJs.src = ec.storefront.staticPages.lazyLoading.scriptJsLink;
                    if (scriptJs.readyState) {
                        scriptJs.onreadystatechange = function() {
                            if (scriptJs.readyState === 'loaded' || scriptJs.readyState === 'complete') {
                                onScriptJsLoadedCallback();
                            }
                        }
                        ;
                    } else {
                        scriptJs.onload = onScriptJsLoadedCallback;
                    }
                    var dynamicEl = find("#" + ec.storefront.staticPages.dynamicContainerID);
                    dynamicEl.appendChild(scriptJs);
                }
                ;
                function processStaticHomePage() {

                    window.ec = window.ec || {};
                    window.ec.storefront = window.ec.storefront || {};
                    window.ec.storefront.staticPages = window.ec.storefront.staticPages || {};

                    window.ec.storefront.staticPages.switchStaticToDynamic = switchToDynamicMode;

                    function onDocumentReady(fn) {
                        if (document.attachEvent ? document.readyState === "complete" : document.readyState !== "loading") {
                            fn();
                        } else {
                            document.addEventListener('DOMContentLoaded', fn);
                        }
                    }

                    onDocumentReady(function() {
                        var staticStorefrontEnabled = window.ec.storefront.staticPages.staticStorefrontEnabled || false;

                        if (staticStorefrontEnabled !== true) {
                            return;
                        }

                        staticId = ec.storefront.staticPages.staticContainerID;
                        dynamicId = ec.storefront.staticPages.dynamicContainerID;
                        if (!staticId || !document.querySelector("#" + staticId)) {
                            if (!!console) {
                                console.warn("Static storefront is enabled, but no staticContainerID is provided or container is not present");
                            }
                            return;
                        }
                        if (!dynamicId || !document.querySelector("#" + dynamicId)) {
                            if (!!console) {
                                console.warn("Static storefront is enabled, but no dynamicContainerID is provided or container is not present");
                            }
                            return;
                        }

                        if (window.location.hash.indexOf("#!/c/0") !== -1) {
                            var element = document.querySelector("#" + staticId);
                            element.scrollIntoView(true);
                        }

                        if (!!('ontouchstart'in window)) {
                            isTouchDevice = true;
                            document.body.classList.add('touchable');
                        }

                        if (typeof ec.storefront.staticPages.lazyLoading !== "undefined") {
                            if (typeof ec.storefront.staticPages.lazyLoading.scriptJsLink === "undefined") {
                                if (!!console) {
                                    console.warn("Storefront lazy loading is enabled, but no scriptJsLink is provided");
                                }
                                return;
                            }
                            if (typeof ec.storefront.staticPages.lazyLoading.xProductBrowserArguments === "undefined") {
                                if (!!console) {
                                    console.warn("Storefront lazy loading is enabled, but no xProductBrowser arguments are provided");
                                }
                                return;
                            }

                            toggleLazyLoadingEvents(true);

                            var lazyLoading = true;

                            function lazyLoadingEventHandler() {
                                if (typeof lazyLoading === 'undefined') {
                                    if (!!console) {
                                        console.warn("Unable to fetch script.js outside of lazy loading mode");
                                    }
                                } else {
                                    toggleLazyLoadingEvents(false);
                                    loadScriptJs(lazyInitDynamic);
                                }
                            }

                            var lazyInitDynamic = function() {
                                xProductBrowser.apply(this, ec.storefront.staticPages.lazyLoading.xProductBrowserArguments);

                                setupEcwidWhenLoaded();
                            }

                            function toggleLazyLoadingEvents(add) {
                                var staticDivEventsForLazyLoading = ['mousedown', 'mouseup', 'mousemove', 'contextmenu', 'keydown', 'keyup'];
                                var staticDivTouchEventsForLazyLoading = ['touchstart', 'touchend', 'touchcancel', 'touchmove'];

                                var toggleEvent = function(el, add, event) {
                                    if (add) {
                                        el.addEventListener(event, lazyLoadingEventHandler);
                                    } else {
                                        el.removeEventListener(event, lazyLoadingEventHandler);
                                    }
                                }

                                var staticEl = find('#' + staticId);
                                if (isTouchDevice) {
                                    staticDivTouchEventsForLazyLoading.forEach(function applyEvent(event) {
                                        toggleEvent(staticEl, add, event);
                                    });
                                } else {
                                    staticDivEventsForLazyLoading.forEach(function applyEvent(event) {
                                        toggleEvent(staticEl, add, event);
                                    });
                                }
                            }
                        }

                        var mainCategoryIdFromConfig = ec.storefront.staticPages.mainCategoryId;
                        if (mainCategoryIdFromConfig) {
                            mainCategoryId = mainCategoryIdFromConfig;
                        }

                        var autoSwitchStaticToDynamicWhenReadyFromConfig = ec.storefront.staticPages.autoSwitchStaticToDynamicWhenReady;
                        if (autoSwitchStaticToDynamicWhenReadyFromConfig) {
                            autoSwitchStaticToDynamicWhenReady = autoSwitchStaticToDynamicWhenReadyFromConfig;
                        } else {
                            autoSwitchStaticToDynamicWhenReady = autoSwitchStaticToDynamicWhenReadyDefault;
                        }

                        if (ec.storefront.staticPages.initialCategoryOffset) {
                            initialCategoryOffset = ec.storefront.staticPages.initialCategoryOffset;
                        }

                        hideStorefront();
                        showStaticHtml();

                        window.ec.config = window.ec.config || {};

                        if (!isRootCategory()) {
                            hideStorefront();
                            switchToDynamicMode();
                            return;
                        }

                        addStaticPageHandlers();

                        function setupAfterEcwidLoaded() {
                            // if a store is opened for a client, then the storeClosed won't be true
                            // if a store is opened for a client and we've uploaded a closed banner, then we check it in dynamic
                            Ecwid.OnAPILoaded.add(function() {
                                if (isDynamicMode()) {
                                    // if we've already switched to dynamic, we don't need to dispatch this event anymore
                                    return;
                                }
                                var storeClosed = window.ecwid_initial_data.data.storeClosed;
                                var storeClosedWrapper = document.querySelectorAll('.ecwid-maintenance-wrapper');
                                var storeNotClosedAndWrapperExists = !storeClosed && storeClosedWrapper.length > 0;

                                if (storeClosed || storeNotClosedAndWrapperExists || hasEcwidMessages()) {
                                    switchToDynamicMode();
                                }
                            });

                            Ecwid.OnPageLoad.add(function(openedPage) {
                                if (isDynamicMode()) {
                                    // if we've already switched to dynamic, we don't need to dispatch this event anymore
                                    return;
                                }
                                if (openedPage.type === "CART" || openedPage.type === "ORDERS" || openedPage.type === "FAVORITES" || openedPage.type === "SIGN_IN" || openedPage.type === "RESET_PASSWORD" || hasEcwidMessages()) {
                                    // static links from bottom of the page should be processed before page load event finishes,
                                    // so self pre-opening scroll didn't make the page jump
                                    switchToDynamicMode();
                                }
                            });

                            addOnPageLoadedCallback(function(openedPage) {
                                if (isDynamicMode()) {
                                    // if we've already switched to dynamic, we don't need to dispatch this event anymore
                                    return;
                                }

                                if (autoSwitchStaticToDynamicWhenReady) {
                                    switchToDynamicWhenReadyWithRetries(10);
                                    return;
                                }

                                if (!ecwidPageOpened && openedPage.type === "CATEGORY" && openedPage.categoryId === mainCategoryId && openedPage.offset === initialCategoryOffset) {

                                    // we don't need to dispatch root category loading,
                                    // since our static contents covers it for the first time
                                    return;
                                }
                                // other than self we must show opened page in dynamic view,
                                // because static view contains only root category page
                                switchToDynamicMode();
                            }, 0);
                        }

                        function switchToDynamicWhenReadyWithRetries(retry) {
                            if (retry <= 0) {
                                switchToDynamicMode();
                                return;
                            }

                            var allImagesLoaded = allImagesLoadedInDynamicMarkup();
                            if (!allImagesLoaded) {
                                setTimeout(function() {
                                    switchToDynamicWhenReadyWithRetries(retry - 1);
                                }, 100);
                                return
                            }

                            switchToDynamicMode();
                        }

                        function allImagesLoadedInDynamicMarkup() {
                            if (!dynamicId) {
                                return true;
                            }

                            try {
                                var firstNotLoadedCategory = document.querySelector('#' + dynamicId + ' .grid-category--loading');
                                if (firstNotLoadedCategory != null) {
                                    return false;
                                }

                                var firstNotLoadedProduct = document.querySelector('#' + dynamicId + ' .grid-product--loading');
                                if (firstNotLoadedProduct != null) {
                                    return false;
                                }
                            } catch (e) {}

                            return true;
                        }

                        function ecwidLoaded() {
                            return !!Ecwid && !!Ecwid.OnAPILoaded && !!Ecwid.OnAPILoaded.add;
                        }

                        function hasEcwidMessages() {
                            // If the merchant has at least one custom label, then switch to dynamics regardless of the page type or click
                            return !!window.ecwidMessages && Object.keys(window.ecwidMessages).length > 0;
                        }

                        var setupEcwidWhenLoaded = function() {
                            if (ecwidLoaded()) {
                                setupAfterEcwidLoaded();
                            } else {
                                var setupIntervalId = setInterval(function() {
                                    if (ecwidLoaded()) {
                                        setupAfterEcwidLoaded();
                                        clearInterval(setupIntervalId);
                                    }
                                }, 100);
                            }
                        };

                        if (typeof lazyLoading === 'undefined') {
                            // Follow legacy dynamic store initialization flow
                            setupEcwidWhenLoaded();
                        }
                    });
                }

                function addStaticPageHandlers() {
                    function addClickHandlers(selector, elementProcessor) {
                        var elements = document.querySelectorAll(selector);
                        for (var i = 0; i < elements.length; i++) {
                            elementProcessor(elements[i]);
                        }
                    }

                    addClickHandlers('#' + staticId + ' .ec-breadcrumbs a', function(element) {
                        var categoryId = element.getAttribute('categoryId');
                        if (categoryId !== mainCategoryId) {
                            addStaticClickEvent(element, openEcwidPage('category', {
                                'id': categoryId
                            }));
                        }
                    });

                    var orderByOptions = document.querySelector('#' + staticId + ' .grid__sort select');
                    if (!!orderByOptions) {
                        orderByOptions.addEventListener('change', function(event) {
                            openEcwidPage('category', {
                                'id': mainCategoryId,
                                'sort': orderByOptions.value
                            })(event);
                        });
                    }

                    addClickHandlers('#' + staticId + ' .grid__sort .grid-sort__item--filter', function(element) {
                        addStaticClickEvent(element, function() {
                            addOnPageLoadedCallback(function() {
                                if (isDynamicMode()) {
                                    return;
                                }
                                switchToDynamicMode();
                                Ecwid.showProductFilters();
                            }, 0);
                        });
                    });

                    addClickHandlers('#' + staticId + ' .grid-category__card a', function(element) {
                        var categoryId = element.getAttribute('data-category-id');
                        addStaticClickEvent(element, openEcwidPage('category', {
                            'id': categoryId
                        }));
                    });

                    addClickHandlers('#' + staticId + ' .grid-product:not(.grid-product--view-all) a:not(.open-external-url)', function(element) {
                        var productId = element.getAttribute('data-product-id');
                        addStaticClickEvent(element, openEcwidPage('product', {
                            'id': productId
                        }));
                    });

                    addClickHandlers('#' + staticId + ' .grid-product:not(.grid-product--view-all) .grid-product__wrap[data-product-id]', function(element) {
                        var productId = element.getAttribute('data-product-id');
                        addStaticClickEvent(element, openEcwidPage('product', {
                            'id': productId
                        }));
                    });

                    addClickHandlers('#' + staticId + ' .grid-product--view-all a', function(element) {
                        var categoryId = element.getAttribute('data-category-id');
                        addStaticClickEvent(element, openEcwidPage('category', {
                            'id': categoryId
                        }));
                    })

                    addClickHandlers('#' + staticId + ' .grid-product__buy-now', function(element) {
                        var productId = element.getAttribute('data-product-id');
                        addStaticClickEvent(element, openEcwidPage('product', {
                            'id': productId
                        }));
                    });

                    addClickHandlers('#' + staticId + ' .footer__link--gift-card', function(element) {
                        var productId = element.getAttribute('data-product-id');
                        addStaticClickEvent(element, openEcwidPage('product', {
                            'id': productId
                        }));
                    });

                    addClickHandlers('#' + staticId + ' .footer__link--all-products', function(element) {
                        addStaticClickEvent(element, openEcwidPage('search'));
                    });

                    addClickHandlers('#' + staticId + ' .footer__link--track-order', function(element) {
                        addStaticClickEvent(element, openEcwidPage('account/orders'));
                    });

                    addClickHandlers('#' + staticId + ' .footer__link--shopping-favorites', function(element) {
                        addStaticClickEvent(element, openEcwidPage('account/favorites'));
                    });

                    addClickHandlers('#' + staticId + ' .footer__link--shopping-cart', function(element) {
                        addStaticClickEvent(element, openEcwidPage('cart'));
                    });

                    addClickHandlers('#' + staticId + ' .footer__link--sigin-in', function(element) {
                        addStaticClickEvent(element, openEcwidPage('signin'));
                    });

                    addClickHandlers('#' + staticId + ' .footer__link--my-account', function(element) {
                        addStaticClickEvent(element, openEcwidPage('account/settings'));
                    });

                    addClickHandlers('#' + staticId + ' .pager__button', function(element) {
                        var pageNumber = element.getAttribute('data-page-number') || 2;
                        addStaticClickEvent(element, openEcwidPage('category', {
                            'id': mainCategoryId,
                            'page': pageNumber
                        }));
                    });

                    addClickHandlers('#' + staticId + ' .pager__number', function(element) {
                        var pageNumber = element.getAttribute('data-page-number');
                        addStaticClickEvent(element, openEcwidPage('category', {
                            'id': mainCategoryId,
                            'page': pageNumber
                        }));
                    });

                    addClickHandlers('#' + staticId + ' .open-external-url', function(element) {
                        addStaticClickEvent(element, function(e) {
                            e.stopPropagation();
                        });
                    });
                }

                function addStaticClickEvent(el, callback) {
                    var x = 0
                      , y = 0
                      , dx = 0
                      , dy = 0
                      , isTap = false;

                    if (isTouchDevice) {
                        el.addEventListener('touchstart', function(e) {
                            isTap = true;
                            x = e.touches[0].clientX;
                            y = e.touches[0].clientY;
                            dx = 0;
                            dy = 0;
                        });
                        el.addEventListener('touchmove', function(e) {
                            dx = e.changedTouches[0].clientX - x;
                            dy = e.changedTouches[0].clientY - y;
                        });
                        el.addEventListener('touchend', function(e) {
                            if (isTap && Math.abs(dx) < 10 && Math.abs(dy) < 10) {
                                callback(e);
                            }
                        });
                    }

                    el.addEventListener('click', function(e) {
                        if (!isTap) {
                            callback(e);
                        } else {
                            isTap = false;
                        }
                    });
                }

                function openEcwidPage(page, params) {
                    return function(e) {
                        if (isCtrlClickOnProductEvent(page, e)) {
                            // In case product element in grid was clicked with ctrl/meta key, do not invoke e.preventDefault()
                            // and do nothing. Event will be handled and processed by default ctrl/meta + click handler on
                            // underlying <a> element. New background tab with product page will be opened.
                            return;
                        }

                        e.preventDefault();
                        // we must wait for Ecwid first page to be ready before changing it
                        addOnPageLoadedCallback(function() {
                            if (isDynamicMode()) {
                                // if we've already switched to dynamic, we don't need to dispatch this event anymore
                                return;
                            }
                            var onClickCallback = window.ec.storefront.staticPages.onClickCallback;
                            if (!autoSwitchStaticToDynamicWhenReady && onClickCallback) {
                                onClickCallback();
                            }
                            ecwidPageOpened = true;
                            var element = find('#' + staticId + " .ec-wrapper");
                            if (!!element) {
                                elementsClassListAction([element], function(list) {
                                    list.add("ec-wrapper--transition");
                                });
                            }
                            Ecwid.openPage(page, params);
                        }, 0);
                    }
                }

                function isCtrlClickOnProductEvent(page, event) {
                    return page === 'product' && (event.ctrlKey || event.metaKey)
                }

                function addOnPageLoadedCallback(callback, attempt) {
                    // let's wait for the Ecwid environment to be loaded for up to 2000 milliseconds
                    if (attempt >= 40) {
                        if (!!console) {
                            console.warn("failed to add Ecwid.OnPageLoaded callback");
                        }
                        return;
                    }

                    if (typeof (Ecwid) == 'object' && typeof (Ecwid.OnPageLoaded) == 'object') {
                        Ecwid.OnPageLoaded.add(callback);
                    } else {
                        setTimeout(function() {
                            addOnPageLoadedCallback(callback, attempt + 1);
                        }, 50);
                    }
                }

                function hideStorefront() {
                    var dynamicEl = find('#' + dynamicId);
                    var currentStyleAttribute = dynamicEl.getAttribute("style") || "";

                    dynamicEl.setAttribute("style", currentStyleAttribute + invisibleDynamicContainerStyle);
                }

                function showStorefront() {
                    var dynamicEl = find('#' + dynamicId);
                    // disable zero-height trick to show the storefront
                    dynamicEl.style.height = "";
                    dynamicEl.style.maxHeight = "";
                    dynamicEl.style.minHeight = "";
                    dynamicEl.style.overflowY = "";
                    dynamicEl.style.display = "block";
                }

                function hideStaticHtml() {
                    var staticEl = find('#' + staticId);
                    if (!!staticEl) {
                        staticEl.style.opacity = 0;
                        staticEl.style.display = 'none';
                    }
                }

                function showStaticHtml() {
                    var element = find('#' + staticId + " ." + staticContentClass);
                    if (!!element) {
                        element.style.opacity = 1;
                    }
                }

                function switchToDynamicMode() {
                    requestAnimationFrame(function() {
                        removeClassAnimationForAutoSwitchToDynamic();
                        showStorefront();
                        hideStaticHtml();

                        var staticEl = find('#' + staticId);
                        if (staticEl && staticEl.parentNode) {
                            staticEl.parentNode.removeChild(staticEl);
                        }
                        var switchToDynamicCallback = window.ec.storefront.staticPages.switchToDynamicCallback;

                        var element = find('#' + staticId + " .ec-wrapper");
                        if (!!element) {
                            elementsClassListAction([element], function(list) {
                                list.remove("ec-wrapper--transition");
                            });
                        }
                        if (!autoSwitchStaticToDynamicWhenReady && switchToDynamicCallback) {
                            switchToDynamicCallback();
                        }
                    });
                }

                function removeClassAnimationForAutoSwitchToDynamic() {
                    if (!autoSwitchStaticToDynamicWhenReady) {
                        return;
                    }
                    var wrapers = document.querySelectorAll('.ec-wrapper--animated-transitions');
                    var arrWrapers = Array.prototype.slice.call(wrapers);
                    elementsClassListAction(arrWrapers, function(list) {
                        list.remove('ec-wrapper--animated-transitions');
                    });
                }

                function elementsClassListAction(elements, callback) {
                    if (!(Array.isArray(elements))) {
                        return;
                    }
                    for (var key in elements) {
                        var list = elements[key].classList;
                        if (typeof list != 'undefined') {
                            callback(list);
                        }
                    }
                }

                processStaticHomePage();

                function forceDynamicLoadingIfRequired() {
                    if (typeof ec.storefront.staticPages.lazyLoading === "undefined") {
                        if (!!console) {
                            console.warn("Storefront lazy loading is not enabled to switch in dynamic mode");
                        }
                        return;
                    }
                    if (typeof ec.storefront.staticPages.lazyLoading.scriptJsLink === "undefined") {
                        if (!!console) {
                            console.warn("No scriptJsLink is provided to switch in dynamic mode");
                        }
                        return;
                    }
                    if (typeof ec.storefront.staticPages.lazyLoading.xProductBrowserArguments === "undefined") {
                        if (!!console) {
                            console.warn("No xProductBrowser arguments are provided to switch in dynamic mode");
                        }
                        return;
                    }

                    var staticContainer = document.getElementById(ec.storefront.staticPages.staticContainerID);

                    var rootCategory = isRootCategory();
                    if (!rootCategory) {
                        while (staticContainer.lastChild) {
                            staticContainer.lastChild.remove();
                        }

                        var onScriptJsLoadedCallback = function() {
                            xProductBrowser.apply(this, ec.storefront.staticPages.lazyLoading.xProductBrowserArguments);
                        }

                        loadScriptJs(onScriptJsLoadedCallback);
                    } else {
                        staticContainer.style.height = "";
                        staticContainer.style.maxHeight = "";
                        staticContainer.style.minHeight = "";
                        staticContainer.style.overflowY = "";
                    }
                }

                window.ec = window.ec || {};
                window.ec.storefront = window.ec.storefront || {};
                window.ec.storefront.staticPages = window.ec.storefront.staticPages || {};
                window.ec.storefront.staticPages.forceDynamicLoadingIfRequired = forceDynamicLoadingIfRequired;
            }
            )();
        </script>
        <link rel="stylesheet" type="text/css" href="https://d1oxsl77a1kjht.cloudfront.net/css/new?hc=426078107&ownerid=83623760&frontendV2=true"/>
        <style>
            #static-html .container {
                padding: 5px 0 0;
            }
        </style>
        <script>
            window.ec = window.ec || {};
            window.ec.storefront = window.ec.storefront || {};
            window.ec.storefront.staticPages = window.ec.storefront.staticPages || {};
            window.ec.storefront.staticPages.staticStorefrontEnabled = true;

            ec.storefront.staticPages.staticContainerID = "static-html";
            ec.storefront.staticPages.dynamicContainerID = "main";
        </script>
        <meta property="og:title" content="NK-Store Online"/>
        <meta property="og:url" content="https://nakhin.company.site"/>
        <meta property="og:image" content='https://s3.amazonaws.com/images.ecwid.com/images/83623760/3414811819.jpg'/>
        <meta property="og:site_name" content="NK-Store Online"/>
        <meta property="og:type" content="website"/>
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="NK-Store Online">
        <meta name="twitter:description" content="NK-Store Online">
        <meta name="twitter:image" content="https://s3.amazonaws.com/images.ecwid.com/images/83623760/3414811819.jpg">
        <link rel="canonical" href="https://nakhin.company.site/"/>
        <style>
            @keyframes button-primary-focus {
                50% {
                    background-color: #595959
                }
            }

            @keyframes button-secondary-focus {
                50% {
                    background-color: #f2f2f2
                }
            }

            @keyframes preloader-rotate {
                0% {
                    transform: rotate(0deg)
                }

                100% {
                    transform: rotate(360deg)
                }
            }

            @keyframes bounce-x {
                0% {
                    transform: translate3d(0, 0, 0)
                }

                10% {
                    transform: translate3d(-6px, 0, 0)
                }

                20% {
                    transform: translate3d(12px, 0, 0)
                }

                29% {
                    transform: translate3d(-12px, 0, 0)
                }

                38% {
                    transform: translate3d(11px, 0, 0)
                }

                47% {
                    transform: translate3d(-9px, 0, 0)
                }

                56% {
                    transform: translate3d(7px, 0, 0)
                }

                65% {
                    transform: translate3d(-5px, 0, 0)
                }

                74% {
                    transform: translate3d(3px, 0, 0)
                }

                83% {
                    transform: translate3d(-1px, 0, 0)
                }

                92% {
                    transform: translate3d(1px, 0, 0)
                }

                100% {
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes bounce-top {
                0% {
                    transform: translate3d(0, 0, 0)
                }

                12% {
                    transform: translate3d(0, -5px, 0)
                }

                25% {
                    transform: translate3d(0, -7px, 0)
                }

                37% {
                    transform: translate3d(0, -5px, 0)
                }

                50% {
                    transform: translate3d(0, 0, 0)
                }

                62% {
                    transform: translate3d(0, -3px, 0)
                }

                75% {
                    transform: translate3d(0, -4px, 0)
                }

                87% {
                    transform: translate3d(0, -3px, 0)
                }

                100% {
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes heartbit-1x {
                0% {
                    transform: scale(1)
                }

                50% {
                    transform: scale(1.2)
                }

                100% {
                    transform: scale(1)
                }
            }

            @keyframes form-control-svg {
                0%,100% {
                    opacity: 0
                }

                6%,94% {
                    opacity: 1
                }
            }

            @keyframes form-control-text {
                0%,100% {
                    opacity: 1
                }

                6%,94% {
                    opacity: 0
                }
            }

            @keyframes form-control-check {
                from {
                    opacity: 1;
                    stroke-dasharray: 50;
                    stroke-dashoffset: 50
                }

                to {
                    opacity: 1;
                    stroke-dasharray: 50;
                    stroke-dashoffset: 0
                }
            }

            @keyframes marker-required {
                0% {
                    opacity: 1;
                    transform: scale(0)
                }

                100% {
                    opacity: 0;
                    transform: scale(2)
                }
            }

            @keyframes progress-bar-stripes {
                from {
                    background-position: 40px 0
                }

                to {
                    background-position: 0 0
                }
            }

            @keyframes move-bg {
                0% {
                    background-position: 200% 0
                }

                100% {
                    background-position: 0 0
                }
            }

            @keyframes showFromTop {
                0% {
                    opacity: 0;
                    transform: translate3d(0, -10px, 0)
                }

                100% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes showFromBottom {
                0% {
                    opacity: 0;
                    transform: translate3d(0, 20px, 0)
                }

                100% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes hideToTop {
                0% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }

                100% {
                    opacity: 0;
                    transform: translate3d(0, -20px, 0)
                }
            }

            @keyframes hideToBottom {
                0% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }

                100% {
                    opacity: 0;
                    transform: translate3d(0, 20px, 0)
                }
            }

            @keyframes fade-in {
                from {
                    opacity: 0
                }

                to {
                    opacity: 1
                }
            }

            @keyframes fade-out {
                from {
                    opacity: 1
                }

                to {
                    opacity: 0
                }
            }

            @keyframes popup-show-wrap {
                from {
                    transform: translateX(60px)
                }

                to {
                    transform: translateX(0)
                }
            }

            @keyframes popup-hide-wrap {
                from {
                    transform: translateX(0)
                }

                to {
                    transform: translateX(60px)
                }
            }

            @keyframes popup-show-wrap-from-left {
                from {
                    transform: translateX(-60px)
                }

                to {
                    transform: translateX(0)
                }
            }

            :root {
                --color-cover-title: $color-white;
                --color-cover-text: $color-white;
                --color-cover-button-text: $color-white;
                --color-cover-button-background: $base-color-button-v2;
                --color-menu: $color-white;
                --fontfamily-cover-title: $font-family;
                --fontfamily-cover-text: $font-family
            }

            .ec-size .ec-store {
                /*! normalize.css v5.0.0 | MIT License | github.com/necolas/normalize.css */
            }

            .ec-size .ec-store {
                margin: 0;
                padding: 0;
                font-family: "Root UI","-apple-system","BlinkMacSystemFont","Segoe UI","Roboto",Arial,sans-serif;
                text-align: left;
                word-wrap: normal;
                word-break: normal
            }

            .ec-size .ec-store article,.ec-size .ec-store aside,.ec-size .ec-store footer,.ec-size .ec-store header,.ec-size .ec-store nav,.ec-size .ec-store section {
                display: block
            }

            .ec-size .ec-store figcaption,.ec-size .ec-store figure,.ec-size .ec-store main {
                display: block
            }

            .ec-size .ec-store figure {
                margin: 1em 40px
            }

            .ec-size .ec-store hr {
                overflow: visible;
                box-sizing: content-box;
                height: 0
            }

            .ec-size .ec-store pre {
                font-family: monospace;
                font-size: 1em
            }

            .ec-size .ec-store a {
                background-color: transparent;
                text-decoration: none;
                -webkit-text-decoration-skip: objects
            }

            .ec-size .ec-store a:active,.ec-size .ec-store a:hover {
                outline-width: 0
            }

            .ec-size .ec-store abbr[title] {
                border-bottom: none;
                text-decoration: underline
            }

            .ec-size .ec-store b,.ec-size .ec-store strong {
                font-weight: 600
            }

            .ec-size .ec-store code,.ec-size .ec-store kbd,.ec-size .ec-store samp {
                font-family: monospace;
                font-size: 1em
            }

            .ec-size .ec-store dfn {
                font-style: italic
            }

            .ec-size .ec-store mark {
                background-color: #a20505;
                color: #000
            }

            .ec-size .ec-store small {
                font-size: 80%
            }

            .ec-size .ec-store sub,.ec-size .ec-store sup {
                position: relative;
                font-size: 75%;
                line-height: 0;
                vertical-align: baseline
            }

            .ec-size .ec-store sub {
                bottom: -.25em
            }

            .ec-size .ec-store sup {
                top: -.5em
            }

            .ec-size .ec-store audio,.ec-size .ec-store video {
                display: inline-block
            }

            .ec-size .ec-store audio:not([controls]) {
                display: none;
                height: 0
            }

            .ec-size .ec-store img {
                border-style: none
            }

            .ec-size .ec-store svg:not(:root) {
                overflow: hidden
            }

            .ec-size .ec-store button,.ec-size .ec-store input,.ec-size .ec-store optgroup,.ec-size .ec-store select,.ec-size .ec-store textarea {
                margin: 0;
                font-family: "Root UI","-apple-system","BlinkMacSystemFont","Segoe UI","Roboto",Arial,sans-serif;
                font-size: 100%;
                line-height: 1.15
            }

            .ec-size .ec-store button,.ec-size .ec-store input {
                overflow: visible
            }

            .ec-size .ec-store button,.ec-size .ec-store select {
                text-transform: none
            }

            .ec-size .ec-store button,.ec-size .ec-store html [type="button"],.ec-size .ec-store [type="reset"],.ec-size .ec-store [type="submit"] {
                -webkit-appearance: button
            }

            .ec-size .ec-store fieldset {
                margin: 0;
                padding: 0;
                border: none
            }

            .ec-size .ec-store legend {
                overflow: hidden;
                height: 0
            }

            .ec-size .ec-store progress {
                display: inline-block;
                vertical-align: baseline
            }

            .ec-size .ec-store textarea {
                overflow: auto
            }

            .ec-size .ec-store [type="checkbox"],.ec-size .ec-store [type="radio"] {
                box-sizing: border-box;
                padding: 0
            }

            .ec-size .ec-store [type="number"]::-webkit-inner-spin-button,.ec-size .ec-store [type="number"]::-webkit-outer-spin-button {
                height: auto
            }

            .ec-size .ec-store [type="search"] {
                outline-offset: -2px;
                -webkit-appearance: textfield
            }

            .ec-size .ec-store [type="search"]::-webkit-search-cancel-button,.ec-size .ec-store [type="search"]::-webkit-search-decoration {
                -webkit-appearance: none
            }

            .ec-size .ec-store ::-webkit-file-upload-button {
                font: inherit;
                -webkit-appearance: button
            }

            .ec-size .ec-store details,.ec-size .ec-store menu {
                display: block
            }

            .ec-size .ec-store summary {
                display: list-item
            }

            .ec-size .ec-store canvas {
                display: inline-block
            }

            .ec-size .ec-store template {
                display: none
            }

            .ec-size .ec-store [hidden] {
                display: none
            }

            .ec-size .ec-store * {
                box-sizing: border-box;
                opacity: 1;
                min-width: 0;
                max-width: none;
                min-height: 0;
                max-height: none;
                margin: 0;
                padding: 0;
                background: none;
                box-shadow: none;
                letter-spacing: normal;
                word-spacing: normal;
                transform: none;
                transform-origin: center center;
                transition: none
            }

            .ec-size .ec-store *:focus:not(:focus-visible) {
                outline: none
            }

            .ec-size .ec-store canvas:not([width]),.ec-size .ec-store embed:not([width]),.ec-size .ec-store iframe:not([width]),.ec-size .ec-store img:not([width]),.ec-size .ec-store object:not([width]),.ec-size .ec-store video:not([width]),.ec-size .ec-store svg:not([width]) {
                width: initial
            }

            .ec-size .ec-store canvas:not([height]),.ec-size .ec-store embed:not([height]),.ec-size .ec-store iframe:not([height]),.ec-size .ec-store img:not([height]),.ec-size .ec-store object:not([height]),.ec-size .ec-store video:not([height]),.ec-size .ec-store svg:not([height]) {
                height: initial
            }

            .ec-size .ec-store fb\:comments,.ec-size .ec-store fb\:comments>span,.ec-size .ec-store fb\:comments iframe {
                max-width: 100%
            }

            .ec-size .ec-store .form-control {
                display: inline-block;
                position: relative;
                width: auto;
                max-width: 100%;
                height: auto;
                -webkit-font-smoothing: antialiased;
                text-align: left;
                vertical-align: middle
            }

            .ec-size .ec-store .form-control--flexible {
                width: 100%
            }

            .ec-size .ec-store .form-control--flexible .form-control__inline-label {
                width: 100%
            }

            .ec-size .ec-store .form__title {
                margin: 4px 0;
                line-height: 1.4;
                font-size: 14px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form__title {
                    font-size:16px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form__title {
                    font-size:16px
                }
            }

            .ec-size .ec-store .ec-form-choice-group__item {
                cursor: pointer;
                -webkit-tap-highlight-color: transparent
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .ec-form-choice-group__item {
                    margin:0;
                    border-top: 1px solid #e6e6e6
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .ec-form-choice-group__item .form-control {
                    margin-bottom:0px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .ec-form-choice-group__item .form-control__inline-label {
                    padding-top:10px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .ec-form-choice-group__item .form-control__inline-label {
                    padding-bottom:10px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .ec-form-choice-group__item .form-control__inline-label {
                    display:block
                }
            }

            .ec-size .ec-store .ec-form {
                width: 100%;
                margin-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .ec-form {
                    margin-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form {
                    margin-bottom:10px
                }
            }

            .ec-size .ec-store .ec-form--cards .form-control__text,.ec-size .ec-store .ec-form--cards .form-control__select {
                letter-spacing: 1px
            }

            .ec-size .ec-store .ec-form--mb2 {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .ec-form--mb2 {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form--mb2 {
                    margin-bottom:20px
                }
            }

            .ec-size .ec-store .ec-form__row {
                display: flex;
                flex-wrap: wrap;
                margin-left: -5px;
                margin-right: -5px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .ec-form__row {
                    margin-left:-4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form__row {
                    margin-left:-5px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .ec-form__row {
                    margin-right:-4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form__row {
                    margin-right:-5px
                }
            }

            .ec-size .ec-store .ec-form__cell {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                width: 100%;
                padding-left: 5px;
                padding-right: 5px;
                margin-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .ec-form__cell {
                    padding-left:4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form__cell {
                    padding-left:5px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .ec-form__cell {
                    padding-right:4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form__cell {
                    padding-right:5px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .ec-form__cell {
                    margin-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form__cell {
                    margin-bottom:10px
                }
            }

            .ec-size .ec-store .ec-form__cell--1 {
                width: 8.3333333333%
            }

            .ec-size .ec-store .ec-form__cell--2 {
                width: 16.6666666667%
            }

            .ec-size .ec-store .ec-form__cell--3 {
                width: 25%
            }

            .ec-size .ec-store .ec-form__cell--4 {
                width: 33.3333333333%
            }

            .ec-size .ec-store .ec-form__cell--5 {
                width: 41.6666666667%
            }

            .ec-size .ec-store .ec-form__cell--6 {
                width: 50%
            }

            .ec-size .ec-store .ec-form__cell--7 {
                width: 58.3333333333%
            }

            .ec-size .ec-store .ec-form__cell--8 {
                width: 66.6666666667%
            }

            .ec-size .ec-store .ec-form__cell--9 {
                width: 75%
            }

            .ec-size .ec-store .ec-form__cell--10 {
                width: 83.3333333333%
            }

            .ec-size .ec-store .ec-form__cell--11 {
                width: 91.6666666667%
            }

            @media screen and (max-width: 767px) {
                .ec-size .ec-store .ec-form__cell {
                    width:100%
                }
            }

            .ec-size .ec-store .ec-form__cell--vtop {
                justify-content: flex-start
            }

            .ec-size .ec-store .ec-form__cell--vcenter {
                justify-content: center
            }

            .ec-size .ec-store .ec-form__cell--vbottom {
                justify-content: flex-end
            }

            .ec-size .ec-store .ec-form__cell--hleft {
                align-items: flex-start
            }

            .ec-size .ec-store .ec-form__cell--hcenter {
                align-items: center
            }

            .ec-size .ec-store .ec-form__cell--hright {
                align-items: flex-end
            }

            .ec-size .ec-store .ec-form__title {
                overflow: hidden;
                max-width: 100%;
                text-overflow: ellipsis;
                white-space: nowrap;
                margin-top: 5px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .ec-form__title {
                    margin-top:4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form__title {
                    margin-top:5px
                }
            }

            @media screen and (min-width: 768px) {
                .ec-size .ec-store .ec-form__pec-note {
                    transform:translateY(calc(16px + max(-50%, -22px)))
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .ec-form__pec-note {
                    transform:translateY(calc(20px + max(-50%, -25px)))
                }
            }

            .ec-size .ec-store .form-control {
                border: none;
                border-radius: 3px;
                background-color: #fbfbfb;
                color: #6e6e6e;
                font-size: inherit;
                line-height: normal;
                transition: background-color .15s ease-out 0s
            }

            .ec-size .ec-store .form-control:hover:not(.form-control--error):not(.form-control--focus) .form-control__text,.ec-size .ec-store .form-control:hover:not(.form-control--error):not(.form-control--focus) .form-control__textarea,.ec-size .ec-store .form-control:hover:not(.form-control--error):not(.form-control--focus) .form-control__prefix,.ec-size .ec-store .form-control:hover:not(.form-control--error):not(.form-control--focus) .form-control__suffix {
                border-color: #517c9e;
                box-shadow: 0 0 0 rgba(0,0,0,0) inset
            }

            .ec-size .ec-store .form-control:hover {
                background-color: #fff
            }

            .ec-size .ec-store .form-control--no-hover:hover {
                background-color: #fbfbfb
            }

            .ec-size .ec-store .form-control--no-hover:hover.form-control--focus {
                background-color: #fff
            }

            .ec-size .ec-store .form-control--no-hover:hover.form-control--error {
                background-color: #fff0f0
            }

            .ec-size .ec-store .form-control--prefix .form-control__inner,.ec-size .ec-store .form-control--suffix .form-control__inner {
                box-shadow: 0 1px 2px rgba(0,0,0,0.08) inset
            }

            .ec-size .ec-store .form-control--prefix .form-control__text,.ec-size .ec-store .form-control--suffix .form-control__text {
                box-shadow: none
            }

            .ec-size .ec-store .form-control--prefix:hover .form-control__inner::before,.ec-size .ec-store .form-control--suffix:hover .form-control__inner::before {
                z-index: -1
            }

            .ec-size .ec-store .form-control--prefix:hover .form-control__prefix,.ec-size .ec-store .form-control--prefix:hover .form-control__suffix,.ec-size .ec-store .form-control--suffix:hover .form-control__prefix,.ec-size .ec-store .form-control--suffix:hover .form-control__suffix {
                background-color: #fff
            }

            .ec-size .ec-store .form-control--prefix .form-control__text,.ec-size .ec-store .form-control--prefix .form-control__placeholder,.ec-size .ec-store .form-control--prefix .form-control__label {
                padding-left: 20px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--prefix .form-control__text,.ec-size .ec-store .form-control--prefix .form-control__placeholder,.ec-size .ec-store .form-control--prefix .form-control__label {
                    padding-left:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--prefix .form-control__text,.ec-size .ec-store .form-control--prefix .form-control__placeholder,.ec-size .ec-store .form-control--prefix .form-control__label {
                    padding-left:20px
                }
            }

            .ec-size .ec-store .form-control--prefix .form-control__prefix {
                display: flex
            }

            .ec-size .ec-store .form-control--suffix .form-control__text,.ec-size .ec-store .form-control--suffix .form-control__placeholder,.ec-size .ec-store .form-control--suffix .form-control__label {
                padding-right: 20px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--suffix .form-control__text,.ec-size .ec-store .form-control--suffix .form-control__placeholder,.ec-size .ec-store .form-control--suffix .form-control__label {
                    padding-right:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--suffix .form-control__text,.ec-size .ec-store .form-control--suffix .form-control__placeholder,.ec-size .ec-store .form-control--suffix .form-control__label {
                    padding-right:20px
                }
            }

            .ec-size .ec-store .form-control--suffix .form-control__suffix {
                display: flex
            }

            .ec-size .ec-store .form-control input::-ms-clear {
                display: none
            }

            .ec-size .ec-store .form-control--focus {
                background-color: #fff;
                color: #6e6e6e
            }

            .ec-size .ec-store .form-control--focus .form-control__text,.ec-size .ec-store .form-control--focus .form-control__textarea,.ec-size .ec-store .form-control--focus .form-control__prefix,.ec-size .ec-store .form-control--focus .form-control__suffix {
                border-color: #1a7ac4;
                box-shadow: 0 0 0 1px #1a7ac4 inset
            }

            .ec-size .ec-store .form-control--focus .form-control__prefix,.ec-size .ec-store .form-control--focus .form-control__suffix {
                background-color: #fff;
                color: #191919
            }

            .ec-size .ec-store .form-control--focus .form-control__prefix::before,.ec-size .ec-store .form-control--focus .form-control__suffix::before {
                border-color: #757575
            }

            .ec-size .ec-store .form-control--focus .form-control__prefix {
                box-shadow: 0 1px 0 0 #1a7ac4 inset,1px 0 0 #1a7ac4 inset,0 -1px 0 0 #1a7ac4 inset
            }

            .ec-size .ec-store .form-control--focus .form-control__suffix {
                box-shadow: 0 1px 0 0 #1a7ac4 inset,-1px 0 0 #1a7ac4 inset,0 -1px 0 0 #1a7ac4 inset
            }

            .ec-size .ec-store .form-control--focus .form-control__text[type=number] {
                padding-right: 2px
            }

            .ec-size .ec-store .form-control--focus:hover .form-control__inner::before {
                z-index: -1
            }

            .ec-size .ec-store .form-control:not(.form-control--focus) .form-control__text[type=number] {
                -moz-appearance: textfield
            }

            .ec-size .ec-store .form-control:not(.form-control--focus) .form-control__text[type=number]::-webkit-outer-spin-button,.ec-size .ec-store .form-control:not(.form-control--focus) .form-control__text[type=number]::-webkit-inner-spin-button {
                margin: 0;
                -webkit-appearance: none
            }

            .ec-size .ec-store .form-control--success .form-control__text,.ec-size .ec-store .form-control--fail .form-control__text {
                padding-right: 40px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--success .form-control__text,.ec-size .ec-store .form-control--fail .form-control__text {
                    padding-right:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--success .form-control__text,.ec-size .ec-store .form-control--fail .form-control__text {
                    padding-right:40px
                }
            }

            .ec-size .ec-store .form-control--success .form-control__arrow,.ec-size .ec-store .form-control--success .form-control__icon,.ec-size .ec-store .form-control--fail .form-control__arrow,.ec-size .ec-store .form-control--fail .form-control__icon {
                display: none
            }

            .ec-size .ec-store .form-control--success.form-control--suffix .form-control__icon,.ec-size .ec-store .form-control--fail.form-control--suffix .form-control__icon {
                padding-right: 10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--success.form-control--suffix .form-control__icon,.ec-size .ec-store .form-control--fail.form-control--suffix .form-control__icon {
                    padding-right:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--success.form-control--suffix .form-control__icon,.ec-size .ec-store .form-control--fail.form-control--suffix .form-control__icon {
                    padding-right:10px
                }
            }

            .ec-size .ec-store .form-control--success .form-control__icon--success {
                display: flex;
                z-index: 1
            }

            .ec-size .ec-store .form-control--success .form-control__icon--success svg {
                animation: heartbit-1x .3s ease forwards 0s
            }

            .ec-size .ec-store .form-control--fail .form-control__icon--fail {
                display: flex;
                z-index: 1
            }

            .ec-size .ec-store .form-control--fail .form-control__icon--fail svg {
                animation: heartbit-1x .3s ease forwards 0s
            }

            .ec-size .ec-store .form-control--error {
                background-color: #fff0f0;
                color: #e56464
            }

            .ec-size .ec-store .form-control--error .form-control__text,.ec-size .ec-store .form-control--error .form-control__textarea,.ec-size .ec-store .form-control--error .form-control__prefix,.ec-size .ec-store .form-control--error .form-control__suffix {
                border-color: #e56363;
                box-shadow: 0 0 0 1px #e56363 inset;
                color: #191919
            }

            .ec-size .ec-store .form-control--error .form-control__prefix,.ec-size .ec-store .form-control--error .form-control__suffix {
                background-color: #fff0f0
            }

            .ec-size .ec-store .form-control--error .form-control__prefix::before,.ec-size .ec-store .form-control--error .form-control__suffix::before {
                border-color: #e56363
            }

            .ec-size .ec-store .form-control--error .form-control__prefix {
                box-shadow: 0 1px 0 0 #e56363 inset,1px 0 0 #e56363 inset,0 -1px 0 0 #e56363 inset
            }

            .ec-size .ec-store .form-control--error .form-control__prefix-inner {
                color: #e56464
            }

            .ec-size .ec-store .form-control--error .form-control__suffix {
                box-shadow: 0 1px 0 0 #e56363 inset,-1px 0 0 #e56363 inset,0 -1px 0 0 #e56363 inset
            }

            .ec-size .ec-store .form-control--error .form-control__suffix-inner {
                color: #e56464
            }

            .ec-size .ec-store .form-control--error .form-control__placeholder-inner {
                opacity: .5
            }

            .ec-size .ec-store .form-control--empty:not(.form-control--focus) .form-control__placeholder,.ec-size .ec-store .form-control--empty:not(.form-control--label) .form-control__placeholder {
                opacity: 1;
                transform: translate3d(0, 0, 0)
            }

            .ec-size .ec-store .form-control--empty:not(.form-control--focus) .form-control__label,.ec-size .ec-store .form-control--empty:not(.form-control--label) .form-control__label {
                opacity: 0;
                transform: translate3d(0, 5px, 0)
            }

            .ec-size .ec-store .form-control--disabled {
                background-color: rgba(25,25,25,0.08);
                cursor: not-allowed;
                pointer-events: none
            }

            .ec-size .ec-store .form-control--disabled .form-control__prefix,.ec-size .ec-store .form-control--disabled .form-control__suffix {
                background-color: #fff
            }

            .ec-size .ec-store .form-control--disabled .form-control__prefix::after,.ec-size .ec-store .form-control--disabled .form-control__suffix::after {
                content: "";
                display: block;
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                background-color: rgba(25,25,25,0.08)
            }

            .ec-size .ec-store .form-control--large .form-control__text,.ec-size .ec-store .form-control--large .form-control__prefix,.ec-size .ec-store .form-control--large .form-control__suffix {
                height: 50px;
                min-height: 50px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--large .form-control__text,.ec-size .ec-store .form-control--large .form-control__prefix,.ec-size .ec-store .form-control--large .form-control__suffix {
                    height:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--large .form-control__text,.ec-size .ec-store .form-control--large .form-control__prefix,.ec-size .ec-store .form-control--large .form-control__suffix {
                    height:50px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--large .form-control__text,.ec-size .ec-store .form-control--large .form-control__prefix,.ec-size .ec-store .form-control--large .form-control__suffix {
                    min-height:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--large .form-control__text,.ec-size .ec-store .form-control--large .form-control__prefix,.ec-size .ec-store .form-control--large .form-control__suffix {
                    min-height:50px
                }
            }

            .ec-size .ec-store .form-control--large .form-control__ico-btn {
                width: 50px;
                min-width: 50px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--large .form-control__ico-btn {
                    width:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--large .form-control__ico-btn {
                    width:50px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--large .form-control__ico-btn {
                    min-width:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--large .form-control__ico-btn {
                    min-width:50px
                }
            }

            .ec-size .ec-store .form-control--large .form-control__icon {
                margin-right: 15px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--large .form-control__icon {
                    margin-right:12px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--large .form-control__icon {
                    margin-right:15px
                }
            }

            .ec-size .ec-store .form-control--large .form-control__prefix,.ec-size .ec-store .form-control--large .form-control__suffix {
                min-width: 40px;
                padding: 0 10px
            }

            .ec-size .ec-store .form-control--large .form-control__prefix::before,.ec-size .ec-store .form-control--large .form-control__suffix::before {
                top: 8px;
                bottom: 8px
            }

            .ec-size .ec-store .form-control--small .form-control__text,.ec-size .ec-store .form-control--small .form-control__prefix,.ec-size .ec-store .form-control--small .form-control__suffix {
                line-height: 1.4;
                font-size: 12px;
                height: 30px;
                min-height: 30px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__text,.ec-size .ec-store .form-control--small .form-control__prefix,.ec-size .ec-store .form-control--small .form-control__suffix {
                    font-size:14px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control--small .form-control__text,.ec-size .ec-store .form-control--small .form-control__prefix,.ec-size .ec-store .form-control--small .form-control__suffix {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--small .form-control__text,.ec-size .ec-store .form-control--small .form-control__prefix,.ec-size .ec-store .form-control--small .form-control__suffix {
                    height:24px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__text,.ec-size .ec-store .form-control--small .form-control__prefix,.ec-size .ec-store .form-control--small .form-control__suffix {
                    height:30px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--small .form-control__text,.ec-size .ec-store .form-control--small .form-control__prefix,.ec-size .ec-store .form-control--small .form-control__suffix {
                    min-height:24px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__text,.ec-size .ec-store .form-control--small .form-control__prefix,.ec-size .ec-store .form-control--small .form-control__suffix {
                    min-height:30px
                }
            }

            .ec-size .ec-store .form-control--small .form-control__ico-btn {
                width: 30px;
                min-width: 30px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--small .form-control__ico-btn {
                    width:24px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__ico-btn {
                    width:30px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--small .form-control__ico-btn {
                    min-width:24px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__ico-btn {
                    min-width:30px
                }
            }

            .ec-size .ec-store .form-control--small .form-control__icon {
                margin-right: 7px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--small .form-control__icon {
                    margin-right:5.6px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__icon {
                    margin-right:7px
                }
            }

            .ec-size .ec-store .form-control--small .form-control__prefix,.ec-size .ec-store .form-control--small .form-control__suffix {
                min-width: 28px;
                padding: 0 4px
            }

            .ec-size .ec-store .form-control--small .form-control__prefix::before,.ec-size .ec-store .form-control--small .form-control__suffix::before {
                top: 4px;
                bottom: 4px
            }

            .ec-size .ec-store .form-control--label .form-control__text {
                height: 50px;
                min-height: 50px;
                padding-top: 20px;
                padding-bottom: 5px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--label .form-control__text {
                    height:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--label .form-control__text {
                    height:50px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--label .form-control__text {
                    min-height:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--label .form-control__text {
                    min-height:50px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--label .form-control__text {
                    padding-top:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--label .form-control__text {
                    padding-top:20px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--label .form-control__text {
                    padding-bottom:4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--label .form-control__text {
                    padding-bottom:5px
                }
            }

            .ec-size .ec-store .form-control--label .form-control__placeholder {
                transition: opacity .1s ease-out 0s, transform .1s ease-out
            }

            .ec-size .ec-store .form-control--label .form-control__label,.ec-size .ec-store .form-control--label .form-control__placeholder {
                z-index: 1
            }

            .ec-size .ec-store .form-control--label .form-control__icon {
                margin-right: 15px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--label .form-control__icon {
                    margin-right:12px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--label .form-control__icon {
                    margin-right:15px
                }
            }

            .ec-size .ec-store .form-control--textarea .form-control__placeholder {
                display: block;
                padding-top: 10px;
                padding-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--textarea .form-control__placeholder {
                    padding-top:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--textarea .form-control__placeholder {
                    padding-top:10px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--textarea .form-control__placeholder {
                    padding-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--textarea .form-control__placeholder {
                    padding-bottom:10px
                }
            }

            .ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__ico-btn {
                left: 0
            }

            .ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__label {
                padding-left: 40px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__label {
                    padding-left:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend .form-control__label {
                    padding-left:40px
                }
            }

            .ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__label {
                padding-left: 30px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__label {
                    padding-left:24px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--small .form-control__label {
                    padding-left:30px
                }
            }

            .ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__label {
                padding-left: 50px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__label {
                    padding-left:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--prepend.form-control--large .form-control__label {
                    padding-left:50px
                }
            }

            .ec-size .ec-store .form-control--fieldset.form-control--append .form-control__ico-btn {
                right: 0
            }

            .ec-size .ec-store .form-control--fieldset.form-control--append .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--append .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--append .form-control__label {
                padding-right: 40px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--fieldset.form-control--append .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--append .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--append .form-control__label {
                    padding-right:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--fieldset.form-control--append .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--append .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--append .form-control__label {
                    padding-right:40px
                }
            }

            .ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__label {
                padding-right: 50px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__label {
                    padding-right:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__text,.ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__placeholder,.ec-size .ec-store .form-control--fieldset.form-control--append.form-control--large .form-control__label {
                    padding-right:50px
                }
            }

            .ec-size .ec-store .form-control--loading .form-control__ico-btn {
                cursor: default;
                pointer-events: none
            }

            .ec-size .ec-store .form-control--loading .form-control__loader {
                z-index: 3;
                opacity: 1;
                transition: opacity .2s linear 0s
            }

            .ec-size .ec-store .form-control__inner {
                display: flex;
                border-radius: 3px
            }

            .ec-size .ec-store .form-control__inner::before {
                content: "";
                display: block;
                position: absolute;
                z-index: 2;
                top: 1px;
                right: 0;
                bottom: 0;
                left: 0;
                border-radius: 3px;
                box-shadow: 0 1px 2px rgba(0,0,0,0.08) inset;
                transition: border-color .15s ease-out 0s;
                pointer-events: none
            }

            .ec-size .ec-store .form-control__field {
                position: relative;
                order: 1;
                width: 100%
            }

            .ec-size .ec-store .form-control__prefix,.ec-size .ec-store .form-control__suffix {
                display: none;
                position: relative;
                z-index: 1;
                flex-shrink: 0;
                align-items: center;
                justify-content: center;
                min-width: 32px;
                height: 40px;
                padding: 0 6px;
                border: 1px solid #517c9e;
                border-radius: 3px;
                background-color: #fbfbfb;
                color: inherit;
                white-space: nowrap;
                -webkit-backface-visibility: hidden;
                transition: color .15s ease-out 0s, border-color .15s ease-out 0s;
                line-height: 1.4;
                font-size: 14px;
                height: 40px;
                min-height: 40px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__prefix,.ec-size .ec-store .form-control__suffix {
                    font-size:16px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control__prefix,.ec-size .ec-store .form-control__suffix {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__prefix,.ec-size .ec-store .form-control__suffix {
                    height:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__prefix,.ec-size .ec-store .form-control__suffix {
                    height:40px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__prefix,.ec-size .ec-store .form-control__suffix {
                    min-height:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__prefix,.ec-size .ec-store .form-control__suffix {
                    min-height:40px
                }
            }

            .ec-size .ec-store .form-control__prefix::before,.ec-size .ec-store .form-control__suffix::before {
                content: "";
                display: block;
                position: absolute;
                top: 6px;
                bottom: 6px;
                border-width: 0 0 0 1px;
                border-style: solid;
                border-color: #e6e6e6;
                transition: border-color .15s ease-out 0s
            }

            .ec-size .ec-store .form-control__prefix {
                order: 0;
                border-right-width: 0;
                border-top-right-radius: 0;
                border-bottom-right-radius: 0;
                margin-right: -10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__prefix {
                    margin-right:-8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__prefix {
                    margin-right:-10px
                }
            }

            .ec-size .ec-store .form-control__prefix::before {
                right: 0
            }

            .ec-size .ec-store .form-control__suffix {
                order: 2;
                border-left-width: 0;
                border-top-left-radius: 0;
                border-bottom-left-radius: 0;
                margin-left: -10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__suffix {
                    margin-left:-8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__suffix {
                    margin-left:-10px
                }
            }

            .ec-size .ec-store .form-control__suffix::before {
                left: 0
            }

            .ec-size .ec-store .form-control__text,.ec-size .ec-store .form-control__textarea {
                position: relative;
                z-index: 1;
                width: 100%;
                border: 1px solid #517c9e;
                border-radius: 3px;
                outline: none;
                background-color: transparent;
                box-shadow: 0 1px 2px rgba(0,0,0,0.08) inset;
                color: #191919;
                transition: border-color .15s ease-out 0s;
                -webkit-appearance: none;
                line-height: 1.4;
                font-size: 14px;
                padding-left: 10px;
                padding-right: 10px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__text,.ec-size .ec-store .form-control__textarea {
                    font-size:16px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control__text,.ec-size .ec-store .form-control__textarea {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__text,.ec-size .ec-store .form-control__textarea {
                    padding-left:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__text,.ec-size .ec-store .form-control__textarea {
                    padding-left:10px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__text,.ec-size .ec-store .form-control__textarea {
                    padding-right:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__text,.ec-size .ec-store .form-control__textarea {
                    padding-right:10px
                }
            }

            .ec-size .ec-store .form-control__text:-webkit-autofill~.form-control__label,.ec-size .ec-store .form-control__textarea:-webkit-autofill~.form-control__label {
                opacity: 1;
                transform: translate3d(0, 0, 0)
            }

            .ec-size .ec-store .form-control__text:-webkit-autofill~.form-control__placeholder,.ec-size .ec-store .form-control__textarea:-webkit-autofill~.form-control__placeholder {
                opacity: 0;
                transform: translate3d(0, -5px, 0)
            }

            .ec-size .ec-store .form-control__text {
                padding-top: 5px;
                padding-bottom: 5px;
                height: 40px;
                min-height: 40px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__text {
                    padding-top:4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__text {
                    padding-top:5px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__text {
                    padding-bottom:4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__text {
                    padding-bottom:5px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__text {
                    height:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__text {
                    height:40px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__text {
                    min-height:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__text {
                    min-height:40px
                }
            }

            .ec-size .ec-store .form-control__textarea {
                display: block;
                resize: vertical;
                height: 80px;
                min-height: 80px;
                padding-top: 10px;
                padding-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__textarea {
                    height:64px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__textarea {
                    height:80px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__textarea {
                    min-height:64px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__textarea {
                    min-height:80px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__textarea {
                    padding-top:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__textarea {
                    padding-top:10px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__textarea {
                    padding-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__textarea {
                    padding-bottom:10px
                }
            }

            .ec-size .ec-store .form-control__label,.ec-size .ec-store .form-control__placeholder {
                position: absolute;
                color: inherit;
                white-space: nowrap;
                -webkit-backface-visibility: hidden;
                pointer-events: none
            }

            .ec-size .ec-store .form-control__label {
                display: block;
                right: 0;
                left: 1px;
                overflow: hidden;
                opacity: 1;
                border-left: 1px solid transparent;
                font-weight: 600;
                text-overflow: ellipsis;
                transform: translate3d(0, 0, 0);
                transition: transform .1s ease-out 0s, color .1s ease-out 0s, opacity .1s ease-out 0s;
                line-height: 1.4;
                font-size: 10px;
                padding-left: 10px;
                padding-right: 10px;
                bottom: 28px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__label {
                    font-size:11px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__label {
                    padding-left:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__label {
                    padding-left:10px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__label {
                    padding-right:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__label {
                    padding-right:10px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__label {
                    bottom:22.4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__label {
                    bottom:28px
                }
            }

            .ec-size .ec-store .form-control__placeholder {
                display: flex;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                opacity: 0;
                align-items: center;
                border: 1px solid transparent;
                transform: translate3d(0, -5px, 0);
                line-height: 1.4;
                font-size: 14px;
                padding-left: 10px;
                padding-right: 10px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__placeholder {
                    font-size:16px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control__placeholder {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__placeholder {
                    padding-left:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__placeholder {
                    padding-left:10px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__placeholder {
                    padding-right:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__placeholder {
                    padding-right:10px
                }
            }

            .ec-size .ec-store .form-control__placeholder-inner {
                overflow: hidden;
                width: 100%;
                text-overflow: ellipsis
            }

            .ec-size .ec-store .form-control__arrow,.ec-size .ec-store .form-control__icon {
                display: flex;
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                align-items: center;
                color: inherit;
                pointer-events: none;
                width: 25px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__arrow,.ec-size .ec-store .form-control__icon {
                    width:20px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__arrow,.ec-size .ec-store .form-control__icon {
                    width:25px
                }
            }

            .ec-size .ec-store .form-control__arrow svg,.ec-size .ec-store .form-control__icon svg {
                display: block;
                max-width: 20px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__arrow svg,.ec-size .ec-store .form-control__icon svg {
                    max-width:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__arrow svg,.ec-size .ec-store .form-control__icon svg {
                    max-width:20px
                }
            }

            .ec-size .ec-store .form-control__arrow svg path,.ec-size .ec-store .form-control__icon svg path {
                transition: fill .12s ease-out 0s
            }

            .ec-size .ec-store .form-control__icon {
                justify-content: flex-end;
                margin-right: 10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__icon {
                    margin-right:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__icon {
                    margin-right:10px
                }
            }

            .ec-size .ec-store .form-control__icon--success {
                display: none;
                color: #1cb920
            }

            .ec-size .ec-store .form-control__icon--fail {
                display: none;
                color: #e56464
            }

            .ec-size .ec-store .form-control__ico-btn {
                position: absolute;
                z-index: 1;
                top: 0;
                bottom: 0;
                border: none;
                outline: none;
                background: none;
                cursor: pointer;
                width: 40px;
                min-width: 40px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__ico-btn {
                    width:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__ico-btn {
                    width:40px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__ico-btn {
                    min-width:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__ico-btn {
                    min-width:40px
                }
            }

            .ec-size .ec-store .form-control__ico-btn .svg-icon {
                display: block;
                position: relative;
                width: 55%;
                height: 55%;
                margin: 0 auto
            }

            .ec-size .ec-store .form-control__ico-btn svg {
                display: block;
                position: absolute;
                width: auto;
                max-width: 100%;
                height: 100%;
                margin: 0 auto
            }

            .ec-size .ec-store .form-control__ico-btn svg path {
                transition: fill .12s ease-out 0s
            }

            .ec-size .ec-store .form-control__loader {
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                opacity: 0;
                background-size: 40px 40px;
                transition: opacity .2s linear .3s;
                animation: progress-bar-stripes .5s linear infinite;
                background-image: linear-gradient(45deg, rgba(251,251,251,0.06) 25%, rgba(25,25,25,0.06) 25%, rgba(25,25,25,0.06) 50%, rgba(251,251,251,0.06) 50%, rgba(251,251,251,0.06) 75%, rgba(25,25,25,0.06) 75%, rgba(25,25,25,0.06))
            }

            .ec-size .ec-store .form-control--focus .form-control__suggestions--filled {
                display: block
            }

            .ec-size .ec-store .form-control__suggestions {
                display: none;
                position: absolute;
                z-index: 1;
                top: 100%;
                overflow: auto;
                width: 100%;
                max-height: 250px;
                margin-top: -2px;
                border-top: 2px solid #1a7ac4;
                border-radius: 0 0 3px 3px;
                background-color: #fff;
                box-shadow: 0 1px 8px 0 rgba(0,0,0,0.14)
            }

            .ec-size .ec-store .form-control__suggestions:hover .form-control__suggestion {
                background-color: transparent
            }

            .ec-size .ec-store .form-control__suggestions:hover .form-control__suggestion:hover {
                background-color: #f2f2f2
            }

            .ec-size .ec-store .form-control__suggestion {
                display: flex;
                align-items: center;
                border-left: 1px solid transparent;
                color: #191919;
                cursor: pointer;
                line-height: 1.4;
                font-size: 14px;
                padding-left: 10px;
                padding-right: 10px;
                height: 40px;
                min-height: 40px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__suggestion {
                    font-size:16px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control__suggestion {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__suggestion {
                    padding-left:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__suggestion {
                    padding-left:10px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__suggestion {
                    padding-right:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__suggestion {
                    padding-right:10px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__suggestion {
                    height:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__suggestion {
                    height:40px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__suggestion {
                    min-height:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__suggestion {
                    min-height:40px
                }
            }

            .ec-size .ec-store .form-control__suggestion:hover,.ec-size .ec-store .form-control__suggestion--selected {
                background-color: #f2f2f2
            }

            .ec-size .ec-store .form-control--button {
                border-radius: 0;
                background-color: transparent
            }

            .ec-size .ec-store .form-control--button:hover,.ec-size .ec-store .form-control--button:active {
                background-color: transparent
            }

            .ec-size .ec-store .form-control--button .form-control__loader {
                transition: opacity .2s linear 0s
            }

            .ec-size .ec-store .form-control--large .form-control__button {
                font-size: 16px;
                min-height: 50px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--large .form-control__button {
                    font-size:18px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control--large .form-control__button {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--large .form-control__button {
                    min-height:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--large .form-control__button {
                    min-height:50px
                }
            }

            @media all and (-ms-high-contrast: none),(-ms-high-contrast: active) {
                .ec-size .ec-store .form-control--large .form-control__button {
                    height: 50px
                }
            }

            @media all and (-ms-high-contrast: none) and (min-width: 480px),screen and (-ms-high-contrast: active) and (min-width: 480px) {
                .ec-size .ec-store .form-control--large .form-control__button {
                    height:40px
                }
            }

            @media all and (-ms-high-contrast: none) and (min-width: 1024px),screen and (-ms-high-contrast: active) and (min-width: 1024px) {
                .ec-size .ec-store .form-control--large .form-control__button {
                    height:50px
                }
            }

            .ec-size .ec-store .form-control--small .form-control__button {
                font-size: 12px;
                min-height: 30px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__button {
                    font-size:14px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control--small .form-control__button {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--small .form-control__button {
                    min-height:24px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__button {
                    min-height:30px
                }
            }

            @media all and (-ms-high-contrast: none),(-ms-high-contrast: active) {
                .ec-size .ec-store .form-control--small .form-control__button {
                    height: 30px
                }
            }

            @media all and (-ms-high-contrast: none) and (min-width: 480px),screen and (-ms-high-contrast: active) and (min-width: 480px) {
                .ec-size .ec-store .form-control--small .form-control__button {
                    height:24px
                }
            }

            @media all and (-ms-high-contrast: none) and (min-width: 1024px),screen and (-ms-high-contrast: active) and (min-width: 1024px) {
                .ec-size .ec-store .form-control--small .form-control__button {
                    height:30px
                }
            }

            .ec-size .ec-store .form-control--primary .form-control__button {
                background-color: #333;
                color: #fff
            }

            .ec-size .ec-store .form-control--primary .form-control__button:focus {
                animation: button-primary-focus .5s linear 0s
            }

            .ec-size .ec-store .form-control--primary .form-control__button:hover {
                background-color: #595959
            }

            .ec-size .ec-store .form-control--primary .form-control__loader {
                background-image: linear-gradient(45deg, rgba(51,51,51,0.06) 25%, rgba(255,255,255,0.06) 25%, rgba(255,255,255,0.06) 50%, rgba(51,51,51,0.06) 50%, rgba(51,51,51,0.06) 75%, rgba(255,255,255,0.06) 75%, rgba(255,255,255,0.06))
            }

            .ec-size .ec-store .form-control--secondary .form-control__button {
                border-color: #ccc;
                background-color: #fff;
                color: #191919
            }

            .ec-size .ec-store .form-control--secondary .form-control__button:focus {
                animation: button-secondary-focus .5s linear 0s
            }

            .ec-size .ec-store .form-control--secondary .form-control__button:hover {
                border-color: #b3b3b3;
                background-color: #f2f2f2
            }

            .ec-size .ec-store .form-control--secondary .form-control__loader {
                background-image: linear-gradient(45deg, rgba(255,255,255,0.06) 25%, rgba(25,25,25,0.06) 25%, rgba(25,25,25,0.06) 50%, rgba(255,255,255,0.06) 50%, rgba(255,255,255,0.06) 75%, rgba(25,25,25,0.06) 75%, rgba(25,25,25,0.06))
            }

            .ec-size .ec-store .form-control--disabled .form-control__button {
                opacity: .5
            }

            .ec-size .ec-store .form-control--bounce .form-control__button-text,.ec-size .ec-store .form-control--bounce .form-control__button-svg {
                display: inline-block;
                position: relative;
                animation: bounce-x .8s ease forwards 0s
            }

            .ec-size .ec-store .form-control--flexible .form-control__button {
                padding: 0 .8em
            }

            .ec-size .ec-store .form-control:not(.form-control--loading) .form-control__button {
                position: relative;
                z-index: 1
            }

            .ec-size .ec-store .form-control__button {
                display: inline-block;
                width: 100%;
                padding: 0 1.8em;
                border: 1px solid transparent;
                border-radius: 3px;
                outline: none;
                box-shadow: 0 0 0 rgba(0,0,0,0);
                font-weight: 600;
                line-height: normal;
                text-align: center;
                word-wrap: break-word;
                transition: background-color .12s ease-out 0s, color .12s ease-out 0s, border-color .12s ease-out 0s, box-shadow .12s ease-out 0s, transform .05s ease-out 0s, opacity .2s ease-out 0s;
                cursor: pointer;
                -webkit-tap-highlight-color: transparent;
                font-size: 14px;
                min-height: 40px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__button {
                    font-size:16px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control__button {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__button {
                    min-height:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__button {
                    min-height:40px
                }
            }

            @media all and (-ms-high-contrast: none),(-ms-high-contrast: active) {
                .ec-size .ec-store .form-control__button {
                    height: 40px
                }
            }

            @media all and (-ms-high-contrast: none) and (min-width: 480px),screen and (-ms-high-contrast: active) and (min-width: 480px) {
                .ec-size .ec-store .form-control__button {
                    height:32px
                }
            }

            @media all and (-ms-high-contrast: none) and (min-width: 1024px),screen and (-ms-high-contrast: active) and (min-width: 1024px) {
                .ec-size .ec-store .form-control__button {
                    height:40px
                }
            }

            .ec-size .ec-store .form-control__button:hover {
                box-shadow: 0 1px 2px rgba(0,0,0,0.15)
            }

            .ec-size .ec-store .form-control__button:active {
                box-shadow: 0 0 0 rgba(0,0,0,0);
                transform: translate3d(0, 1px, 0)
            }

            .ec-size .ec-store .form-control__button .svg-icon {
                position: absolute;
                width: 1.8em;
                padding: 2px 4px
            }

            .ec-size .ec-store .form-control__button .svg-icon svg {
                opacity: .9;
                width: 100%;
                height: 100%;
                vertical-align: top
            }

            .ec-size .ec-store .form-control__button--icon-prepend .form-control__button-svg {
                float: left
            }

            .ec-size .ec-store .form-control__button--icon-prepend .form-control__button-text {
                padding-left: 1.2em
            }

            .ec-size .ec-store .form-control__button--icon-append .form-control__button-svg {
                float: right
            }

            .ec-size .ec-store .form-control__button--icon-append .form-control__button-text {
                padding-right: 1.2em
            }

            .ec-size .ec-store .form-control__button--icon-prepend .form-control__button-svg,.ec-size .ec-store .form-control__button--icon-append .form-control__button-svg {
                display: inline-block;
                width: 1.8em;
                margin: 0 -1em;
                text-align: left
            }

            .ec-size .ec-store .form-control__button--icon-prepend .form-control__button-svg::after,.ec-size .ec-store .form-control__button--icon-append .form-control__button-svg::after {
                content: " "
            }

            .ec-size .ec-store .form-control__button--icon-prepend .svg-icon,.ec-size .ec-store .form-control__button--icon-append .svg-icon {
                top: 49%;
                height: 1.8em;
                margin-top: -.86em;
                padding: 0
            }

            .ec-size .ec-store .form-control__button--icon-prepend .svg-icon2,.ec-size .ec-store .form-control__button--icon-append .svg-icon2 {
                height: 1.8em;
                margin-top: -.86em;
                padding: 0
            }

            .ec-size .ec-store .form-control__button--icon-center .form-control__button-svg {
                display: inline-block;
                position: absolute;
                top: 0;
                left: 50%;
                width: 1.8em;
                height: 100%;
                margin-left: -.9em
            }

            .ec-size .ec-store .form-control__button--icon-center .svg-icon {
                top: 0;
                left: 0;
                height: 100%
            }

            .ec-size .ec-store .form-control__button--icon-only {
                padding-right: 1em;
                padding-left: 1em
            }

            .ec-size .ec-store .form-control__button--icon-only .form-control__button-text {
                display: none
            }

            .ec-size .ec-store .form-control__button-text {
                display: inline-block;
                max-width: 100%
            }

            .ec-size .ec-store a.form-control__button {
                display: flex;
                align-items: center;
                justify-content: center
            }

            .ec-size .ec-store .form-control--animated .form-control__button-text,.ec-size .ec-store .form-control--animated .svg-line-check {
                opacity: 0
            }

            .ec-size .ec-store .form-control--animated .form-control__button-svg {
                opacity: 1
            }

            .ec-size .ec-store .form-control--animated.form-control--done .form-control__button-text,.ec-size .ec-store .form-control--animated.form-control--done .form-control__button-svg {
                opacity: 1;
                transition: opacity .1s linear 1.5s
            }

            .ec-size .ec-store .form-control--animated.form-control--done .form-control__button-svg {
                opacity: 0
            }

            .ec-size .ec-store .form-control--animated.form-control--done .svg-line-check {
                animation: form-control-check .25s ease-in-out forwards .05s
            }

            .ec-size .ec-store .form-control--select.form-control--empty .form-control__placeholder {
                opacity: 1;
                transform: translate3d(0, 0, 0)
            }

            .ec-size .ec-store .form-control--select.form-control--empty .form-control__label {
                opacity: 0;
                transform: translate3d(0, 5px, 0)
            }

            .ec-size .ec-store .form-control--select.form-control--disabled {
                color: gray
            }

            .ec-size .ec-store .form-control--select .form-control__text,.ec-size .ec-store .form-control--select .form-control__placeholder {
                padding-right: 30px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--select .form-control__text,.ec-size .ec-store .form-control--select .form-control__placeholder {
                    padding-right:24px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--select .form-control__text,.ec-size .ec-store .form-control--select .form-control__placeholder {
                    padding-right:30px
                }
            }

            .ec-size .ec-store .form-control--select-inline {
                border-radius: 0;
                background-color: transparent;
                color: inherit;
                vertical-align: baseline;
                white-space: nowrap;
                cursor: pointer
            }

            .ec-size .ec-store .form-control--select-inline:hover {
                background-color: transparent
            }

            .ec-size .ec-store .form-control--select-inline:hover .form-control__select-text,.ec-size .ec-store .form-control--select-inline:hover .form-control__arrow {
                color: #115080
            }

            .ec-size .ec-store .form-control--select-inline.form-control--opened .form-control__arrow {
                transform: rotate(180deg)
            }

            .ec-size .ec-store .form-control--select-inline .form-control__arrow {
                display: inline-block;
                position: relative;
                top: -.1em;
                width: .8em;
                height: .8em;
                text-align: center;
                vertical-align: middle;
                transform-origin: 50% 50%;
                transition: transform .2s ease 0s, color .12s ease-out 0s
            }

            .ec-size .ec-store .form-control--select-inline .form-control__arrow svg {
                display: block;
                width: 100%;
                max-width: none;
                height: auto
            }

            .ec-size .ec-store .form-control--select-inline:focus-visible .form-control__arrow,.ec-size .ec-store .form-control--select-inline .form-control__select:focus-visible~.form-control__arrow {
                outline: auto 5px -webkit-focus-ring-color
            }

            .ec-size .ec-store .form-control--select-inline .form-control__select-text {
                display: inline;
                padding-right: .35em;
                word-wrap: break-word;
                white-space: normal
            }

            .ec-size .ec-store .form-control__select {
                position: absolute;
                z-index: 2;
                top: 0;
                left: 0;
                opacity: 0;
                width: 100%;
                height: 100%;
                padding: 4px 5px;
                cursor: pointer;
                -webkit-appearance: none
            }

            .ec-size .ec-store .form-control__select option {
                padding: 4px 5px;
                background-color: #fff;
                color: #000
            }

            .ec-size .ec-store .form-control__select-text {
                display: inline-block;
                padding-right: 30px;
                color: inherit;
                font-size: inherit;
                -webkit-font-smoothing: auto;
                line-height: inherit;
                transition: color .12s ease-out 0s;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none
            }

            .ec-size .ec-store .form-control--checkbox {
                display: flex;
                align-items: baseline;
                border-radius: 0;
                background-color: transparent;
                color: inherit;
                font-size: inherit;
                line-height: 1.4em;
                margin-bottom: 5px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--checkbox {
                    margin-bottom:4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--checkbox {
                    margin-bottom:5px
                }
            }

            .ec-size .ec-store .form-control--checkbox:hover,.ec-size .ec-store .form-control--checkbox:active {
                background-color: transparent
            }

            .ec-size .ec-store .form-control--checkbox:hover .form-control__checkbox-view::after,.ec-size .ec-store .form-control--checkbox:active .form-control__checkbox-view::after {
                border-color: #1a7ac4
            }

            .ec-size .ec-store .form-control--checkbox:hover .form-control__checkbox:checked~.form-control__checkbox-view::after,.ec-size .ec-store .form-control--checkbox:active .form-control__checkbox:checked~.form-control__checkbox-view::after {
                border-color: #115080;
                background-color: #115080
            }

            .ec-size .ec-store .form-control--checkbox label {
                cursor: pointer;
                -webkit-tap-highlight-color: transparent
            }

            .ec-size .ec-store .form-control--checkbox.form-control--disabled {
                opacity: .6;
                cursor: default;
                pointer-events: none
            }

            .ec-size .ec-store .form-control--checkbox.form-control--disabled label {
                cursor: default
            }

            .ec-size .ec-store .form-control--checkbox.form-control--error {
                color: #e56464
            }

            .ec-size .ec-store .form-control--large .form-control__checkbox-wrap {
                top: 4px;
                flex: 0 0 20px;
                width: 20px;
                height: 20px
            }

            .ec-size .ec-store .form-control--small .form-control__checkbox-wrap {
                top: 2px;
                flex: 0 0 14px;
                width: 14px;
                height: 14px
            }

            .ec-size .ec-store .form-control--no-animation .form-control__checkbox-view::before {
                display: none
            }

            .ec-size .ec-store .form-control--checkbox-colored .form-control__checkbox {
                display: none
            }

            .ec-size .ec-store .form-control--checkbox-colored .form-control__inline-label {
                position: relative;
                border-radius: 2px;
                outline: none;
                background-size: cover;
                transition: background-color .12s ease-out 0s, color .12s ease-out 0s, border-color .12s ease-out 0s, box-shadow .12s ease-out 0s, transform .05s ease-out 0s, opacity .2s ease-out 0s;
                -webkit-tap-highlight-color: transparent;
                height: 40px;
                width: 40px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--checkbox-colored .form-control__inline-label {
                    height:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--checkbox-colored .form-control__inline-label {
                    height:40px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--checkbox-colored .form-control__inline-label {
                    width:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--checkbox-colored .form-control__inline-label {
                    width:40px
                }
            }

            .ec-size .ec-store .form-control--checkbox-colored .form-control__inline-label:hover {
                box-shadow: 0 1px 2px rgba(0,0,0,0.15)
            }

            .ec-size .ec-store .form-control--checkbox-colored .form-control__inline-label:active {
                box-shadow: 0 0 0 rgba(0,0,0,0);
                transform: translate3d(0, 1px, 0)
            }

            .ec-size .ec-store .form-control--checkbox-colored .form-control__inline-label label {
                display: block;
                position: absolute;
                width: 100%;
                height: 100%;
                border: 2px solid transparent;
                border-radius: 2px;
                transition: border-color .12s ease-out 0s, box-shadow .12s ease-out 0s;
                cursor: pointer
            }

            .ec-size .ec-store .form-control--checkbox-colored .form-control__checkbox:checked~.form-control__inline-label label {
                border-color: #1a7ac4;
                box-shadow: 0 0 0 2px #fff inset
            }

            .ec-size .ec-store .form-control--checkbox-colored.form-control--checkbox-bordered .form-control__checkbox:not(:checked)~.form-control__inline-label label {
                border: 1px solid #ccc
            }

            .ec-size .ec-store .form-control--checkbox-button.form-control--disabled .form-control__inline-label label {
                opacity: .5
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                width: 100%;
                padding: 0 .8em;
                border: 1px solid transparent;
                border-radius: 2px;
                outline: none;
                background-position: -20%;
                box-shadow: 0 0 0 rgba(0,0,0,0);
                font-weight: 600;
                text-align: center;
                word-wrap: break-word;
                transition: background-color .12s ease-out 0s, background-position .5s ease-out 0s, color .12s ease-out 0s, border-color .12s ease-out 0s, box-shadow .12s ease-out 0s, opacity .2s ease-out 0s;
                cursor: pointer;
                -webkit-tap-highlight-color: transparent;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
                line-height: 1.4;
                font-size: 14px;
                min-height: 50px;
                min-width: 50px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    font-size:16px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    font-size:16px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    min-height:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    min-height:50px
                }
            }

            @media all and (-ms-high-contrast: none),(-ms-high-contrast: active) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    height: 50px
                }
            }

            @media all and (-ms-high-contrast: none) and (min-width: 480px),screen and (-ms-high-contrast: active) and (min-width: 480px) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    height:40px
                }
            }

            @media all and (-ms-high-contrast: none) and (min-width: 1024px),screen and (-ms-high-contrast: active) and (min-width: 1024px) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    height:50px
                }
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    min-width:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label {
                    min-width:50px
                }
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label:hover {
                border-color: #b3b3b3;
                background-color: #f2f2f2;
                box-shadow: 0 3px 3px -2px rgba(0,0,0,0.13),0 6px 8px 1px rgba(0,0,0,0.1),0 2px 11px 2px rgba(0,0,0,0.08)
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__checkbox,.ec-size .ec-store .form-control--checkbox-button .form-control__radio {
                z-index: -1
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__checkbox:checked~.form-control__inline-label label,.ec-size .ec-store .form-control--checkbox-button .form-control__radio:checked~.form-control__inline-label label {
                background-image: linear-gradient(135deg, #1a7ac4 30%, rgba(255,255,255,0.3) 50%, #1a7ac4 50%);
                background-position: -150%;
                background-size: 400%
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__radio:checked~.form-control__inline-label label {
                cursor: default;
                pointer-events: none
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label,.ec-size .ec-store .form-control--checkbox-button .form-control__checkbox:checked~.form-control__inline-label label:active,.ec-size .ec-store .form-control--checkbox-button .form-control__radio:checked~.form-control__inline-label label:active {
                border-color: #ccc;
                background-color: #fff;
                background-image: none;
                color: #191919
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label .option-surcharge,.ec-size .ec-store .form-control--checkbox-button .form-control__checkbox:checked~.form-control__inline-label label:active .option-surcharge,.ec-size .ec-store .form-control--checkbox-button .form-control__radio:checked~.form-control__inline-label label:active .option-surcharge {
                color: #757575
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label:active,.ec-size .ec-store .form-control--checkbox-button .form-control__checkbox:checked~.form-control__inline-label label,.ec-size .ec-store .form-control--checkbox-button .form-control__radio:checked~.form-control__inline-label label {
                border-color: #115080;
                background-color: #1a7ac4;
                color: #fff
            }

            .ec-size .ec-store .form-control--checkbox-button .form-control__inline-label label:active .option-surcharge,.ec-size .ec-store .form-control--checkbox-button .form-control__checkbox:checked~.form-control__inline-label label .option-surcharge,.ec-size .ec-store .form-control--checkbox-button .form-control__radio:checked~.form-control__inline-label label .option-surcharge {
                color: inherit
            }

            .ec-size .ec-store .form-control--checkbox-button .option-surcharge {
                line-height: 1.4;
                font-size: 11px;
                font-weight: 600;
                line-height: 1.2em
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--checkbox-button .option-surcharge {
                    font-size:12px
                }
            }

            .ec-size .ec-store .form-control--checkbox-button .option-surcharge__bracket {
                display: none
            }

            .ec-size .ec-store .form-control--checkbox-button .option-surcharge__value {
                padding-right: 3px
            }

            .ec-size .ec-store .form-control__checkbox {
                position: absolute;
                z-index: 2;
                top: 0;
                left: 0;
                opacity: 0;
                width: 100%;
                height: 100%;
                cursor: pointer
            }

            .ec-size .ec-store .form-control__checkbox:focus~.form-control__checkbox-view::after {
                border-color: #1a7ac4
            }

            .ec-size .ec-store .form-control__checkbox:focus:checked~.form-control__checkbox-view::after {
                border-color: #115080;
                background-color: #115080
            }

            .ec-size .ec-store .form-control__checkbox:checked~.form-control__checkbox-view::after {
                border-color: #1a7ac4;
                background-color: #1a7ac4;
                color: #191919
            }

            .ec-size .ec-store .form-control__checkbox:checked~.form-control__checkbox-view::before {
                visibility: hidden;
                opacity: 0;
                width: 0;
                transform: scale(3);
                transition: transform .3s ease 0s, opacity .3s ease 0s, visibility 0s linear .3s, width 0s linear .3s
            }

            .ec-size .ec-store .form-control__checkbox:checked~.form-control__checkbox-view svg {
                opacity: 1;
                transform: scale(1)
            }

            .ec-size .ec-store .form-control__checkbox-wrap {
                position: relative;
                top: 2px;
                box-sizing: content-box;
                flex: 0 0 16px;
                width: 16px;
                height: 16px;
                padding: 0 7px 0 1px;
                color: #fff
            }

            .ec-size .ec-store .form-control__checkbox-view,.ec-size .ec-store .form-control__checkbox-view::before,.ec-size .ec-store .form-control__checkbox-view::after {
                position: relative;
                box-sizing: border-box;
                width: 100%;
                height: 100%
            }

            .ec-size .ec-store .form-control__checkbox-view::before,.ec-size .ec-store .form-control__checkbox-view::after {
                content: '';
                display: block;
                position: absolute;
                top: 0;
                left: 0;
                border-radius: 3px
            }

            .ec-size .ec-store .form-control__checkbox-view::before {
                visibility: visible;
                opacity: .2;
                background-color: #000;
                will-change: transform, opacity, visibility
            }

            .ec-size .ec-store .form-control__checkbox-view::after {
                border: 1px solid #517c9e;
                background-color: #f2f2f2;
                color: transparent;
                transition: background-color .1s ease 0s, border-color .1s ease 0s, color .1s ease 0s;
                will-change: transform, border-color, color
            }

            .ec-size .ec-store .form-control__checkbox-view svg {
                display: block;
                position: absolute;
                z-index: 1;
                top: 3px;
                left: 3px;
                opacity: 0;
                width: calc(100% - 6px);
                height: calc(100% - 6px);
                transform: scale(0.8);
                transition: transform .2s ease .1s, opacity .2s ease .1s;
                will-change: transform, opacity
            }

            .ec-size .ec-store .form-control__black-checkbox {
                display: flex;
                align-items: center;
                cursor: pointer;
                background: transparent;
                color: #191919;
                padding-top: 10px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__black-checkbox {
                    padding-top:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__black-checkbox {
                    padding-top:10px
                }
            }

            .ec-size .ec-store .form-control__black-checkbox.form-control--disabled {
                cursor: default;
                pointer-events: none
            }

            .ec-size .ec-store .form-control__black-checkbox.form-control--disabled .form-control__black-checkbox-input {
                opacity: .6
            }

            .ec-size .ec-store .form-control__black-checkbox-input {
                width: 16px;
                height: 16px;
                cursor: pointer;
                accent-color: #000
            }

            .ec-size .ec-store .form-control__black-checkbox-label {
                padding-left: 10px;
                font-weight: 600
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control__black-checkbox-label {
                    padding-left:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control__black-checkbox-label {
                    padding-left:10px
                }
            }

            .ec-size .ec-store .form-control--radio {
                display: flex;
                align-items: baseline;
                border-radius: 0;
                background-color: transparent;
                color: #191919;
                font-size: inherit;
                line-height: 1.4em;
                margin-bottom: 5px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--radio {
                    margin-bottom:4px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--radio {
                    margin-bottom:5px
                }
            }

            .ec-size .ec-store .form-control--radio:hover,.ec-size .ec-store .form-control--radio:active {
                background-color: transparent
            }

            .ec-size .ec-store .form-control--radio:hover .form-control__radio-view::after,.ec-size .ec-store .form-control--radio:active .form-control__radio-view::after {
                border-color: #1a7ac4
            }

            .ec-size .ec-store .form-control--radio:hover .form-control__radio:checked+.form-control__radio-view::after,.ec-size .ec-store .form-control--radio:active .form-control__radio:checked+.form-control__radio-view::after {
                border-color: #115080;
                background-color: #115080
            }

            .ec-size .ec-store .form-control--radio label {
                cursor: pointer;
                -webkit-tap-highlight-color: transparent
            }

            .ec-size .ec-store .form-control--radio.form-control--disabled {
                opacity: .6;
                cursor: default;
                pointer-events: none
            }

            .ec-size .ec-store .form-control--radio.form-control--disabled label {
                cursor: default
            }

            .ec-size .ec-store .form-control--radio.form-control--error {
                color: #e56464
            }

            .ec-size .ec-store .form-control--large .form-control__radio-wrap {
                top: 5px;
                flex: 0 0 24px;
                width: 24px;
                height: 24px
            }

            .ec-size .ec-store .form-control--small .form-control__radio-wrap {
                top: 2px;
                flex: 0 0 14px;
                width: 14px;
                height: 14px
            }

            .ec-size .ec-store .form-control--no-animation .form-control__radio-view::before {
                display: none
            }

            .ec-size .ec-store .form-control__radio {
                position: absolute;
                z-index: 2;
                top: 0;
                left: 0;
                opacity: 0;
                width: 100%;
                height: 100%;
                cursor: pointer
            }

            .ec-size .ec-store .form-control__radio:focus+.form-control__radio-view::after {
                border-color: #1a7ac4
            }

            .ec-size .ec-store .form-control__radio:focus:checked+.form-control__radio-view::after {
                border-color: #115080;
                background-color: #115080
            }

            .ec-size .ec-store .form-control__radio:checked+.form-control__radio-view::before {
                visibility: hidden;
                opacity: 0;
                width: 0;
                transform: scale(3);
                transition: transform .3s ease 0s, opacity .3s ease 0s, visibility 0s linear .3s, width 0s linear .3s
            }

            .ec-size .ec-store .form-control__radio:checked+.form-control__radio-view::after {
                border-color: #1a7ac4;
                background-color: #1a7ac4
            }

            .ec-size .ec-store .form-control__radio:checked+.form-control__radio-view .form-control__radio-view-inner {
                transform: scale(0.4)
            }

            .ec-size .ec-store .form-control__radio-wrap {
                position: relative;
                top: 3px;
                box-sizing: content-box;
                flex: 0 0 18px;
                width: 18px;
                height: 18px;
                padding: 0 7px 0 1px
            }

            .ec-size .ec-store .form-control__radio-view,.ec-size .ec-store .form-control__radio-view::before,.ec-size .ec-store .form-control__radio-view::after {
                position: relative;
                box-sizing: border-box;
                width: 100%;
                height: 100%
            }

            .ec-size .ec-store .form-control__radio-view::before,.ec-size .ec-store .form-control__radio-view::after {
                content: '';
                display: block;
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%
            }

            .ec-size .ec-store .form-control__radio-view::before {
                visibility: visible;
                opacity: .2;
                border-radius: 50%;
                background-color: #000;
                will-change: transform, opacity, visibility
            }

            .ec-size .ec-store .form-control__radio-view::after {
                border: 1px solid #517c9e;
                border-radius: 50%;
                background-color: #f2f2f2;
                color: #191919;
                transition: border-color .1s linear 0s
            }

            .ec-size .ec-store .form-control__radio-view-inner {
                position: absolute;
                z-index: 1;
                top: 1px;
                left: 1px;
                width: calc(100% - 2px);
                height: calc(100% - 2px);
                border-radius: 50%;
                background-color: #fff;
                transition: transform .2s ease 0s;
                will-change: transform
            }

            .ec-size .ec-store .form-control--file {
                display: block;
                position: relative;
                border-radius: 0;
                background-color: transparent
            }

            .ec-size .ec-store .form-control--file:hover,.ec-size .ec-store .form-control--file:active {
                background-color: transparent
            }

            .ec-size .ec-store .form-control--file.form-control--has-file .form-control {
                display: none
            }

            .ec-size .ec-store .form-control--file.form-control--has-file .form-control__add-more {
                display: inline-block
            }

            .ec-size .ec-store .form-control--file.form-control--has-file .form-control__cards {
                display: block
            }

            .ec-size .ec-store .form-control--file.form-control--file-limit .form-control__add-more {
                display: none
            }

            .ec-size .ec-store .form-control--file .form-control__add-more {
                display: none;
                position: relative;
                line-height: 1.4;
                font-size: 12px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--file .form-control__add-more {
                    font-size:14px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form-control--file .form-control__add-more {
                    font-size:16px
                }
            }

            .ec-size .ec-store .form-control--file .form-control__button {
                position: relative
            }

            .ec-size .ec-store .form-control--file .ec-preloader {
                display: none
            }

            .ec-size .ec-store .form-control__cards {
                display: none;
                overflow: hidden
            }

            .ec-size .ec-store input[type=file].form-control__file {
                position: absolute;
                z-index: 2;
                top: 0;
                left: 0;
                overflow: hidden;
                opacity: 0;
                width: 100%;
                height: 100%;
                cursor: pointer
            }

            .ec-size .ec-store .file-card {
                display: block;
                position: relative;
                float: left;
                overflow: hidden;
                width: 104px;
                height: 72px;
                margin: 0 16px 16px 0;
                background-repeat: no-repeat;
                background-position: center center;
                background-size: cover;
                text-align: center;
                cursor: pointer
            }

            .ec-size .ec-store .file-card::after {
                content: "";
                display: block;
                position: absolute;
                z-index: 1;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                background-color: rgba(255,255,255,0);
                transition: background-color .1s linear 0s
            }

            .ec-size .ec-store .file-card--doc {
                box-shadow: 0 0 0 1px #e6e6e6 inset
            }

            .ec-size .ec-store .file-card--doc .file-card__size,.ec-size .ec-store .file-card--doc .file-card__name {
                display: block
            }

            .ec-size .ec-store .file-card--image:hover::after {
                background-color: rgba(255,255,255,0.8)
            }

            .ec-size .ec-store .file-card--loading::after {
                background-color: rgba(255,255,255,0.8)
            }

            .ec-size .ec-store .file-card--loading .ec-preloader {
                display: block
            }

            .ec-size .ec-store .file-card .ec-preloader {
                position: absolute;
                z-index: 2;
                top: 50%;
                left: 50%;
                margin: -15px 0 0 -15px;
                color: #757575
            }

            .ec-size .ec-store .file-card__name {
                display: none;
                overflow: hidden;
                margin: 32px 12px -3px;
                text-overflow: ellipsis;
                white-space: nowrap;
                line-height: 1.4;
                font-size: 11px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .file-card__name {
                    font-size:12px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .file-card__name {
                    font-size:16px
                }
            }

            .ec-size .ec-store .file-card__size {
                display: none;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                line-height: 1.4;
                font-size: 11px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .file-card__size {
                    font-size:12px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .file-card__size {
                    font-size:16px
                }
            }

            .ec-size .ec-store .file-card__size--error {
                color: #e56464
            }

            .ec-size .ec-store .file-card__cross {
                position: absolute;
                z-index: 3;
                top: 1px;
                right: 1px
            }

            .ec-size .ec-store .file-card__cross svg {
                display: block;
                width: 14px;
                height: 14px;
                margin: 5px
            }

            .ec-size .ec-store .form-control--datepicker .form-control__text,.ec-size .ec-store .form-control--datepicker .form-control__placeholder {
                cursor: text;
                padding-right: 30px
            }

            @media screen and (min-width: 480px) {
                .ec-size .ec-store .form-control--datepicker .form-control__text,.ec-size .ec-store .form-control--datepicker .form-control__placeholder {
                    padding-right:24px
                }
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form-control--datepicker .form-control__text,.ec-size .ec-store .form-control--datepicker .form-control__placeholder {
                    padding-right:30px
                }
            }

            .ec-pika-single {
                display: block;
                position: relative;
                z-index: 9999999;
                box-sizing: border-box;
                border: 1px solid #e6e6e6;
                background: #fff;
                box-shadow: 0 5px 15px -5px rgba(0,0,0,0.5);
                color: #191919
            }

            @media screen and (max-width: 479px) {
                .ec-pika-single {
                    left:0 !important;
                    box-sizing: border-box;
                    width: 100%;
                    padding: 10px
                }
            }

            .ec-pika-single::before,.ec-pika-single::after {
                content: " ";
                display: table
            }

            .ec-pika-single::after {
                clear: both
            }

            .ec-pika-single.ec-pika--hidden {
                display: none
            }

            .ec-pika-single.ec-pika--bound {
                position: absolute
            }

            .ec-pika-single * {
                box-sizing: border-box;
                opacity: 1;
                min-width: 0;
                max-width: none;
                min-height: 0;
                max-height: none;
                margin: 0;
                padding: 0;
                background: none;
                box-shadow: none;
                letter-spacing: normal;
                word-spacing: normal;
                transform: none;
                transform-origin: center center;
                transition: none
            }

            .ec-pika-lendar {
                float: left;
                margin: 20px 10px 8px
            }

            .ec-pika-time-container {
                clear: both;
                margin: 8px
            }

            .ec-pika-time-container .ec-store {
                display: flex;
                padding: 0 10px
            }

            .ec-pika-time-container .ec-store .form-control {
                flex-grow: 1
            }

            .ec-pika-time-container .ec-store .form-control--button {
                flex-grow: 0;
                flex-shrink: 0;
                margin-left: 8px
            }

            .ec-pika-time-container .ec-store .form-control.form-control--flexible {
                width: auto
            }

            .ec-pika-time-container .ec-store .form-control__select {
                font-size: 12px
            }

            .ec-pika-time-container .ec-store .form-control__text {
                height: 32px;
                font-size: 14px
            }

            .ec-pika-lendar,.ec-pika-time-container {
                width: 310px
            }

            @media screen and (max-width: 479px) {
                .ec-pika-lendar,.ec-pika-time-container {
                    width:100%;
                    margin-right: 0;
                    margin-left: 0
                }
            }

            .ec-pika-button--bound.ec-pika-button--hidden {
                display: none
            }

            .ec-pika-title {
                position: relative;
                text-align: center
            }

            .ec-pika-title select {
                position: absolute;
                z-index: 9998;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                opacity: 0;
                height: auto;
                padding: 0 3px;
                border: 0;
                font-size: inherit;
                cursor: pointer
            }

            .ec-pika-label {
                display: inline-block;
                position: relative;
                z-index: 9999;
                overflow: hidden;
                height: 30px;
                margin: 0;
                padding: 0 3px;
                background-color: #fff;
                font-size: 14px;
                font-weight: 600;
                line-height: 30px
            }

            .ec-pika-label,.ec-pika-label:visited {
                color: #191919;
                transition: color .12s ease-out 0s
            }

            .ec-pika-label:hover,.ec-pika-label:active {
                color: #1a7ac4
            }

            .ec-pika-prev,.ec-pika-next {
                display: block;
                position: relative;
                overflow: hidden;
                opacity: .5;
                width: 40px;
                height: 30px;
                border: 0;
                outline: none;
                background-color: transparent;
                background-repeat: no-repeat;
                background-position: center center;
                background-size: 15px;
                text-indent: 40px;
                white-space: nowrap;
                cursor: pointer
            }

            .ec-pika-prev:hover,.ec-pika-next:hover {
                opacity: 1
            }

            .ec-pika-prev.ec-pika--disabled,.ec-pika-next.ec-pika--disabled {
                opacity: .2;
                cursor: default
            }

            .ec-pika-prev,.ec-pika--rtl .ec-pika-next {
                float: left;
                background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAeCAYAAAAsEj5rAAAAUklEQVR42u3VMQoAIBADQf8Pgj+OD9hG2CtONJB2ymQkKe0HbwAP0xucDiQWARITIDEBEnMgMQ8S8+AqBIl6kKgHiXqQqAeJepBo/z38J/U0uAHlaBkBl9I4GwAAAABJRU5ErkJggg==");
                background-position: center left
            }

            .ec-pika-next,.ec-pika--rtl .ec-pika-prev {
                float: right;
                background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAeCAYAAAAsEj5rAAAAU0lEQVR42u3VOwoAMAgE0dwfAnNjU26bYkBCFGwfiL9VVWoO+BJ4Gf3gtsEKKoFBNTCoCAYVwaAiGNQGMUHMkjGbgjk2mIONuXo0nC8XnCf1JXgArVIZAQh5TKYAAAAASUVORK5CYII=");
                background-position: center right
            }

            .ec-pika-select {
                display: inline-block
            }

            .ec-pika-table {
                width: 100%;
                border-spacing: 0;
                border-collapse: collapse;
                border: 0
            }

            .ec-pika-table th,.ec-pika-table td {
                width: 14.285714285714286%;
                padding: 0
            }

            .ec-pika-table th {
                font-size: 12px;
                font-weight: 400;
                line-height: 25px;
                text-align: center
            }

            .ec-pika-table abbr {
                border-bottom: none;
                text-decoration: none;
                cursor: default
            }

            .ec-pika-button {
                display: block;
                box-sizing: border-box;
                width: 100%;
                margin: 0;
                padding: 8px;
                border: 0;
                border-radius: 2px;
                outline: none;
                background: #fff;
                color: #191919;
                font-size: 14px;
                line-height: 15px;
                text-align: center;
                transition: background-color .1s linear 0s, color .1s linear 0s;
                cursor: pointer
            }

            .ec-pika-button--today .ec-pika-button {
                color: #1a7ac4;
                font-weight: 600
            }

            .ec-pika-button--selected .ec-pika-button {
                background: #1a7ac4;
                color: #fff
            }

            .ec-pika-button--disabled .ec-pika-button,.ec-pika-button--outside-current-month .ec-pika-button {
                opacity: .3;
                color: #757575;
                cursor: default;
                pointer-events: none
            }

            td .ec-pika-button:hover {
                background: #1a7ac4;
                color: #fff
            }

            .ec-pika-week {
                color: #757575;
                font-size: 11px
            }

            .ec-pika--inrange .ec-pika-button {
                background: #1a7ac4;
                color: #fff
            }

            .ec-pika--startrange .ec-pika-button {
                background: #1a7ac4;
                color: #fff
            }

            .ec-pika--endrange .ec-pika-button {
                background: #1a7ac4;
                color: #fff
            }

            .dp__theme_light {
                --dp-background-color: #fff;
                --dp-hover-color: #1a7ac4;
                --dp-text-color: #191919;
                --dp-hover-text-color: #fff;
                --dp-icon-color: #191919;
                --dp-hover-icon-color: #fff;
                --dp-primary-color: #1a7ac4;
                --dp-disabled-color: #757575;
                --dp-secondary-color: #757575;
                --dp-primary-text-color: #fff
            }

            .ec-size .ec-store .form__msg {
                display: none;
                margin: 4px 0;
                color: #6e6e6e;
                -webkit-font-smoothing: antialiased;
                font-weight: 600;
                transition: color .15s ease-out 0s;
                line-height: 1.4;
                font-size: 12px
            }

            @media screen and (min-width: 1024px) {
                .ec-size .ec-store .form__msg {
                    font-size:14px
                }
            }

            @media screen and (max-width: 479px) {
                .ec-size .ec-store .form__msg {
                    font-size:16px
                }
            }

            .ec-size .ec-store .form__msg--info,.ec-size .ec-store .form__msg--error,.ec-size .ec-store .form__msg--success {
                display: block
            }

            .ec-size .ec-store .form__msg--error {
                color: #e56464
            }

            @font-face {
                font-family: "Root UI";
                font-style: normal;
                font-weight: 300;
                src: local("Root UI Light Regular"),local("Root UI Light"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Light.woff2") format("woff2"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Light.woff") format("woff"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Light.ttf") format("truetype");
                font-display: swap
            }

            @font-face {
                font-family: "Root UI";
                font-style: normal;
                font-weight: 400;
                src: local("Root UI Regular"),local("Root UI"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Regular.woff2") format("woff2"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Regular.woff") format("woff"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Regular.ttf") format("truetype");
                font-display: swap
            }

            @font-face {
                font-family: "Root UI";
                font-style: normal;
                font-weight: 600;
                src: local("Root UI Medium Regular"),local("Root UI Medium"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Medium.woff2") format("woff2"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Medium.woff") format("woff"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Medium.ttf") format("truetype");
                font-display: swap
            }

            @font-face {
                font-family: "Root UI";
                font-style: normal;
                font-weight: 700;
                src: local("Root UI Bold Regular"),local("Root UI Bold"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Bold.woff2") format("woff2"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Bold.woff") format("woff"),url("https://don16obqbay2c.cloudfront.net/fonts/root-ui/PT-Root-UI_Bold.ttf") format("truetype");
                font-display: swap
            }

            html,body {
                width: 100%;
                min-height: 100%;
                margin: 0;
                padding: 0;
                font-size: 16px;
                max-width: 100%;
                background-color: #fff;
                font-family: "Root UI","-apple-system","BlinkMacSystemFont","Segoe UI","Roboto",Arial,sans-serif;
                color: #191919
            }

            img {
                border: none
            }

            a {
                cursor: pointer;
                text-decoration: none
            }

            a,a:visited {
                color: #1a7ac4;
                transition: color .12s ease-out 0s
            }

            a:hover {
                color: #115080
            }

            a:active {
                color: #0a263b
            }

            .body {
                position: relative;
                background-color: #efefef;
                min-height: 100vh
            }

            .hidden {
                display: none !important
            }

            .ecwid-helper {
                position: fixed;
                left: -100%;
                top: 0;
                opacity: 0
            }

            .top-panel {
                background-color: #fff;
                top: 0;
                left: 0;
                width: 100%;
                z-index: 10;
                box-shadow: 0 0 3px rgba(0,0,0,0.2);
                box-sizing: border-box;
                padding-right: calc(env(safe-area-inset-right) - 20px);
                padding-left: calc(env(safe-area-inset-left) - 20px)
            }

            .top-panel.admin-panel {
                position: absolute
            }

            .top-panel.admin-panel.fixed {
                position: fixed
            }

            .top-panel.admin-panel .cross {
                width: 24px;
                height: 24px;
                padding: 8px;
                margin: 0 0 0 8px;
                opacity: .3;
                cursor: pointer;
                transition: opacity .1s ease-in-out 0s
            }

            .top-panel.admin-panel .cross:hover {
                opacity: .6
            }

            .top-panel.admin-panel .cross svg {
                width: 100%;
                height: 100%;
                display: block
            }

            .top-panel.edit-panel {
                position: fixed
            }

            .top-panel.edit-panel .wrapper .cell {
                padding: 0 8px 0 16px
            }

            .top-panel .wrapper {
                display: table;
                width: 100%
            }

            .top-panel .wrapper .cell {
                display: table-cell;
                vertical-align: middle;
                padding: 0 8px;
                height: 64px;
                text-align: left;
                font-size: 14px;
                line-height: 1.4em
            }

            @media (min-width: 480px) {
                .top-panel .wrapper .cell {
                    font-size:16px
                }
            }

            @media (min-width: 1024px) {
                .top-panel .wrapper .cell {
                    text-align:center;
                    width: 33%;
                    font-size: 18px
                }
            }

            .top-panel .wrapper .cell.first {
                text-align: left;
                width: 0;
                padding: 0
            }

            @media (min-width: 1024px) {
                .top-panel .wrapper .cell.first {
                    width:33%
                }
            }

            .top-panel .wrapper .cell.text {
                display: none
            }

            @media (min-width: 480px) {
                .top-panel .wrapper .cell.text {
                    display:table-cell
                }
            }

            .top-panel .wrapper .cell.buttons {
                text-align: right;
                width: 100%
            }

            @media (min-width: 480px) {
                .top-panel .wrapper .cell.buttons {
                    width:33%;
                    white-space: nowrap
                }
            }

            .top-panel .wrapper .cell .btn {
                margin: 2px 4px
            }

            .top-panel~.body {
                margin-top: 64px
            }

            .top-panel~.hero,.top-panel~.cover {
                padding-top: 64px
            }

            .top-panel~.hero~.body,.top-panel~.cover~.body {
                margin-top: 0
            }

            .top-panel~.block-offline {
                padding-top: 64px
            }

            .top-panel .btn-action .svg-icon {
                display: none;
                height: 12px
            }

            .top-panel .btn-action-success .svg-icon {
                display: inline-block;
                position: relative;
                left: -3px
            }

            .top-panel .btn-action-success::after {
                background-color: transparent;
                left: 10px
            }

            body.restored-http-checkout .body>*:not(.tiles),body.restored-http-checkout .tiles>*:not(.tile-store),body.restored-http-checkout .store .border,body.restored-http-checkout .hero,body.restored-http-checkout .cover {
                display: none
            }

            body.restored-http-checkout .body {
                background-color: transparent;
                overflow: hidden
            }

            @media (min-width: 480px) {
                body.restored-http-checkout .store {
                    width:1200px
                }
            }

            body.restored-http-checkout #ecwidStorefrontPlaceholder {
                position: fixed;
                width: 100vw;
                top: 0;
                left: 0
            }
        </style>
        <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Nunito:400,700|Cabin:400,700|Cabin:400,700&display=swap" crossorigin="anonymous"/>
    </head>
    <body id="ecwid_body" class="starter-site disable-ecwid-loader loading">
        <!-- Google Tag Manager -->
        <!-- Not Configured -->
        <!-- End Google Tag Manager -->
        <div class="search-panel hidden">
            <form method="get" action="#!/~/search/offset=0&sort=relevance&keyword=">
                <input class="text-field" type="search" name="keywords" value="" enterkeyhint="search" placeholder="Search products" aria-label="Search products">
                <button class="button" type="submit" aria-label="Search products">
                    <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <g fill="none" fill-rule="evenodd">
                            <path fill="#439CA0" d="M14.335 17.528c4.357 0 7.89-3.532 7.89-7.89 0-4.357-3.533-7.89-7.89-7.89-4.358 0-7.89 3.533-7.89 7.89 0 4.358 3.532 7.89 7.89 7.89zm0 1c-4.91 0-8.89-3.98-8.89-8.89s3.98-8.89 8.89-8.89 8.89 3.98 8.89 8.89-3.98 8.89-8.89 8.89z"/>
                            <path fill="#439CA0" d="M7.537 15.292L.684 22.146c-.39.39-.39 1.023 0 1.414.39.39 1.023.39 1.414 0l6.853-6.854c.392-.39.392-1.023 0-1.414-.39-.39-1.022-.39-1.413 0z"/>
                        </g>
                    </svg>
                </button>
                <div class="loader" wix-ctrl="Preloader"></div>
            </form>
        </div>
        <div class="search-panel-overlay hidden"></div>
        <style>
            @keyframes button-primary-focus {
                50% {
                    background-color: #595959
                }
            }

            @keyframes button-secondary-focus {
                50% {
                    background-color: #f2f2f2
                }
            }

            @keyframes preloader-rotate {
                0% {
                    transform: rotate(0deg)
                }

                100% {
                    transform: rotate(360deg)
                }
            }

            @keyframes bounce-x {
                0% {
                    transform: translate3d(0, 0, 0)
                }

                10% {
                    transform: translate3d(-6px, 0, 0)
                }

                20% {
                    transform: translate3d(12px, 0, 0)
                }

                29% {
                    transform: translate3d(-12px, 0, 0)
                }

                38% {
                    transform: translate3d(11px, 0, 0)
                }

                47% {
                    transform: translate3d(-9px, 0, 0)
                }

                56% {
                    transform: translate3d(7px, 0, 0)
                }

                65% {
                    transform: translate3d(-5px, 0, 0)
                }

                74% {
                    transform: translate3d(3px, 0, 0)
                }

                83% {
                    transform: translate3d(-1px, 0, 0)
                }

                92% {
                    transform: translate3d(1px, 0, 0)
                }

                100% {
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes bounce-top {
                0% {
                    transform: translate3d(0, 0, 0)
                }

                12% {
                    transform: translate3d(0, -5px, 0)
                }

                25% {
                    transform: translate3d(0, -7px, 0)
                }

                37% {
                    transform: translate3d(0, -5px, 0)
                }

                50% {
                    transform: translate3d(0, 0, 0)
                }

                62% {
                    transform: translate3d(0, -3px, 0)
                }

                75% {
                    transform: translate3d(0, -4px, 0)
                }

                87% {
                    transform: translate3d(0, -3px, 0)
                }

                100% {
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes heartbit-1x {
                0% {
                    transform: scale(1)
                }

                50% {
                    transform: scale(1.2)
                }

                100% {
                    transform: scale(1)
                }
            }

            @keyframes form-control-svg {
                0%,100% {
                    opacity: 0
                }

                6%,94% {
                    opacity: 1
                }
            }

            @keyframes form-control-text {
                0%,100% {
                    opacity: 1
                }

                6%,94% {
                    opacity: 0
                }
            }

            @keyframes form-control-check {
                from {
                    opacity: 1;
                    stroke-dasharray: 50;
                    stroke-dashoffset: 50
                }

                to {
                    opacity: 1;
                    stroke-dasharray: 50;
                    stroke-dashoffset: 0
                }
            }

            @keyframes marker-required {
                0% {
                    opacity: 1;
                    transform: scale(0)
                }

                100% {
                    opacity: 0;
                    transform: scale(2)
                }
            }

            @keyframes progress-bar-stripes {
                from {
                    background-position: 40px 0
                }

                to {
                    background-position: 0 0
                }
            }

            @keyframes move-bg {
                0% {
                    background-position: 200% 0
                }

                100% {
                    background-position: 0 0
                }
            }

            @keyframes showFromTop {
                0% {
                    opacity: 0;
                    transform: translate3d(0, -10px, 0)
                }

                100% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes showFromBottom {
                0% {
                    opacity: 0;
                    transform: translate3d(0, 20px, 0)
                }

                100% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes hideToTop {
                0% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }

                100% {
                    opacity: 0;
                    transform: translate3d(0, -20px, 0)
                }
            }

            @keyframes hideToBottom {
                0% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }

                100% {
                    opacity: 0;
                    transform: translate3d(0, 20px, 0)
                }
            }

            @keyframes fade-in {
                from {
                    opacity: 0
                }

                to {
                    opacity: 1
                }
            }

            @keyframes fade-out {
                from {
                    opacity: 1
                }

                to {
                    opacity: 0
                }
            }

            @keyframes popup-show-wrap {
                from {
                    transform: translateX(60px)
                }

                to {
                    transform: translateX(0)
                }
            }

            @keyframes popup-hide-wrap {
                from {
                    transform: translateX(0)
                }

                to {
                    transform: translateX(60px)
                }
            }

            @keyframes popup-show-wrap-from-left {
                from {
                    transform: translateX(-60px)
                }

                to {
                    transform: translateX(0)
                }
            }

            :root {
                --color-cover-title: $color-white;
                --color-cover-text: $color-white;
                --color-cover-button-text: $color-white;
                --color-cover-button-background: $base-color-button-v2;
                --color-menu: $color-white;
                --fontfamily-cover-title: $font-family;
                --fontfamily-cover-text: $font-family
            }

            .touchable .search-panel {
                position: absolute
            }

            .show-search-panel.touchable {
                position: relative
            }

            .show-search-panel.touchable .search-panel-overlay {
                display: block
            }

            .show-search-panel .search-panel {
                display: block
            }

            .search-panel {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                padding: 0 24px;
                box-sizing: border-box;
                z-index: 40;
                margin-top: 32px
            }

            @media (min-width: 600px) {
                .search-panel {
                    margin-top:64px
                }
            }

            @media (min-width: 768px) {
                .search-panel {
                    margin-top:96px
                }
            }

            @media (min-width: 1024px) {
                .search-panel {
                    margin-top:128px
                }
            }

            @media (min-width: 1280px) {
                .search-panel {
                    margin-top:160px
                }
            }

            .search-panel.loading .button {
                display: none
            }

            .search-panel.loading .loader {
                display: block
            }

            .search-panel form {
                display: block;
                margin: 0 auto;
                width: 100%;
                max-width: 624px;
                position: relative;
                box-sizing: border-box
            }

            .search-panel .text-field {
                background-color: #fff;
                border: 1px solid #e6e6e6;
                border-radius: 6px;
                box-shadow: 0 10px 37px rgba(0,0,0,0.4);
                box-sizing: border-box;
                width: 100%;
                height: 64px;
                font-size: 18px;
                line-height: 36px;
                outline: 0 none;
                padding: 14px 20px 14px 60px;
                vertical-align: middle;
                color: inherit;
                -webkit-appearance: none;
                transition: color .1s linear 0s, background-color .1s linear 0s, border-color .1s linear 0s, box-shadow .1s linear 0s
            }

            .search-panel .text-field::-moz-placeholder {
                color: #757575
            }

            .search-panel .text-field::-webkit-input-placeholder {
                color: #757575
            }

            .search-panel .text-field::-ms-input-placeholder {
                color: #757575
            }

            .search-panel .button {
                position: absolute;
                left: 0;
                top: 0;
                width: 55px;
                height: 100%;
                border: none;
                cursor: pointer;
                background-color: transparent
            }

            .search-panel .button:hover svg path[stroke] {
                stroke: #115080
            }

            .search-panel .button:hover svg path[fill] {
                fill: #115080
            }

            .search-panel .button:active svg path[stroke] {
                stroke: #0a263b
            }

            .search-panel .button:active svg path[fill] {
                fill: #0a263b
            }

            .search-panel .button svg path {
                transition: fill .1s ease-in-out 0s, stroke .1s ease-in-out 0s
            }

            .search-panel .button svg path[stroke] {
                stroke: #757575
            }

            .search-panel .button svg path[fill] {
                fill: #757575
            }

            .search-panel .loader {
                display: none;
                position: absolute;
                top: 0;
                left: 0;
                background: transparent url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 44 44'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' fill='%23757575' d='M36.3 35.9c-.4.5-.9.8-1.5.8-1.1 0-2-.9-2-2 0-.6.3-1.1.6-1.4 2.9-3 4.6-6.9 4.6-11.3s-1.8-8.4-4.7-11.3c-.4-.4-.6-.8-.6-1.4 0-1.1.9-2 2-2 .7 0 1.3.4 1.6.9 3.4 3.6 5.5 8.4 5.5 13.8.1 5.4-2 10.3-5.5 13.9zM10.7 10.7C7.8 13.6 6 17.6 6 22s1.8 8.4 4.7 11.3c.3.3.5.8.5 1.3 0 1.1-.9 2-2 2-.7 0-1.3-.4-1.6-.9-3.4-3.5-5.5-8.4-5.5-13.7 0-5.5 2.2-10.5 5.8-14.1.3-.3.8-.6 1.4-.6 1.1 0 1.9.9 1.9 1.9 0 .7-.2 1.1-.5 1.5z'/%3E%3C/svg%3E") center center no-repeat;
                background-size: 32px 32px;
                height: 100%;
                width: 65px;
                animation: spinright .5s linear 0s infinite
            }

            .search-panel-overlay {
                display: none;
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 35
            }

            @keyframes spinright {
                0% {
                    transform: rotate(0deg)
                }

                100% {
                    transform: rotate(360deg)
                }
            }

            .float-icons {
                position: absolute;
                z-index: 30;
                top: 0;
                right: 0;
                padding-right: env(safe-area-inset-right)
            }

            .float-icons.fixed {
                position: fixed
            }

            @media (max-width: 1280px) {
                .float-icons {
                    transform:translateY(60px)
                }
            }

            @media (max-width: 600px) {
                .float-icons {
                    transform:none
                }
            }

            .float-icons__icon {
                opacity: 1;
                height: 48px;
                padding-top: 12px;
                text-align: right;
                transform: translateX(-8px);
                transition: height .15s ease-in-out 0s, padding .15s ease-in-out 0s, opacity .3s ease-in-out .15s, transform .3s ease-in-out .15s
            }

            @media (min-width: 414px) {
                .float-icons__icon {
                    height:68px;
                    padding-top: 16px;
                    transform: translateX(-16px)
                }
            }

            @media (min-width: 768px) {
                .float-icons__icon {
                    padding-top:24px;
                    transform: translateX(-24px)
                }
            }

            .float-icons__icon.off,.float-icons__icon.off2 {
                opacity: 0;
                height: 0;
                padding-top: 0;
                transform: translateX(-4px);
                transition: height .15s ease-in-out .3s, padding .15s ease-in-out .3s, opacity .3s ease-in-out 0s, transform .3s ease-in-out 0s;
                cursor: default;
                pointer-events: none
            }

            .float-icons__icon .ecwid {
                display: none
            }

            [data-block] {
                background-color: #fff;
                box-sizing: border-box;
                padding-right: env(safe-area-inset-right);
                padding-left: env(safe-area-inset-left)
            }

            [data-block]:not(.store) h2 {
                text-align: center;
                font-size: 28px;
                line-height: 1.3em;
                font-weight: 600;
                margin: 0 auto 16px;
                padding: 0 8px;
                word-wrap: break-word;
                -webkit-font-smoothing: antialiased
            }

            @media (min-width: 1024px) {
                [data-block]:not(.store) h2 {
                    font-size:30px
                }
            }

            [data-block]:not(.store).location h2 {
                margin-left: 16px;
                margin-right: 16px
            }

            [data-block]:not(.store) p,[data-block]:not(.store) .description,[data-block]:not(.store) .description::before {
                font-size: 14px;
                line-height: 1.8em;
                font-weight: 400;
                margin: 16px auto;
                padding: 0 8px;
                word-wrap: break-word
            }

            @media (min-width: 1024px) {
                [data-block]:not(.store) p,[data-block]:not(.store) .description,[data-block]:not(.store) .description::before {
                    font-size:16px
                }
            }

            [data-block]:not(.store) .description {
                box-sizing: border-box
            }

            [data-block]:not(.store) .description p,[data-block]:not(.store) .description::before {
                padding: 0
            }

            [data-block]:not(.store) .description p>br {
                display: none
            }

            [data-block]:not(.store) sup,[data-block]:not(.store) mark,[data-block]:not(.store) .nobr {
                font-size: inherit;
                line-height: inherit;
                vertical-align: baseline;
                white-space: nowrap;
                background-color: inherit;
                color: inherit
            }

            [data-block]>div {
                padding: 32px 16px;
                max-width: 1152px;
                box-sizing: border-box;
                margin: 0 auto
            }

            .menu>div {
                padding-bottom: 0;
                text-align: center
            }

            .menu .container {
                display: none
            }

            @media (min-width: 600px) {
                .menu .container {
                    display:block;
                    margin: 0 auto;
                    max-width: 1152px;
                    position: relative;
                    font-size: 14px;
                    font-weight: 400;
                    line-height: 24px;
                    min-height: 32px
                }
            }

            @media (min-width: 768px) {
                .menu .container {
                    font-size:16px;
                    line-height: 28px
                }
            }

            @media (min-width: 1024px) {
                .menu .container {
                    font-size:18px;
                    line-height: 32px
                }
            }

            .menu .cat-row {
                margin: 0;
                padding: 0;
                display: inline-block
            }

            .menu .cat-name {
                display: inline-block;
                margin: 0;
                padding: 0 16px 8px;
                box-sizing: border-box;
                list-style: none
            }

            @media (min-width: 1024px) {
                .menu .cat-name {
                    padding:0 24px 8px
                }
            }

            .menu .cat-name.active>a {
                color: #0a263b
            }

            .menu .cat-name a {
                display: block;
                max-width: 90vw;
                word-wrap: break-word;
                vertical-align: middle
            }

            .menu .cat-name a,.menu .cat-name a:visited {
                color: #191919;
                transition: color .12s ease-out 0s
            }

            .menu .cat-name a:hover {
                color: #115080
            }

            .menu .cat-name a:active {
                color: #0a263b
            }

            .menu .cart-spacer {
                float: right;
                width: 32px;
                height: 24px;
                display: inline-block;
                list-style: none
            }

            .menu .cart-spacer.left {
                float: left
            }

            .menu .pushmenu-btn {
                display: inline-block;
                height: 24px;
                margin: -16px 0;
                padding: 16px 24px;
                background-size: contain;
                cursor: pointer;
                z-index: 10;
                color: #1a7ac4
            }

            @media (min-width: 600px) {
                .menu .pushmenu-btn {
                    display:none
                }
            }

            .menu .pushmenu-btn:hover {
                color: #115080
            }

            .menu .pushmenu-btn:hover svg path {
                fill: #115080
            }

            .menu .pushmenu-btn:active {
                color: #0a263b
            }

            .menu .pushmenu-btn:active svg path {
                fill: #0a263b
            }

            .menu .pushmenu-btn svg {
                width: 24px;
                height: 24px;
                margin-right: 4px;
                display: inline-block;
                vertical-align: middle
            }

            .menu .pushmenu-btn svg path {
                fill: #1a7ac4
            }

            .menu .pushmenu-btn span {
                display: inline-block;
                vertical-align: middle
            }

            .pushmenu {
                position: fixed;
                top: 0;
                left: -100%;
                overflow: hidden;
                height: 100%;
                width: 100%;
                z-index: 10;
                transition: left 0s linear .3s
            }

            @media (min-width: 600px) {
                .pushmenu {
                    display:none
                }
            }

            .pushmenu::before {
                content: "";
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0);
                transition: background-color .3s ease-in-out .0s
            }

            .pushmenu .container {
                height: 100%;
                max-width: 70%;
                min-width: 200px;
                padding: 0 16px;
                background-color: #fff;
                position: absolute;
                overflow: auto;
                box-sizing: border-box;
                -webkit-overflow-scrolling: touch;
                transform: translate3D(-100%, 0, 0);
                transition: transform .3s ease-in-out 0s
            }

            .pushmenu .container>.cat-row {
                padding: 16px 0
            }

            .pushmenu .cat-row {
                margin: 0;
                padding: 0
            }

            .pushmenu .cat-name {
                display: block;
                margin: 0;
                box-sizing: border-box;
                width: 100%;
                list-style: none
            }

            .pushmenu .cat-name.active>a {
                color: #1a7ac4
            }

            .pushmenu .cat-name.active>a:hover,.pushmenu .cat-name.active>a:active {
                color: #fff
            }

            .pushmenu .cat-name a {
                color: #191919;
                display: block;
                transition-duration: 0s;
                padding: 16px;
                border-radius: 4px;
                background-color: transparent;
                word-wrap: break-word;
                transition: background-color .1s ease-in-out 0s
            }

            .pushmenu .cat-name a:hover {
                color: #fff;
                background-color: #115080
            }

            .pushmenu .cat-name a:active {
                color: #fff;
                background-color: #0a263b
            }

            .pushmenu .cat-name a:active svg path {
                fill: #fff
            }

            body.has-overlay {
                overflow: hidden
            }

            body.menu-opened .pushmenu {
                left: 0;
                transition: left 0s linear 0s
            }

            body.menu-opened .pushmenu::before {
                background-color: rgba(0,0,0,0.7)
            }

            body.menu-opened .pushmenu .container {
                transform: translate3D(0%, 0, 0)
            }

            .caption>div {
                text-align: center;
                max-width: 624px;
                padding-bottom: 0
            }

            @media (min-width: 1024px) {
                .caption>div {
                    max-width:768px
                }
            }

            .caption img {
                max-width: 100%;
                max-height: 140px;
                width: auto;
                height: auto;
                margin: 0 auto;
                display: block
            }

            @media (min-width: 480px) {
                .caption img {
                    max-width:480px
                }
            }

            .caption h1 {
                margin: 0 auto;
                text-align: center;
                font-weight: 600;
                font-size: 22px;
                line-height: 1.3em;
                word-wrap: break-word
            }

            @media (min-width: 480px) {
                .caption h1 {
                    font-size:28px
                }
            }

            @media (min-width: 1024px) {
                .caption h1 {
                    font-size:34px
                }
            }

            .caption .home,.caption .home:visited {
                color: #191919;
                transition: color .12s ease-out 0s
            }

            .caption .home:hover {
                color: #115080
            }

            .caption .home:active {
                color: #0a263b
            }

            .caption .logo {
                margin: 0 auto
            }

            .block-offline {
                display: none;
                margin: 64px 0 32px;
                text-align: center
            }

            .block-offline__panel {
                box-sizing: border-box;
                max-width: 500px;
                margin: 0 auto;
                padding: 30px 20px;
                border-radius: 5px;
                background-color: #fff;
                box-shadow: 0 10px 35px rgba(0,0,0,0.2);
                word-wrap: break-word
            }

            @media (min-width: 414px) {
                .block-offline__panel {
                    padding:45px 20px
                }
            }

            .block-offline__panel-title {
                margin: 10px 0;
                font-size: 22px;
                line-height: 1.3em
            }

            .block-offline__panel-text {
                margin: 16px;
                font-size: 16px;
                line-height: 1.8em
            }

            .offline .block-offline {
                display: block
            }

            .offline .ecwid,.offline .caption,.offline .menu,.offline .float-icons {
                display: none
            }

            .offline .store,.offline .store div {
                min-height: 0 !important
            }

            .store:not(.block-hidden) {
                min-height: 250px
            }

            .store:not(.block-hidden)>div {
                max-width: 1152px
            }

            .store:not(.block-hidden) #ecwid-products {
                min-height: 400px
            }

            .store:not(.block-hidden) .border {
                max-width: 100%;
                border-top: 3px solid #e6e6e6;
                padding: 0
            }

            .whyus>div {
                max-width: 624px
            }

            @media (min-width: 1024px) {
                .whyus>div {
                    max-width:768px
                }
            }

            [data-block].quote .description,[data-block].quote .description p,[data-block].quote .description::before {
                font-size: 22px;
                line-height: 1.3em;
                font-weight: 300
            }

            @media (min-width: 1024px) {
                [data-block].quote .description,[data-block].quote .description p,[data-block].quote .description::before {
                    font-size:28px
                }
            }

            .quote>div {
                padding-top: 16px;
                max-width: 624px
            }

            @media (min-width: 1024px) {
                .quote>div {
                    max-width:768px
                }
            }

            .quote .ico {
                display: block;
                margin: 0 auto 16px;
                overflow: hidden
            }

            .quote .author {
                display: table;
                width: 100%;
                margin: 16px 0 0
            }

            @media (min-width: 1024px) {
                .quote .author {
                    margin-top:24px
                }
            }

            .quote .author>div {
                display: table-cell;
                vertical-align: middle
            }

            .quote .author .avatar {
                width: 96px;
                padding: 0 16px 0 8px
            }

            .quote .author .avatar form {
                display: inline-block
            }

            .quote .author p {
                margin: 0
            }

            .quote .author p:last-child {
                margin-bottom: 8px
            }

            .quote .author img {
                border-radius: 50%;
                width: 96px;
                height: 96px;
                display: block
            }

            .reviews {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-wrap: wrap;
                flex-wrap: wrap;
                -ms-flex-pack: justify;
                justify-content: space-between;
                padding: 16px 16px 8px 16px;
                position: relative
            }

            .reviews .reviews__item {
                margin-bottom: 24px;
                width: 100%;
                box-sizing: border-box
            }

            .reviews .review {
                display: -ms-grid;
                display: grid;
                -ms-grid-columns: min-content 1fr;
                grid-template-columns: min-content 1fr;
                word-break: break-word
            }

            .reviews .review .review__quote {
                display: flex;
                align-items: center;
                justify-content: center
            }

            .reviews .review .review__quote svg {
                width: 39px;
                height: 32px;
                fill: #ccc
            }

            .reviews .review .review__desc p {
                font-size: inherit;
                line-height: inherit;
                font-style: inherit;
                font-weight: inherit;
                padding: 0;
                margin: 0
            }

            .reviews .review .review__desc p+p {
                margin-top: 16px
            }

            .reviews .review .review__avatar img {
                display: block;
                width: 96px;
                height: 96px;
                margin: auto;
                border-radius: 50%
            }

            .reviews .review .review__avatar .review__quote {
                width: 96px;
                height: 96px;
                margin: auto;
                border-radius: 50%;
                background-color: #f9f9f9;
                display: none
            }

            .reviews .review .review__avatar.empty img {
                display: none
            }

            .reviews .review .review__avatar.empty .review__quote {
                display: flex
            }

            .reviews .review .review__author {
                font-size: 14px;
                line-height: 1.5em
            }

            @media (min-width: 1024px) {
                .reviews .review .review__author {
                    font-size:16px
                }
            }

            .reviews .review .review__author-name,.reviews .review .review__author-title {
                display: block
            }

            .reviews[data-items="1"] .review {
                -ms-grid-columns: min-content 1fr;
                grid-template-columns: min-content 1fr;
                position: relative
            }

            .reviews[data-items="1"] .review .review__quote {
                -ms-grid-row: 1;
                grid-row: 1;
                -ms-grid-column: 1;
                -ms-grid-column-span: 2;
                grid-column: 1 / span 2;
                margin-bottom: 16px
            }

            .reviews[data-items="1"] .review .review__quote svg {
                width: 32px;
                height: 26px
            }

            .reviews[data-items="1"] .review .review__desc {
                font-size: 22px;
                line-height: 1.3em;
                font-weight: 300;
                margin-bottom: 16px;
                -ms-grid-row: 2;
                grid-row: 2;
                -ms-grid-column: 1;
                -ms-grid-column-span: 2;
                grid-column: 1 / span 2
            }

            @media (min-width: 1024px) {
                .reviews[data-items="1"] .review .review__desc {
                    font-size:28px
                }
            }

            .reviews[data-items="1"] .review .review__avatar {
                -ms-grid-row: 3;
                grid-row: 3;
                -ms-grid-column: 1;
                -ms-grid-column-span: 1;
                grid-column: 1 / 2
            }

            .reviews[data-items="1"] .review .review__avatar img {
                margin-right: 24px
            }

            .reviews[data-items="1"] .review .review__avatar .review__quote {
                display: none
            }

            .reviews[data-items="1"] .review .review__author {
                -ms-grid-row: 3;
                grid-row: 3;
                -ms-grid-column: 2;
                grid-column: 2 / 2;
                align-self: center
            }

            @media (min-width: 768px) {
                .reviews[data-items="2"],.reviews[data-items="4"] {
                    max-width:1152px
                }
            }

            .reviews[data-items="2"] .reviews__item,.reviews[data-items="4"] .reviews__item {
                padding-left: 8px;
                padding-right: 8px;
                width: 100%
            }

            @media (min-width: 768px) {
                .reviews[data-items="2"] .reviews__item,.reviews[data-items="4"] .reviews__item {
                    width:50%
                }
            }

            .reviews[data-items="2"] .reviews__item>.review__quote,.reviews[data-items="4"] .reviews__item>.review__quote {
                display: none
            }

            .reviews[data-items="2"] .review,.reviews[data-items="4"] .review {
                -ms-grid-rows: max-content min-content;
                grid-template-rows: max-content min-content
            }

            .reviews[data-items="2"] .review .review__desc,.reviews[data-items="4"] .review .review__desc {
                font-size: 18px;
                line-height: 1.4em;
                font-style: italic;
                -ms-grid-row: 2;
                grid-row: 2;
                -ms-grid-column: 2;
                grid-column: 2
            }

            @media (min-width: 768px) {
                .reviews[data-items="2"] .review .review__desc,.reviews[data-items="4"] .review .review__desc {
                    font-size:20px
                }
            }

            .reviews[data-items="2"] .review .review__avatar,.reviews[data-items="4"] .review .review__avatar {
                -ms-grid-column: 1;
                grid-column: 1;
                -ms-grid-row: 1;
                -ms-grid-row-span: 2;
                grid-row: 1 / span 2
            }

            .reviews[data-items="2"] .review .review__avatar img,.reviews[data-items="2"] .review .review__avatar .review__quote,.reviews[data-items="4"] .review .review__avatar img,.reviews[data-items="4"] .review .review__avatar .review__quote {
                margin-right: 24px
            }

            .reviews[data-items="2"] .review .review__author,.reviews[data-items="4"] .review .review__author {
                -ms-grid-row: 1;
                grid-row: 1;
                -ms-grid-column: 2;
                grid-column: 2 / 2;
                margin-bottom: 8px
            }

            @media (min-width: 768px) {
                .reviews[data-items="2"] .review .review__author,.reviews[data-items="4"] .review .review__author {
                    font-size:16px
                }
            }

            .reviews[data-items="2"] .review .review__author-name,.reviews[data-items="2"] .review .review__author-title,.reviews[data-items="4"] .review .review__author-name,.reviews[data-items="4"] .review .review__author-title {
                display: inline
            }

            .reviews[data-items="2"] .review .review__author-name:not(:empty)+.review__author-title:not(:empty)::before,.reviews[data-items="4"] .review .review__author-name:not(:empty)+.review__author-title:not(:empty)::before {
                content: ", ";
                margin-left: -0.3em
            }

            @media (min-width: 768px) {
                .reviews[data-items="3"] {
                    max-width:1152px
                }
            }

            .reviews[data-items="3"] .reviews__item {
                padding-left: 8px;
                padding-right: 8px;
                width: 100%
            }

            @media (min-width: 768px) {
                .reviews[data-items="3"] .reviews__item {
                    width:calc(100% / 3)
                }
            }

            .reviews[data-items="3"] .reviews__item>.review__quote {
                display: none
            }

            .reviews[data-items="3"] .review {
                -ms-grid-rows: 104px 12px min-content 12px auto;
                grid-template-rows: 104px min-content auto;
                -ms-grid-columns: none;
                grid-template-columns: none;
                grid-row-gap: 12px;
                grid-column-gap: 16px;
                text-align: center
            }

            .reviews[data-items="3"] .review .review__desc {
                font-size: 16px;
                line-height: 1.4em;
                font-style: italic;
                -ms-grid-row: 3;
                grid-row: 3;
                -ms-grid-column: 1;
                grid-column: 1
            }

            @media (min-width: 768px) {
                .reviews[data-items="3"] .review .review__desc {
                    font-size:18px;
                    line-height: 1.56em
                }
            }

            .reviews[data-items="3"] .review .review__avatar {
                -ms-grid-row: 1;
                grid-row: 1;
                -ms-grid-column: 1;
                grid-column: 1;
                margin-bottom: 20px
            }

            .reviews[data-items="3"] .review .review__author {
                -ms-grid-row: 2;
                grid-row: 2;
                -ms-grid-column: 1;
                grid-column: 1
            }

            .reviews[data-items="3"] .review>*:nth-child(1) {
                -ms-grid-row: 1;
                -ms-grid-column: 1
            }

            .reviews[data-items="3"] .review>*:nth-child(2) {
                -ms-grid-row: 3;
                -ms-grid-column: 1
            }

            .reviews[data-items="3"] .review>*:nth-child(3) {
                -ms-grid-row: 5;
                -ms-grid-column: 1
            }

            .reviews[data-items="4"] .reviews__item:not(:last-child) {
                margin-bottom: 48px
            }

            @media (min-width: 768px) {
                .reviews[data-items="4"] .reviews__item {
                    padding-right:24px
                }
            }

            .owner>div {
                max-width: 624px
            }

            @media (min-width: 1024px) {
                .owner>div {
                    max-width:768px
                }
            }

            .owner .description {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-direction: column;
                flex-direction: column;
                -ms-align-items: stretch;
                align-items: stretch
            }

            .owner .description p {
                display: block;
                margin-left: 0;
                margin-right: 0;
                margin-bottom: 0
            }

            .owner .description p:first-child {
                margin-top: 0
            }

            @media (min-width: 768px) {
                .owner .author {
                    float:right;
                    margin: 8px -40px 0 32px;
                    max-width: 176px;
                    word-wrap: break-word
                }
            }

            @media (min-width: 1280px) {
                .owner .author {
                    margin:8px -64px 0 32px;
                    max-width: 208px
                }
            }

            .owner .author .avatar {
                text-align: center
            }

            .owner .author .avatar form {
                display: inline-block
            }

            .owner .author img {
                width: 144px;
                height: 144px;
                border-radius: 50%;
                display: block;
                margin: 0 auto
            }

            .owner .author p {
                text-align: center;
                margin: 16px 0 0
            }

            .owner .author p:last-child {
                margin-bottom: 16px
            }

            .owner .author p+p {
                margin-top: 0
            }

            .owner .cb {
                clear: both;
                height: 1px
            }

            .location>div {
                max-width: 1152px;
                padding-left: 0;
                padding-right: 0
            }

            .location p.title {
                font-weight: 600;
                margin: 8px 0
            }

            .location p.address {
                margin: 8px 0
            }

            .location p.day {
                margin: 8px 0 0
            }

            .location p.hour {
                margin: 0 0 8px
            }

            .location .layout,.location .columns {
                display: flex;
                justify-content: stretch
            }

            .location .layout>*,.location .columns>* {
                width: 100%
            }

            .location .layout>*.address,.location .columns>*.address {
                padding-right: 8px
            }

            .location .layout {
                flex-direction: column
            }

            @media (min-width: 768px) {
                .location .layout {
                    flex-direction:row
                }
            }

            .location .layout.no-description {
                margin: 0 auto
            }

            @media (min-width: 768px) {
                .location .layout.no-description {
                    max-width:624px
                }
            }

            @media (min-width: 1024px) {
                .location .layout.no-description {
                    max-width:768px
                }
            }

            @media (min-width: 768px) {
                .location .layout.no-description:not(.no-schedule) .columns {
                    flex-direction:column
                }
            }

            @media (min-width: 768px) {
                .location .layout.no-description:not(.no-schedule) .schedule {
                    padding-top:30px
                }
            }

            .location .layout.no-description.no-schedule {
                text-align: center
            }

            @media (min-width: 768px) {
                .location .layout.no-description.no-schedule {
                    flex-direction:column
                }
            }

            .location .layout.no-description.no-schedule .text,.location .layout.no-description.no-schedule .frame {
                order: 1;
                padding-left: 24px;
                padding-right: 24px;
                box-sizing: border-box
            }

            .location .layout.no-description.no-schedule .frame {
                order: 2
            }

            .location .layout.no-description.no-schedule .ec-size {
                display: none
            }

            .location .text {
                margin: 0 auto;
                box-sizing: border-box;
                overflow: hidden;
                max-width: 624px;
                padding: 0 16px
            }

            @media (min-width: 768px) {
                .location .text {
                    max-width:768px
                }
            }

            .location .frame {
                position: relative;
                margin-bottom: 15px;
                transition: opacity .6s ease-in-out 0s
            }

            @media (min-width: 768px) {
                .location .frame {
                    margin-top:14px;
                    margin-left: 24px;
                    margin-bottom: 0
                }
            }

            .location .frame.disabled {
                pointer-events: none;
                opacity: .4
            }

            .location .google-map {
                background-color: #efefef;
                width: 100%;
                height: 100%;
                display: block;
                border: 0 none;
                min-height: 320px
            }

            html#ecwid_html body#ecwid_body .location .ec-size {
                padding: 0 8px
            }

            html#ecwid_html body#ecwid_body .location .ec-size .ec-store .form-control__button {
                padding-left: 10px;
                padding-right: 10px
            }

            .location+.contacts>div {
                padding-top: 64px
            }

            .contacts>div {
                overflow: hidden;
                text-align: center;
                max-width: 1152px
            }

            .contacts .data {
                text-align: center
            }

            .contacts .data:last-child {
                margin-bottom: 24px
            }

            .contacts .data>div {
                display: inline-block;
                margin: 10px 15px
            }

            .contacts .data .value {
                box-sizing: border-box
            }

            .contacts .data .value .icon {
                display: inline-block;
                position: relative;
                top: 1px;
                margin-right: 4px
            }

            .contacts .data .value .icon svg {
                display: block
            }

            .contacts .data .phone a,.contacts .data .phone a:visited {
                color: #191919;
                transition: color .12s ease-out 0s
            }

            .contacts .data .phone a:hover {
                color: #115080
            }

            .contacts .data .phone a:active {
                color: #0a263b
            }

            .contacts .data+div h3 {
                margin-top: 40px
            }

            .contacts .data+.channels {
                margin-top: 24px
            }

            .contacts h3 {
                font-size: 16px;
                line-height: 1.3em;
                font-weight: 400;
                margin: 8px auto;
                padding: 0 16px
            }

            @media (min-width: 480px) {
                .contacts h3 {
                    font-size:18px
                }
            }

            .contacts .channels {
                margin: 8px auto
            }

            .contacts .channels>div {
                margin: 0 auto
            }

            .contacts .channels>div>div {
                display: inline-block;
                max-width: 100%;
                margin: 16px 0 8px;
                text-align: center;
                width: 100%
            }

            @media (min-width: 480px) {
                .contacts .channels>div>div {
                    width:auto
                }
            }

            .contacts .channels>div>div.facebook a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath fill='%233B5998' fill-rule='evenodd' d='M48 45c0 1.656-1.344 3-3 3H3c-1.656 0-3-1.344-3-3V3c0-1.656 1.344-3 3-3h42c1.656 0 3 1.344 3 3v42zm-15 3V30h6l1.5-7.5H33v-3c0-3 1.503-4.5 4.5-4.5h3V7.5h-6c-5.512 0-9 4.322-9 10.5v4.5h-6V30h6v18H33z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.facebook a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath fill='%23999' fill-rule='evenodd' d='M48 45c0 1.656-1.344 3-3 3H3c-1.656 0-3-1.344-3-3V3c0-1.656 1.344-3 3-3h42c1.656 0 3 1.344 3 3v42zm-15 3V30h6l1.5-7.5H33v-3c0-3 1.503-4.5 4.5-4.5h3V7.5h-6c-5.512 0-9 4.322-9 10.5v4.5h-6V30h6v18H33z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.twitter a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='40' viewBox='0 0 50 40'%3E%3Cpath fill='%2340B9FA' fill-rule='evenodd' d='M43.556 6.483c2.06-1.235 3.643-3.19 4.39-5.52-1.93 1.143-4.065 1.976-6.338 2.42-1.822-1.937-4.415-3.15-7.288-3.15-5.51 0-9.977 4.468-9.977 9.98 0 .78.087 1.545.257 2.274C16.306 12.07 8.953 8.097 4.03 2.06c-.858 1.475-1.35 3.188-1.35 5.018 0 3.463 1.762 6.516 4.438 8.307-1.635-.053-3.174-.5-4.52-1.248v.125c0 4.836 3.44 8.87 8.005 9.787-.837.226-1.72.35-2.63.35-.644 0-1.267-.064-1.876-.18 1.268 3.963 4.956 6.85 9.32 6.93-3.413 2.677-7.715 4.275-12.39 4.275-.807 0-1.602-.047-2.382-.14 4.415 2.828 9.66 4.48 15.297 4.48 18.356 0 28.395-15.205 28.395-28.394 0-.43-.012-.862-.03-1.29 1.95-1.407 3.64-3.164 4.98-5.168-1.79.796-3.71 1.332-5.73 1.57z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.twitter a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='40' viewBox='0 0 50 40'%3E%3Cpath fill='%23999' fill-rule='evenodd' d='M43.556 6.483c2.06-1.235 3.643-3.19 4.39-5.52-1.93 1.143-4.065 1.976-6.338 2.42-1.822-1.937-4.415-3.15-7.288-3.15-5.51 0-9.977 4.468-9.977 9.98 0 .78.087 1.545.257 2.274C16.306 12.07 8.953 8.097 4.03 2.06c-.858 1.475-1.35 3.188-1.35 5.018 0 3.463 1.762 6.516 4.438 8.307-1.635-.053-3.174-.5-4.52-1.248v.125c0 4.836 3.44 8.87 8.005 9.787-.837.226-1.72.35-2.63.35-.644 0-1.267-.064-1.876-.18 1.268 3.963 4.956 6.85 9.32 6.93-3.413 2.677-7.715 4.275-12.39 4.275-.807 0-1.602-.047-2.382-.14 4.415 2.828 9.66 4.48 15.297 4.48 18.356 0 28.395-15.205 28.395-28.394 0-.43-.012-.862-.03-1.29 1.95-1.407 3.64-3.164 4.98-5.168-1.79.796-3.71 1.332-5.73 1.57z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.pinterest a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='41' height='48' viewBox='0 0 41 48'%3E%3Cpath fill='%23C13E3E' fill-rule='evenodd' d='M8.59 46.524c-.083-2.06-.015-4.528.512-6.76.567-2.397 3.79-16.055 3.79-16.055s-.943-1.88-.943-4.657c0-4.362 2.532-7.623 5.682-7.623 2.677 0 3.972 2.01 3.972 4.42 0 2.69-1.72 6.72-2.6 10.45-.738 3.123 1.57 5.67 4.644 5.67 5.58 0 9.338-7.163 9.338-15.657 0-6.453-4.347-11.283-12.253-11.283-8.934 0-14.498 6.66-14.498 14.102 0 2.567.757 4.377 1.94 5.778.548.644.623.9.423 1.64-.137.545-.46 1.847-.597 2.363-.196.75-.798 1.014-1.474.736C2.41 27.972.496 23.465.496 18.4.496 10.034 7.55 0 21.546 0c11.243 0 18.65 8.138 18.65 16.873 0 11.553-6.43 20.185-15.897 20.185-3.182 0-6.174-1.72-7.194-3.668 0 0-1.713 6.787-2.072 8.094-.626 2.267-1.848 4.54-2.964 6.31-1.31.62-3.472-.264-3.48-1.27z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.pinterest a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='41' height='48' viewBox='0 0 41 48'%3E%3Cpath fill='%23999' fill-rule='evenodd' d='M8.59 46.524c-.083-2.06-.015-4.528.512-6.76.567-2.397 3.79-16.055 3.79-16.055s-.943-1.88-.943-4.657c0-4.362 2.532-7.623 5.682-7.623 2.677 0 3.972 2.01 3.972 4.42 0 2.69-1.72 6.72-2.6 10.45-.738 3.123 1.57 5.67 4.644 5.67 5.58 0 9.338-7.163 9.338-15.657 0-6.453-4.347-11.283-12.253-11.283-8.934 0-14.498 6.66-14.498 14.102 0 2.567.757 4.377 1.94 5.778.548.644.623.9.423 1.64-.137.545-.46 1.847-.597 2.363-.196.75-.798 1.014-1.474.736C2.41 27.972.496 23.465.496 18.4.496 10.034 7.55 0 21.546 0c11.243 0 18.65 8.138 18.65 16.873 0 11.553-6.43 20.185-15.897 20.185-3.182 0-6.174-1.72-7.194-3.668 0 0-1.713 6.787-2.072 8.094-.626 2.267-1.848 4.54-2.964 6.31-1.31.62-3.472-.264-3.48-1.27z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.instagram a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cdefs%3E%3ClinearGradient x1='7.274%' y1='92.726%' x2='92.086%' y2='7.914%' id='a'%3E%3Cstop stop-color='%23FFD521' offset='0%'/%3E%3Cstop stop-color='%23F52400' offset='49.715%'/%3E%3Cstop stop-color='%23B92BB4' offset='100%'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath d='M592 3920c6.518 0 7.335.028 9.895.144 2.555.117 4.3.523 5.826 1.116 1.58.613 2.918 1.434 4.252 2.768 1.334 1.334 2.155 2.673 2.768 4.25.593 1.528 1 3.272 1.116 5.827.116 2.56.144 3.377.144 9.895s-.028 7.335-.144 9.895c-.117 2.555-.523 4.3-1.116 5.826-.613 1.58-1.434 2.918-2.768 4.252-1.334 1.334-2.673 2.155-4.25 2.768-1.528.593-3.272 1-5.827 1.116-2.56.116-3.377.144-9.895.144s-7.335-.028-9.895-.144c-2.555-.117-4.3-.523-5.826-1.116-1.58-.613-2.918-1.434-4.252-2.768-1.334-1.334-2.155-2.673-2.768-4.25-.593-1.528-1-3.272-1.116-5.827-.116-2.56-.144-3.377-.144-9.895s.028-7.335.144-9.895c.117-2.555.523-4.3 1.116-5.826.613-1.58 1.434-2.918 2.768-4.252 1.334-1.334 2.673-2.155 4.25-2.768 1.528-.593 3.272-1 5.827-1.116 2.56-.116 3.377-.144 9.895-.144zm0 4c-6.514 0-7.285.025-9.858.142-2.378.11-3.67.506-4.53.84-1.14.443-1.95.97-2.805 1.825-.854.854-1.382 1.666-1.825 2.805-.334.86-.73 2.152-.84 4.53-.117 2.573-.142 3.344-.142 9.858 0 6.514.025 7.285.142 9.858.11 2.378.506 3.67.84 4.53.443 1.14.972 1.95 1.825 2.805.854.854 1.666 1.382 2.805 1.825.86.334 2.152.73 4.53.84 2.572.117 3.344.142 9.858.142 6.514 0 7.286-.025 9.858-.142 2.378-.11 3.67-.506 4.53-.84 1.14-.443 1.95-.97 2.805-1.825.854-.854 1.382-1.666 1.825-2.805.334-.86.73-2.152.84-4.53.117-2.573.142-3.344.142-9.858 0-6.514-.025-7.285-.142-9.858-.11-2.378-.506-3.67-.84-4.53-.443-1.14-.97-1.95-1.825-2.805-.854-.854-1.666-1.382-2.805-1.825-.86-.334-2.152-.73-4.53-.84-2.573-.117-3.344-.142-9.858-.142zm0 8c6.627 0 12 5.373 12 12s-5.373 12-12 12-12-5.373-12-12 5.373-12 12-12zm0 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm16-21c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z' transform='translate(-568 -3920)' fill='url(%23a)' fill-rule='evenodd'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.instagram a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cdefs%3E%3ClinearGradient x1='7.274%' y1='92.726%' x2='92.086%' y2='7.914%' id='a'%3E%3Cstop stop-color='%23999' offset='0%'/%3E%3Cstop stop-color='%23999' offset='49.715%'/%3E%3Cstop stop-color='%23999' offset='100%'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath d='M592 3920c6.518 0 7.335.028 9.895.144 2.555.117 4.3.523 5.826 1.116 1.58.613 2.918 1.434 4.252 2.768 1.334 1.334 2.155 2.673 2.768 4.25.593 1.528 1 3.272 1.116 5.827.116 2.56.144 3.377.144 9.895s-.028 7.335-.144 9.895c-.117 2.555-.523 4.3-1.116 5.826-.613 1.58-1.434 2.918-2.768 4.252-1.334 1.334-2.673 2.155-4.25 2.768-1.528.593-3.272 1-5.827 1.116-2.56.116-3.377.144-9.895.144s-7.335-.028-9.895-.144c-2.555-.117-4.3-.523-5.826-1.116-1.58-.613-2.918-1.434-4.252-2.768-1.334-1.334-2.155-2.673-2.768-4.25-.593-1.528-1-3.272-1.116-5.827-.116-2.56-.144-3.377-.144-9.895s.028-7.335.144-9.895c.117-2.555.523-4.3 1.116-5.826.613-1.58 1.434-2.918 2.768-4.252 1.334-1.334 2.673-2.155 4.25-2.768 1.528-.593 3.272-1 5.827-1.116 2.56-.116 3.377-.144 9.895-.144zm0 4c-6.514 0-7.285.025-9.858.142-2.378.11-3.67.506-4.53.84-1.14.443-1.95.97-2.805 1.825-.854.854-1.382 1.666-1.825 2.805-.334.86-.73 2.152-.84 4.53-.117 2.573-.142 3.344-.142 9.858 0 6.514.025 7.285.142 9.858.11 2.378.506 3.67.84 4.53.443 1.14.972 1.95 1.825 2.805.854.854 1.666 1.382 2.805 1.825.86.334 2.152.73 4.53.84 2.572.117 3.344.142 9.858.142 6.514 0 7.286-.025 9.858-.142 2.378-.11 3.67-.506 4.53-.84 1.14-.443 1.95-.97 2.805-1.825.854-.854 1.382-1.666 1.825-2.805.334-.86.73-2.152.84-4.53.117-2.573.142-3.344.142-9.858 0-6.514-.025-7.285-.142-9.858-.11-2.378-.506-3.67-.84-4.53-.443-1.14-.97-1.95-1.825-2.805-.854-.854-1.666-1.382-2.805-1.825-.86-.334-2.152-.73-4.53-.84-2.573-.117-3.344-.142-9.858-.142zm0 8c6.627 0 12 5.373 12 12s-5.373 12-12 12-12-5.373-12-12 5.373-12 12-12zm0 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm16-21c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z' transform='translate(-568 -3920)' fill='url(%23a)' fill-rule='evenodd'/%3E%3C/svg%3E")
            }

            @media all and (-ms-high-contrast: none),(-ms-high-contrast: active) {
                .contacts .channels>div>div.instagram a::before {
                    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath d='M592 3920c6.518 0 7.335.028 9.895.144 2.555.117 4.3.523 5.826 1.116 1.58.613 2.918 1.434 4.252 2.768 1.334 1.334 2.155 2.673 2.768 4.25.593 1.528 1 3.272 1.116 5.827.116 2.56.144 3.377.144 9.895s-.028 7.335-.144 9.895c-.117 2.555-.523 4.3-1.116 5.826-.613 1.58-1.434 2.918-2.768 4.252-1.334 1.334-2.673 2.155-4.25 2.768-1.528.593-3.272 1-5.827 1.116-2.56.116-3.377.144-9.895.144s-7.335-.028-9.895-.144c-2.555-.117-4.3-.523-5.826-1.116-1.58-.613-2.918-1.434-4.252-2.768-1.334-1.334-2.155-2.673-2.768-4.25-.593-1.528-1-3.272-1.116-5.827-.116-2.56-.144-3.377-.144-9.895s.028-7.335.144-9.895c.117-2.555.523-4.3 1.116-5.826.613-1.58 1.434-2.918 2.768-4.252 1.334-1.334 2.673-2.155 4.25-2.768 1.528-.593 3.272-1 5.827-1.116 2.56-.116 3.377-.144 9.895-.144zm0 4c-6.514 0-7.285.025-9.858.142-2.378.11-3.67.506-4.53.84-1.14.443-1.95.97-2.805 1.825-.854.854-1.382 1.666-1.825 2.805-.334.86-.73 2.152-.84 4.53-.117 2.573-.142 3.344-.142 9.858 0 6.514.025 7.285.142 9.858.11 2.378.506 3.67.84 4.53.443 1.14.972 1.95 1.825 2.805.854.854 1.666 1.382 2.805 1.825.86.334 2.152.73 4.53.84 2.572.117 3.344.142 9.858.142 6.514 0 7.286-.025 9.858-.142 2.378-.11 3.67-.506 4.53-.84 1.14-.443 1.95-.97 2.805-1.825.854-.854 1.382-1.666 1.825-2.805.334-.86.73-2.152.84-4.53.117-2.573.142-3.344.142-9.858 0-6.514-.025-7.285-.142-9.858-.11-2.378-.506-3.67-.84-4.53-.443-1.14-.97-1.95-1.825-2.805-.854-.854-1.666-1.382-2.805-1.825-.86-.334-2.152-.73-4.53-.84-2.573-.117-3.344-.142-9.858-.142zm0 8c6.627 0 12 5.373 12 12s-5.373 12-12 12-12-5.373-12-12 5.373-12 12-12zm0 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm16-21c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z' transform='translate(-568 -3920)' fill='%23CC5885' fill-rule='evenodd'/%3E%3C/svg%3E")
                }

                .contacts .channels>div>div.instagram a[href='']::before {
                    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath d='M592 3920c6.518 0 7.335.028 9.895.144 2.555.117 4.3.523 5.826 1.116 1.58.613 2.918 1.434 4.252 2.768 1.334 1.334 2.155 2.673 2.768 4.25.593 1.528 1 3.272 1.116 5.827.116 2.56.144 3.377.144 9.895s-.028 7.335-.144 9.895c-.117 2.555-.523 4.3-1.116 5.826-.613 1.58-1.434 2.918-2.768 4.252-1.334 1.334-2.673 2.155-4.25 2.768-1.528.593-3.272 1-5.827 1.116-2.56.116-3.377.144-9.895.144s-7.335-.028-9.895-.144c-2.555-.117-4.3-.523-5.826-1.116-1.58-.613-2.918-1.434-4.252-2.768-1.334-1.334-2.155-2.673-2.768-4.25-.593-1.528-1-3.272-1.116-5.827-.116-2.56-.144-3.377-.144-9.895s.028-7.335.144-9.895c.117-2.555.523-4.3 1.116-5.826.613-1.58 1.434-2.918 2.768-4.252 1.334-1.334 2.673-2.155 4.25-2.768 1.528-.593 3.272-1 5.827-1.116 2.56-.116 3.377-.144 9.895-.144zm0 4c-6.514 0-7.285.025-9.858.142-2.378.11-3.67.506-4.53.84-1.14.443-1.95.97-2.805 1.825-.854.854-1.382 1.666-1.825 2.805-.334.86-.73 2.152-.84 4.53-.117 2.573-.142 3.344-.142 9.858 0 6.514.025 7.285.142 9.858.11 2.378.506 3.67.84 4.53.443 1.14.972 1.95 1.825 2.805.854.854 1.666 1.382 2.805 1.825.86.334 2.152.73 4.53.84 2.572.117 3.344.142 9.858.142 6.514 0 7.286-.025 9.858-.142 2.378-.11 3.67-.506 4.53-.84 1.14-.443 1.95-.97 2.805-1.825.854-.854 1.382-1.666 1.825-2.805.334-.86.73-2.152.84-4.53.117-2.573.142-3.344.142-9.858 0-6.514-.025-7.285-.142-9.858-.11-2.378-.506-3.67-.84-4.53-.443-1.14-.97-1.95-1.825-2.805-.854-.854-1.666-1.382-2.805-1.825-.86-.334-2.152-.73-4.53-.84-2.573-.117-3.344-.142-9.858-.142zm0 8c6.627 0 12 5.373 12 12s-5.373 12-12 12-12-5.373-12-12 5.373-12 12-12zm0 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm16-21c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z' transform='translate(-568 -3920)' fill='%23999' fill-rule='evenodd'/%3E%3C/svg%3E")
                }
            }

            @supports (-ms-ime-align: auto) {
                .contacts .channels>div>div.instagram a::before {
                    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath d='M592 3920c6.518 0 7.335.028 9.895.144 2.555.117 4.3.523 5.826 1.116 1.58.613 2.918 1.434 4.252 2.768 1.334 1.334 2.155 2.673 2.768 4.25.593 1.528 1 3.272 1.116 5.827.116 2.56.144 3.377.144 9.895s-.028 7.335-.144 9.895c-.117 2.555-.523 4.3-1.116 5.826-.613 1.58-1.434 2.918-2.768 4.252-1.334 1.334-2.673 2.155-4.25 2.768-1.528.593-3.272 1-5.827 1.116-2.56.116-3.377.144-9.895.144s-7.335-.028-9.895-.144c-2.555-.117-4.3-.523-5.826-1.116-1.58-.613-2.918-1.434-4.252-2.768-1.334-1.334-2.155-2.673-2.768-4.25-.593-1.528-1-3.272-1.116-5.827-.116-2.56-.144-3.377-.144-9.895s.028-7.335.144-9.895c.117-2.555.523-4.3 1.116-5.826.613-1.58 1.434-2.918 2.768-4.252 1.334-1.334 2.673-2.155 4.25-2.768 1.528-.593 3.272-1 5.827-1.116 2.56-.116 3.377-.144 9.895-.144zm0 4c-6.514 0-7.285.025-9.858.142-2.378.11-3.67.506-4.53.84-1.14.443-1.95.97-2.805 1.825-.854.854-1.382 1.666-1.825 2.805-.334.86-.73 2.152-.84 4.53-.117 2.573-.142 3.344-.142 9.858 0 6.514.025 7.285.142 9.858.11 2.378.506 3.67.84 4.53.443 1.14.972 1.95 1.825 2.805.854.854 1.666 1.382 2.805 1.825.86.334 2.152.73 4.53.84 2.572.117 3.344.142 9.858.142 6.514 0 7.286-.025 9.858-.142 2.378-.11 3.67-.506 4.53-.84 1.14-.443 1.95-.97 2.805-1.825.854-.854 1.382-1.666 1.825-2.805.334-.86.73-2.152.84-4.53.117-2.573.142-3.344.142-9.858 0-6.514-.025-7.285-.142-9.858-.11-2.378-.506-3.67-.84-4.53-.443-1.14-.97-1.95-1.825-2.805-.854-.854-1.666-1.382-2.805-1.825-.86-.334-2.152-.73-4.53-.84-2.573-.117-3.344-.142-9.858-.142zm0 8c6.627 0 12 5.373 12 12s-5.373 12-12 12-12-5.373-12-12 5.373-12 12-12zm0 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm16-21c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z' transform='translate(-568 -3920)' fill='%23CC5885' fill-rule='evenodd'/%3E%3C/svg%3E")
                }

                .contacts .channels>div>div.instagram a[href='']::before {
                    background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath d='M592 3920c6.518 0 7.335.028 9.895.144 2.555.117 4.3.523 5.826 1.116 1.58.613 2.918 1.434 4.252 2.768 1.334 1.334 2.155 2.673 2.768 4.25.593 1.528 1 3.272 1.116 5.827.116 2.56.144 3.377.144 9.895s-.028 7.335-.144 9.895c-.117 2.555-.523 4.3-1.116 5.826-.613 1.58-1.434 2.918-2.768 4.252-1.334 1.334-2.673 2.155-4.25 2.768-1.528.593-3.272 1-5.827 1.116-2.56.116-3.377.144-9.895.144s-7.335-.028-9.895-.144c-2.555-.117-4.3-.523-5.826-1.116-1.58-.613-2.918-1.434-4.252-2.768-1.334-1.334-2.155-2.673-2.768-4.25-.593-1.528-1-3.272-1.116-5.827-.116-2.56-.144-3.377-.144-9.895s.028-7.335.144-9.895c.117-2.555.523-4.3 1.116-5.826.613-1.58 1.434-2.918 2.768-4.252 1.334-1.334 2.673-2.155 4.25-2.768 1.528-.593 3.272-1 5.827-1.116 2.56-.116 3.377-.144 9.895-.144zm0 4c-6.514 0-7.285.025-9.858.142-2.378.11-3.67.506-4.53.84-1.14.443-1.95.97-2.805 1.825-.854.854-1.382 1.666-1.825 2.805-.334.86-.73 2.152-.84 4.53-.117 2.573-.142 3.344-.142 9.858 0 6.514.025 7.285.142 9.858.11 2.378.506 3.67.84 4.53.443 1.14.972 1.95 1.825 2.805.854.854 1.666 1.382 2.805 1.825.86.334 2.152.73 4.53.84 2.572.117 3.344.142 9.858.142 6.514 0 7.286-.025 9.858-.142 2.378-.11 3.67-.506 4.53-.84 1.14-.443 1.95-.97 2.805-1.825.854-.854 1.382-1.666 1.825-2.805.334-.86.73-2.152.84-4.53.117-2.573.142-3.344.142-9.858 0-6.514-.025-7.285-.142-9.858-.11-2.378-.506-3.67-.84-4.53-.443-1.14-.97-1.95-1.825-2.805-.854-.854-1.666-1.382-2.805-1.825-.86-.334-2.152-.73-4.53-.84-2.573-.117-3.344-.142-9.858-.142zm0 8c6.627 0 12 5.373 12 12s-5.373 12-12 12-12-5.373-12-12 5.373-12 12-12zm0 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm16-21c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z' transform='translate(-568 -3920)' fill='%23999' fill-rule='evenodd'/%3E%3C/svg%3E")
                }
            }

            .contacts .channels>div>div.foursquare a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='36' height='50' viewBox='0 0 36 50'%3E%3Cpath fill='%23F94877' fill-rule='evenodd' d='M3.226.89c-.76-.003-1.496.3-2.034.838-.538.536-.842 1.27-.843 2.03L.28 46.185c-.005 1.185.742 2.267 1.85 2.69 1.106.42 2.386.11 3.172-.777L17.88 33.93h8.968c.653 0 1.29-.224 1.8-.633.51-.408.865-.978 1.007-1.616l6.042-27.197c.188-.845-.017-1.74-.558-2.416-.542-.677-1.367-1.077-2.234-1.08L3.23.888h-.004zm3.35 5.147h.003l22.068.07c.298 0 .592.143.778.376.185.233.26.55.194.842l-1.376 6.17c-.1.438-.526.78-.976.78h-10.28c-.458-.005-1.11-.015-1.307.597-.183.572-.758 2.918-.758 3.38 0 .462.188.91.515 1.234.326.32.774.504 1.23.5H25.567c.3 0 .594.14.78.374.187.233.26.552.196.843l-1.458 6.536c-.097.44-.525.784-.976.784h-7.56c-.49-.002-.964.213-1.292.58-.018.02-.036.038-.055.056L5.555 40.198c.006-.02 0-33.162 0-33.162 0-.523.498-1 1.02-1z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.foursquare a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='36' height='50' viewBox='0 0 36 50'%3E%3Cpath fill='%23999' fill-rule='evenodd' d='M3.226.89c-.76-.003-1.496.3-2.034.838-.538.536-.842 1.27-.843 2.03L.28 46.185c-.005 1.185.742 2.267 1.85 2.69 1.106.42 2.386.11 3.172-.777L17.88 33.93h8.968c.653 0 1.29-.224 1.8-.633.51-.408.865-.978 1.007-1.616l6.042-27.197c.188-.845-.017-1.74-.558-2.416-.542-.677-1.367-1.077-2.234-1.08L3.23.888h-.004zm3.35 5.147h.003l22.068.07c.298 0 .592.143.778.376.185.233.26.55.194.842l-1.376 6.17c-.1.438-.526.78-.976.78h-10.28c-.458-.005-1.11-.015-1.307.597-.183.572-.758 2.918-.758 3.38 0 .462.188.91.515 1.234.326.32.774.504 1.23.5H25.567c.3 0 .594.14.78.374.187.233.26.552.196.843l-1.458 6.536c-.097.44-.525.784-.976.784h-7.56c-.49-.002-.964.213-1.292.58-.018.02-.036.038-.055.056L5.555 40.198c.006-.02 0-33.162 0-33.162 0-.523.498-1 1.02-1z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.yelp a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='39' height='52' viewBox='0 0 39 52'%3E%3Cpath fill='%23D93030' fill-rule='evenodd' d='M35.508 27.327L25.312 29.97c-2.507.423-3.424-1.573-2.946-2.644.033-.074.054-.155.1-.22.714-.99 4.075-5.638 7.325-10.125 3.252-4.492 7.428 3.973 8.497 6.607 1.074 2.628-.575 3.17-.575 3.17l-2.2.57h-.004zM14.55 35.454l-8.477 10.26s-1.06 1.465 1.444 3.025c2.506 1.56 11.172 6.155 11.172.39V36.138c0-1.266-2.17-2.682-4.14-.684zm-10.93.587c5.184-1.634 10.54-3.326 11.68-3.688 1.142-.36 1.805-2.686-.55-3.87l-2.91-1.156H.53c-.72 3.502-1.422 10.143 3.09 8.715zM.83 26.01c-.09.346-.196.798-.302 1.316H11.84L3.15 23.87s-1.614-.526-2.32 2.14zm36.066 10.95c-4.92-1.62-10.01-3.295-11.1-3.648-1.08-.36-2.9 1.086-1.744 3.335l6.384 10.097s.955 1.314 2.994-.38c2.036-1.693 8.39-7.785 3.466-9.405zM17.03 25.415s2.764 2.194 3.855-1.116c.794-2.407-1.143-22.06-1.143-22.06s.14-3.91-9.42-.42C2.898 4.194 4.897 7.268 4.897 7.268L17.03 25.416z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.yelp a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='39' height='52' viewBox='0 0 39 52'%3E%3Cpath fill='%23999' fill-rule='evenodd' d='M35.508 27.327L25.312 29.97c-2.507.423-3.424-1.573-2.946-2.644.033-.074.054-.155.1-.22.714-.99 4.075-5.638 7.325-10.125 3.252-4.492 7.428 3.973 8.497 6.607 1.074 2.628-.575 3.17-.575 3.17l-2.2.57h-.004zM14.55 35.454l-8.477 10.26s-1.06 1.465 1.444 3.025c2.506 1.56 11.172 6.155 11.172.39V36.138c0-1.266-2.17-2.682-4.14-.684zm-10.93.587c5.184-1.634 10.54-3.326 11.68-3.688 1.142-.36 1.805-2.686-.55-3.87l-2.91-1.156H.53c-.72 3.502-1.422 10.143 3.09 8.715zM.83 26.01c-.09.346-.196.798-.302 1.316H11.84L3.15 23.87s-1.614-.526-2.32 2.14zm36.066 10.95c-4.92-1.62-10.01-3.295-11.1-3.648-1.08-.36-2.9 1.086-1.744 3.335l6.384 10.097s.955 1.314 2.994-.38c2.036-1.693 8.39-7.785 3.466-9.405zM17.03 25.415s2.764 2.194 3.855-1.116c.794-2.407-1.143-22.06-1.143-22.06s.14-3.91-9.42-.42C2.898 4.194 4.897 7.268 4.897 7.268L17.03 25.416z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.vk a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='320' height='180.268' viewBox='90 159.732 320 180.268'%3E%3Cpath fill='%23537599' d='M261.278 159.733c-17.03.08-27.892.1-43.2.1-12.807 0-19.998 5.184-20.227 8.275-.207 2.827 6.328 5.112 10.3 7.4 3.838 2.378 7.303 9.926 7.303 15.025v44.476c0 4.225-.96 7.17-4.375 9.923-1.627 1.312-3.56 1.66-5.65 1.65-1.69-.01-3.992-.325-5.575-2.375-16.867-21.834-16.923-24.53-40.55-68.528-1.147-2.134-2.28-4.398-4.627-6.1s-5.824-2.825-11.4-2.825c-18.99 0-30.713.275-43.2.275-11.82 0-10.684 7.25-9.1 10.55 14.17 29.55 28.56 57.764 45.1 86.402 19.37 33.538 37.08 53.683 66.877 68.152 6.917 3.358 19.388 6.825 33.8 6.825h30.627c3.935 0 10.475-3.104 10.475-7.275V308.71c0-6.57 6.55-8.96 10.125-10.575 4.21-1.903 8.626 1.097 10.85 3.476 17.122 18.305 15.176 16.314 30.776 32.7 3.525 3.706 6.188 5.65 12.85 5.65 44.995 0 45.032.088 55.777 0 2.95-.02 7.332-4.45 8.3-6.173 1.278-2.277 4.184-10.408-.475-15.676-15.812-17.88-31.93-34.25-47.376-50.5-1.178-1.24-2.068-2.917-2.1-4.626-.036-1.87 1.007-3.684 2.1-5.2 17.324-24.046 31.636-44.408 47.2-69.7 5.06-8.223 4.406-14.046 3.476-16.05-1.077-2.324-4.394-5.53-8.2-5.55-20.786-.118-29.777-.41-51.95-.376-6.624.01-12.49-.5-16.126 7.475-9.746 21.368-25.646 53.973-39.45 67.527-2.55 2.5-5.955 4.36-8.926 4.374-2.972.015-6.132-2.01-6.575-6.85-.34-23.255-.056-43.095-.174-65.876-.036-6.964-2.972-8.755-5.2-10.3-3.024-2.096-7.8-2.743-11.477-2.725z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.vk a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='320' height='180.268' viewBox='90 159.732 320 180.268'%3E%3Cpath fill='%23999' d='M261.278 159.733c-17.03.08-27.892.1-43.2.1-12.807 0-19.998 5.184-20.227 8.275-.207 2.827 6.328 5.112 10.3 7.4 3.838 2.378 7.303 9.926 7.303 15.025v44.476c0 4.225-.96 7.17-4.375 9.923-1.627 1.312-3.56 1.66-5.65 1.65-1.69-.01-3.992-.325-5.575-2.375-16.867-21.834-16.923-24.53-40.55-68.528-1.147-2.134-2.28-4.398-4.627-6.1s-5.824-2.825-11.4-2.825c-18.99 0-30.713.275-43.2.275-11.82 0-10.684 7.25-9.1 10.55 14.17 29.55 28.56 57.764 45.1 86.402 19.37 33.538 37.08 53.683 66.877 68.152 6.917 3.358 19.388 6.825 33.8 6.825h30.627c3.935 0 10.475-3.104 10.475-7.275V308.71c0-6.57 6.55-8.96 10.125-10.575 4.21-1.903 8.626 1.097 10.85 3.476 17.122 18.305 15.176 16.314 30.776 32.7 3.525 3.706 6.188 5.65 12.85 5.65 44.995 0 45.032.088 55.777 0 2.95-.02 7.332-4.45 8.3-6.173 1.278-2.277 4.184-10.408-.475-15.676-15.812-17.88-31.93-34.25-47.376-50.5-1.178-1.24-2.068-2.917-2.1-4.626-.036-1.87 1.007-3.684 2.1-5.2 17.324-24.046 31.636-44.408 47.2-69.7 5.06-8.223 4.406-14.046 3.476-16.05-1.077-2.324-4.394-5.53-8.2-5.55-20.786-.118-29.777-.41-51.95-.376-6.624.01-12.49-.5-16.126 7.475-9.746 21.368-25.646 53.973-39.45 67.527-2.55 2.5-5.955 4.36-8.926 4.374-2.972.015-6.132-2.01-6.575-6.85-.34-23.255-.056-43.095-.174-65.876-.036-6.964-2.972-8.755-5.2-10.3-3.024-2.096-7.8-2.743-11.477-2.725z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.tumblr a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='27' height='46' viewBox='0 0 27 46'%3E%3Cpath fill='%2339475D' fill-rule='nonzero' d='M26.8 43.156c-1.538 1.662-5.102 2.79-8.293 2.844h-.35C7.437 46 5.11 38.022 5.11 33.364V20.426H.884c-.234 0-.46-.094-.626-.262-.167-.17-.26-.397-.26-.634v-6.11c0-.645.402-1.22 1.002-1.434 5.503-1.963 7.23-6.824 7.485-10.52C8.557.48 9.067 0 9.913 0h6.294c.49 0 .886.4.886.896v10.348h7.368c.49 0 .886.4.888.894v7.343c0 .238-.094.466-.26.634-.166.168-.392.263-.627.262h-7.4v11.966c0 3.004 1.955 3.834 3.163 3.834 1.16-.028 2.3-.386 2.872-.62.424-.17.797-.285 1.13-.2.312.078.516.3.654.707l1.952 5.775c.16.463.295.964-.033 1.318z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.tumblr a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='27' height='46' viewBox='0 0 27 46'%3E%3Cpath fill='%23999' fill-rule='nonzero' d='M26.8 43.156c-1.538 1.662-5.102 2.79-8.293 2.844h-.35C7.437 46 5.11 38.022 5.11 33.364V20.426H.884c-.234 0-.46-.094-.626-.262-.167-.17-.26-.397-.26-.634v-6.11c0-.645.402-1.22 1.002-1.434 5.503-1.963 7.23-6.824 7.485-10.52C8.557.48 9.067 0 9.913 0h6.294c.49 0 .886.4.886.896v10.348h7.368c.49 0 .886.4.888.894v7.343c0 .238-.094.466-.26.634-.166.168-.392.263-.627.262h-7.4v11.966c0 3.004 1.955 3.834 3.163 3.834 1.16-.028 2.3-.386 2.872-.62.424-.17.797-.285 1.13-.2.312.078.516.3.654.707l1.952 5.775c.16.463.295.964-.033 1.318z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.etsy a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 52 52'%3E%3Cpath fill='%23CE6F2B' fill-rule='evenodd' clip-rule='evenodd' d='M39.93 34.434c-.736.963-1.646 1.375-2.5 1.375-.547 0-.81-.24-.893-.62l-.305-1.558-.852.04c-.163.918-.325 1.938-.55 2.776.51.38 1.36.578 2.03.578 1.4 0 3.53-.18 5.48-4.73l3.266-7.586c.265-.62.365-.68 1.137-.98l.426-.158v-.7l-1.93.1-2.068-.1v.7l.528.158c.527.16.77.36.77.72 0 .18-.06.358-.162.638-.305.76-2.373 5.55-2.373 5.55-.893-2.177-2.07-5.31-2.273-5.93-.04-.12-.06-.22-.06-.32 0-.318.222-.578.708-.678l.67-.14v-.698l-2.78.1-2.212-.1v.7l.365.118c.508.16.63.3.934.998 1.684 3.794 2.413 5.69 3.488 8.404 0 0-.346.688-.845 1.342zm-11.61-4.988c.04.44.063 1 .063 1.52 0 .54-.02 1.04-.062 1.28 0 0 1.546.56 3.11.56 2.115 0 3.803-1 3.803-2.96 0-3.36-5.123-2.86-5.123-5.12 0-.94.854-1.3 1.79-1.3.73 0 1.34.26 1.463.64l.508 1.5.753-.04c.062-.8.102-1.72.225-2.46-.65-.28-2.014-.44-2.867-.44-1.99 0-3.597.86-3.597 2.78 0 3.34 5 2.66 5 5.12 0 .88-.55 1.5-1.788 1.5-1.138 0-1.708-.58-1.93-1.16l-.57-1.438-.774.018zm-7.216-6.625c-.61.4-1.22.54-1.463.56v.76h1.81v6.142c0 1.72 1.16 2.56 2.704 2.56 1.2 0 2.44-.5 2.867-1.54l-.426-.54c-.203.34-.854.84-1.667.84-.895 0-1.382-.6-1.382-2.12v-5.42l3.01.22.162-1.36-3.17.12v-3.04l-.876-.02c-.285 1.24-.57 2.2-1.566 2.84zm-10.49-3.4c0-.2.02-.32.366-.32h4.655c.813 0 1.26.682 1.586 1.962l.265 1.02h.793c.142-2.9.264-4.16.264-4.16s-1.992.22-3.17.22H9.414l-3.192-.1v.84l1.078.2c.753.14.936.3.997.98 0 0 .062 2 .062 5.3s-.063 5.28-.063 5.28c0 .6-.244.82-.996.96l-1.077.2v.84l3.192-.1h5.326c1.2 0 3.985.1 3.985.1.06-.72.468-3.98.53-4.34H18.5l-.792 1.78c-.63 1.4-1.545 1.5-2.562 1.5h-3.03c-1.016 0-1.503-.4-1.503-1.26v-4.56s2.216 0 2.988.06c.57.04.915.2 1.098.98l.245 1.04h.874l-.062-2.62.122-2.64h-.874l-.284 1.16c-.184.76-.305.9-1.098.98-.895.1-3.01.08-3.01.08v-5.38zM26 52c14.36 0 26-11.64 26-26S40.36 0 26 0 0 11.64 0 26s11.64 26 26 26z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.etsy a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 52 52'%3E%3Cpath fill='%23999' fill-rule='evenodd' clip-rule='evenodd' d='M39.93 34.434c-.736.963-1.646 1.375-2.5 1.375-.547 0-.81-.24-.893-.62l-.305-1.558-.852.04c-.163.918-.325 1.938-.55 2.776.51.38 1.36.578 2.03.578 1.4 0 3.53-.18 5.48-4.73l3.266-7.586c.265-.62.365-.68 1.137-.98l.426-.158v-.7l-1.93.1-2.068-.1v.7l.528.158c.527.16.77.36.77.72 0 .18-.06.358-.162.638-.305.76-2.373 5.55-2.373 5.55-.893-2.177-2.07-5.31-2.273-5.93-.04-.12-.06-.22-.06-.32 0-.318.222-.578.708-.678l.67-.14v-.698l-2.78.1-2.212-.1v.7l.365.118c.508.16.63.3.934.998 1.684 3.794 2.413 5.69 3.488 8.404 0 0-.346.688-.845 1.342zm-11.61-4.988c.04.44.063 1 .063 1.52 0 .54-.02 1.04-.062 1.28 0 0 1.546.56 3.11.56 2.115 0 3.803-1 3.803-2.96 0-3.36-5.123-2.86-5.123-5.12 0-.94.854-1.3 1.79-1.3.73 0 1.34.26 1.463.64l.508 1.5.753-.04c.062-.8.102-1.72.225-2.46-.65-.28-2.014-.44-2.867-.44-1.99 0-3.597.86-3.597 2.78 0 3.34 5 2.66 5 5.12 0 .88-.55 1.5-1.788 1.5-1.138 0-1.708-.58-1.93-1.16l-.57-1.438-.774.018zm-7.216-6.625c-.61.4-1.22.54-1.463.56v.76h1.81v6.142c0 1.72 1.16 2.56 2.704 2.56 1.2 0 2.44-.5 2.867-1.54l-.426-.54c-.203.34-.854.84-1.667.84-.895 0-1.382-.6-1.382-2.12v-5.42l3.01.22.162-1.36-3.17.12v-3.04l-.876-.02c-.285 1.24-.57 2.2-1.566 2.84zm-10.49-3.4c0-.2.02-.32.366-.32h4.655c.813 0 1.26.682 1.586 1.962l.265 1.02h.793c.142-2.9.264-4.16.264-4.16s-1.992.22-3.17.22H9.414l-3.192-.1v.84l1.078.2c.753.14.936.3.997.98 0 0 .062 2 .062 5.3s-.063 5.28-.063 5.28c0 .6-.244.82-.996.96l-1.077.2v.84l3.192-.1h5.326c1.2 0 3.985.1 3.985.1.06-.72.468-3.98.53-4.34H18.5l-.792 1.78c-.63 1.4-1.545 1.5-2.562 1.5h-3.03c-1.016 0-1.503-.4-1.503-1.26v-4.56s2.216 0 2.988.06c.57.04.915.2 1.098.98l.245 1.04h.874l-.062-2.62.122-2.64h-.874l-.284 1.16c-.184.76-.305.9-1.098.98-.895.1-3.01.08-3.01.08v-5.38zM26 52c14.36 0 26-11.64 26-26S40.36 0 26 0 0 11.64 0 26s11.64 26 26 26z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.google a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='58' height='38' viewBox='0 0 58 38'%3E%3Cpath fill='%23D95032' fill-rule='evenodd' d='M37.53 15.438c.242 1.282.363 2.612.363 3.99C37.893 30.28 30.498 38 19.333 38 8.653 38 0 29.497 0 19 0 8.502 8.652 0 19.333 0c5.22 0 9.57 1.9 12.93 4.94l-5.438 5.367c-2.03-1.9-4.592-2.85-7.492-2.85-6.38 0-11.6 5.225-11.6 11.543 0 6.27 5.22 11.566 11.6 11.566 5.8 0 9.74-3.253 10.537-7.718H19.333v-7.41H37.53zm14.428 1.187v-5.938h-4.833v5.938h-6.042v4.75h6.042v5.938h4.833v-5.938H58v-4.75h-6.042z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.google a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='58' height='38' viewBox='0 0 58 38'%3E%3Cpath fill='%23999' fill-rule='evenodd' d='M37.53 15.438c.242 1.282.363 2.612.363 3.99C37.893 30.28 30.498 38 19.333 38 8.653 38 0 29.497 0 19 0 8.502 8.652 0 19.333 0c5.22 0 9.57 1.9 12.93 4.94l-5.438 5.367c-2.03-1.9-4.592-2.85-7.492-2.85-6.38 0-11.6 5.225-11.6 11.543 0 6.27 5.22 11.566 11.6 11.566 5.8 0 9.74-3.253 10.537-7.718H19.333v-7.41H37.53zm14.428 1.187v-5.938h-4.833v5.938h-6.042v4.75h6.042v5.938h4.833v-5.938H58v-4.75h-6.042z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.youtube a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='36' viewBox='0 0 50 36'%3E%3Cpath fill='red' fill-rule='evenodd' d='M48.955 5.622C50 9.632 50 18 50 18s0 8.368-1.045 12.38c-.575 2.21-2.27 3.954-4.42 4.546C40.635 36 25 36 25 36S9.364 36 5.465 34.926c-2.15-.592-3.845-2.335-4.42-4.547C0 26.367 0 18 0 18S0 9.632 1.045 5.622c.575-2.213 2.27-3.956 4.42-4.547C9.365 0 25 0 25 0s15.636 0 19.535 1.075c2.15.59 3.845 2.334 4.42 4.547zM19 25l13-7.5L19 10v15z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.youtube a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='36' viewBox='0 0 50 36'%3E%3Cpath fill='%23999' fill-rule='evenodd' d='M48.955 5.622C50 9.632 50 18 50 18s0 8.368-1.045 12.38c-.575 2.21-2.27 3.954-4.42 4.546C40.635 36 25 36 25 36S9.364 36 5.465 34.926c-2.15-.592-3.845-2.335-4.42-4.547C0 26.367 0 18 0 18S0 9.632 1.045 5.622c.575-2.213 2.27-3.956 4.42-4.547C9.365 0 25 0 25 0s15.636 0 19.535 1.075c2.15.59 3.845 2.334 4.42 4.547zM19 25l13-7.5L19 10v15z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.vimeo a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath fill='%231BB7EA' d='M22.396 7.164c-.093 2.026-1.507 4.8-4.245 8.32C15.323 19.16 12.93 21 10.97 21c-1.214 0-2.24-1.12-3.08-3.36-.56-2.052-1.118-4.105-1.68-6.158-.622-2.24-1.29-3.36-2.004-3.36-.156 0-.7.328-1.634.98l-.978-1.26c1.027-.903 2.04-1.806 3.037-2.71C6 3.95 7.03 3.328 7.716 3.265c1.62-.156 2.616.95 2.99 3.32.404 2.558.685 4.148.84 4.77.468 2.12.982 3.18 1.543 3.18.435 0 1.09-.687 1.963-2.064.872-1.376 1.34-2.422 1.402-3.142.125-1.187-.343-1.782-1.4-1.782-.5 0-1.013.115-1.542.34 1.023-3.35 2.977-4.976 5.862-4.883 2.14.063 3.148 1.45 3.024 4.16z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.vimeo a[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath fill='%23999' d='M22.396 7.164c-.093 2.026-1.507 4.8-4.245 8.32C15.323 19.16 12.93 21 10.97 21c-1.214 0-2.24-1.12-3.08-3.36-.56-2.052-1.118-4.105-1.68-6.158-.622-2.24-1.29-3.36-2.004-3.36-.156 0-.7.328-1.634.98l-.978-1.26c1.027-.903 2.04-1.806 3.037-2.71C6 3.95 7.03 3.328 7.716 3.265c1.62-.156 2.616.95 2.99 3.32.404 2.558.685 4.148.84 4.77.468 2.12.982 3.18 1.543 3.18.435 0 1.09-.687 1.963-2.064.872-1.376 1.34-2.422 1.402-3.142.125-1.187-.343-1.782-1.4-1.782-.5 0-1.013.115-1.542.34 1.023-3.35 2.977-4.976 5.862-4.883 2.14.063 3.148 1.45 3.024 4.16z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.wechat a::before,.contacts .channels>div>div.wechat span::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='57' height='48' viewBox='0 0 57 48'%3E%3Cpath fill='%232DC200' d='M56.997 30.744c0-8.163-7.95-14.416-17.173-14.416-9.766 0-17.554 6.394-17.554 14.557 0 8.178 7.408 14.947 17.565 15.003 2.044.012 5.09-.51 7.143-1.362 0 0 4.908 2.955 5.183 2.934s.416-.238.428-.424c.01-.185-1.564-4.797-1.564-4.797 4.214-3.28 5.973-6.89 5.973-11.496zm-23.6-3.014c-1.286 0-2.327-1.036-2.327-2.314s1.04-2.314 2.326-2.314 2.327 1.036 2.327 2.314c0 1.28-1.04 2.314-2.327 2.314zm12.44 0c-1.284 0-2.325-1.036-2.325-2.314s1.04-2.314 2.326-2.314 2.328 1.036 2.328 2.314c0 1.28-1.043 2.314-2.328 2.314z'/%3E%3Cpath fill='%232DC200' d='M20.55.043C9.48-.123.28 7.957.28 17.485c0 5.5 2.604 10.272 7.647 13.775 0 0-1.848 6.057-1.822 6.18.026.12.428.358.568.28s6.68-3.95 6.68-3.95c5.014 1.708 7.937 1.14 8.104 1.128-.5-1.454-.828-3.72-.455-5.854C22.956 17.872 34.476 14.396 40.79 14.99 39.046 6.92 31.473.206 20.55.043zm-7.695 14.394c-1.453 0-2.63-1.17-2.63-2.612s1.177-2.612 2.63-2.612 2.63 1.17 2.63 2.612-1.177 2.612-2.63 2.612zm15.92 0c-1.452 0-2.63-1.17-2.63-2.612s1.178-2.612 2.63-2.612c1.453 0 2.63 1.17 2.63 2.612s-1.176 2.612-2.63 2.612z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.wechat a[href='']::before,.contacts .channels>div>div.wechat span[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='57' height='48' viewBox='0 0 57 48'%3E%3Cpath fill='%23999' d='M56.997 30.744c0-8.163-7.95-14.416-17.173-14.416-9.766 0-17.554 6.394-17.554 14.557 0 8.178 7.408 14.947 17.565 15.003 2.044.012 5.09-.51 7.143-1.362 0 0 4.908 2.955 5.183 2.934s.416-.238.428-.424c.01-.185-1.564-4.797-1.564-4.797 4.214-3.28 5.973-6.89 5.973-11.496zm-23.6-3.014c-1.286 0-2.327-1.036-2.327-2.314s1.04-2.314 2.326-2.314 2.327 1.036 2.327 2.314c0 1.28-1.04 2.314-2.327 2.314zm12.44 0c-1.284 0-2.325-1.036-2.325-2.314s1.04-2.314 2.326-2.314 2.328 1.036 2.328 2.314c0 1.28-1.043 2.314-2.328 2.314z'/%3E%3Cpath fill='%23999' d='M20.55.043C9.48-.123.28 7.957.28 17.485c0 5.5 2.604 10.272 7.647 13.775 0 0-1.848 6.057-1.822 6.18.026.12.428.358.568.28s6.68-3.95 6.68-3.95c5.014 1.708 7.937 1.14 8.104 1.128-.5-1.454-.828-3.72-.455-5.854C22.956 17.872 34.476 14.396 40.79 14.99 39.046 6.92 31.473.206 20.55.043zm-7.695 14.394c-1.453 0-2.63-1.17-2.63-2.612s1.177-2.612 2.63-2.612 2.63 1.17 2.63 2.612-1.177 2.612-2.63 2.612zm15.92 0c-1.452 0-2.63-1.17-2.63-2.612s1.178-2.612 2.63-2.612c1.453 0 2.63 1.17 2.63 2.612s-1.176 2.612-2.63 2.612z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.whatsapp a::before,.contacts .channels>div>div.whatsapp span::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60' viewBox='0 0 60 60'%3E%3Cpath fill='%2354CC61' d='M19.85 53.367L6.275 57.69 2.164 59l-1.74.553.584-1.73 5.775-17.068.063.737c-1.004-1.848-1.797-3.8-2.36-5.82-.687-2.45-1.034-4.986-1.034-7.536 0-7.484 2.972-14.597 8.295-19.88C17.07 2.973 24.22.036 31.733.036c7.51 0 14.658 2.94 19.977 8.225C57.03 13.546 60 20.66 60 28.145c0 7.483-2.97 14.594-8.293 19.877-5.32 5.283-12.47 8.222-19.98 8.222-2.39 0-4.76-.296-7.058-.884-1.9-.486-3.747-1.172-5.51-2.044l.69.053zm-.28-.88c1.702.842 3.488 1.506 5.328 1.977 2.23.57 4.526.856 6.83.856 7.258 0 14.176-2.837 19.33-7.954 5.138-5.1 8.02-11.974 8.02-19.222 0-7.25-2.88-14.125-8.017-19.23C45.91 3.798 38.995.958 31.736.958c-7.26 0-14.18 2.836-19.336 7.954-5.14 5.102-8.022 11.975-8.022 19.226 0 2.464.335 4.916.998 7.288.547 1.956 1.315 3.845 2.284 5.627L1.883 58.12l4.11-1.31 13.578-4.323z'/%3E%3Cpath fill='%2354CC61' d='M49.523 10.464C44.97 5.94 38.68 3.14 31.733 3.14c-6.95 0-13.243 2.798-17.8 7.32C9.377 14.984 6.56 21.234 6.56 28.135c0 2.317.32 4.564.917 6.7.594 2.124 1.462 4.134 2.563 5.99L5.678 53.71l-.346 1.02 1.024-.325 13.412-4.27c1.776.956 3.676 1.705 5.67 2.216 2.01.515 4.116.788 6.288.788 6.95 0 13.24-2.797 17.795-7.32 4.558-4.523 7.375-10.772 7.375-17.672 0-6.906-2.817-13.157-7.372-17.682zM46.686 36.1c-.07.574-.224 1.273-.494 2.026-.302.842-1.092 1.642-1.998 2.273-1.09.762-2.388 1.305-3.18 1.38-.177.016-.34.056-.506.096-.98.237-2.075.503-8.132-1.862-6.676-2.61-11.068-9.037-12.023-10.435-.08-.12-.136-.2-.15-.22l-.005-.004-.003-.005c-.38-.5-2.966-3.915-2.966-7.504 0-3.422 1.693-5.204 2.47-6.02l.123-.13c.327-.36.684-.604 1.03-.766.465-.22.908-.286 1.233-.286.245 0 .503.017.753.032.198.013.39.025.587.025.047 0 .083 0 .12-.004.56-.037 1.293-.084 1.955 1.496.07.167.43 1.033.804 1.942.588 1.42 1.226 2.962 1.336 3.185.113.22.206.467.234.744.03.298-.01.615-.177.95h-.003l-.102.207c-.188.386-.328.67-.664 1.063v.002c-.14.16-.253.296-.367.433-.25.3-.498.6-.718.82-.197.2-.413.414-.22.747.247.424.864 1.43 1.777 2.56.564.697 1.24 1.44 2.008 2.12 2.146 1.902 4.03 2.716 4.998 3.134.19.08.346.147.505.228.25.123.43.176.56.16.094-.012.19-.08.3-.207.263-.298.874-1.004 1.388-1.633.324-.397.62-.776.79-1.03v.002c.335-.51.696-.722 1.11-.77.366-.04.706.065 1.098.206.278.1.98.42 1.77.795 1.224.58 2.655 1.28 3.068 1.49.108.053.222.106.327.156.6.283 1 .472 1.23.854l.002.002c.152.252.233.91.13 1.747z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.whatsapp a[href='']::before,.contacts .channels>div>div.whatsapp span[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60' viewBox='0 0 60 60'%3E%3Cpath fill='%23999' d='M19.85 53.367L6.275 57.69 2.164 59l-1.74.553.584-1.73 5.775-17.068.063.737c-1.004-1.848-1.797-3.8-2.36-5.82-.687-2.45-1.034-4.986-1.034-7.536 0-7.484 2.972-14.597 8.295-19.88C17.07 2.973 24.22.036 31.733.036c7.51 0 14.658 2.94 19.977 8.225C57.03 13.546 60 20.66 60 28.145c0 7.483-2.97 14.594-8.293 19.877-5.32 5.283-12.47 8.222-19.98 8.222-2.39 0-4.76-.296-7.058-.884-1.9-.486-3.747-1.172-5.51-2.044l.69.053zm-.28-.88c1.702.842 3.488 1.506 5.328 1.977 2.23.57 4.526.856 6.83.856 7.258 0 14.176-2.837 19.33-7.954 5.138-5.1 8.02-11.974 8.02-19.222 0-7.25-2.88-14.125-8.017-19.23C45.91 3.798 38.995.958 31.736.958c-7.26 0-14.18 2.836-19.336 7.954-5.14 5.102-8.022 11.975-8.022 19.226 0 2.464.335 4.916.998 7.288.547 1.956 1.315 3.845 2.284 5.627L1.883 58.12l4.11-1.31 13.578-4.323z'/%3E%3Cpath fill='%23999' d='M49.523 10.464C44.97 5.94 38.68 3.14 31.733 3.14c-6.95 0-13.243 2.798-17.8 7.32C9.377 14.984 6.56 21.234 6.56 28.135c0 2.317.32 4.564.917 6.7.594 2.124 1.462 4.134 2.563 5.99L5.678 53.71l-.346 1.02 1.024-.325 13.412-4.27c1.776.956 3.676 1.705 5.67 2.216 2.01.515 4.116.788 6.288.788 6.95 0 13.24-2.797 17.795-7.32 4.558-4.523 7.375-10.772 7.375-17.672 0-6.906-2.817-13.157-7.372-17.682zM46.686 36.1c-.07.574-.224 1.273-.494 2.026-.302.842-1.092 1.642-1.998 2.273-1.09.762-2.388 1.305-3.18 1.38-.177.016-.34.056-.506.096-.98.237-2.075.503-8.132-1.862-6.676-2.61-11.068-9.037-12.023-10.435-.08-.12-.136-.2-.15-.22l-.005-.004-.003-.005c-.38-.5-2.966-3.915-2.966-7.504 0-3.422 1.693-5.204 2.47-6.02l.123-.13c.327-.36.684-.604 1.03-.766.465-.22.908-.286 1.233-.286.245 0 .503.017.753.032.198.013.39.025.587.025.047 0 .083 0 .12-.004.56-.037 1.293-.084 1.955 1.496.07.167.43 1.033.804 1.942.588 1.42 1.226 2.962 1.336 3.185.113.22.206.467.234.744.03.298-.01.615-.177.95h-.003l-.102.207c-.188.386-.328.67-.664 1.063v.002c-.14.16-.253.296-.367.433-.25.3-.498.6-.718.82-.197.2-.413.414-.22.747.247.424.864 1.43 1.777 2.56.564.697 1.24 1.44 2.008 2.12 2.146 1.902 4.03 2.716 4.998 3.134.19.08.346.147.505.228.25.123.43.176.56.16.094-.012.19-.08.3-.207.263-.298.874-1.004 1.388-1.633.324-.397.62-.776.79-1.03v.002c.335-.51.696-.722 1.11-.77.366-.04.706.065 1.098.206.278.1.98.42 1.77.795 1.224.58 2.655 1.28 3.068 1.49.108.053.222.106.327.156.6.283 1 .472 1.23.854l.002.002c.152.252.233.91.13 1.747z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.telegram a::before,.contacts .channels>div>div.telegram span::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 52 52'%3E%3Cpath fill='%2337AEE2' d='M26 0C11.64 0 0 11.64 0 26s11.64 26 26 26 26-11.64 26-26S40.36 0 26 0zm12.46 17.55l-4.264 20.38c-.2.957-1.32 1.387-2.11.81l-6.436-4.726-3.28 3.35c-.576.588-1.57.35-1.818-.435l-2.368-7.515-6.345-1.874c-.834-.245-.883-1.405-.074-1.72l24.97-9.73c.95-.37 1.932.46 1.723 1.46z'/%3E%3Cpath fill='%2337AEE2' d='M33.246 20.13L19.55 28.622c-.24.15-.35.443-.267.715l1.837 5.92c.04.124.22.107.234-.022l.447-3.97c.018-.152.09-.295.207-.396l11.598-10.256c.278-.247-.044-.68-.36-.485z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.telegram a[href='']::before,.contacts .channels>div>div.telegram span[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 52 52'%3E%3Cpath fill='%23999' d='M26 0C11.64 0 0 11.64 0 26s11.64 26 26 26 26-11.64 26-26S40.36 0 26 0zm12.46 17.55l-4.264 20.38c-.2.957-1.32 1.387-2.11.81l-6.436-4.726-3.28 3.35c-.576.588-1.57.35-1.818-.435l-2.368-7.515-6.345-1.874c-.834-.245-.883-1.405-.074-1.72l24.97-9.73c.95-.37 1.932.46 1.723 1.46z'/%3E%3Cpath fill='%23999' d='M33.246 20.13L19.55 28.622c-.24.15-.35.443-.267.715l1.837 5.92c.04.124.22.107.234-.022l.447-3.97c.018-.152.09-.295.207-.396l11.598-10.256c.278-.247-.044-.68-.36-.485z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.messenger a::before,.contacts .channels>div>div.messenger span::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='56' viewBox='0 0 56 56'%3E%3Cpath fill='%23007FFF' d='M28 0C12.536 0 0 11.607 0 25.926c0 8.16 4.072 15.437 10.435 20.19V56l9.534-5.232c2.543.704 5.24 1.084 8.03 1.084 15.465 0 28-11.607 28-25.926S43.465 0 28 0zm2.783 34.914l-7.13-7.605-13.914 7.604 15.303-16.248 7.304 7.605 13.74-7.604-15.304 16.248z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.messenger a[href='']::before,.contacts .channels>div>div.messenger span[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='56' viewBox='0 0 56 56'%3E%3Cpath fill='%23999' d='M28 0C12.536 0 0 11.607 0 25.926c0 8.16 4.072 15.437 10.435 20.19V56l9.534-5.232c2.543.704 5.24 1.084 8.03 1.084 15.465 0 28-11.607 28-25.926S43.465 0 28 0zm2.783 34.914l-7.13-7.605-13.914 7.604 15.303-16.248 7.304 7.605 13.74-7.604-15.304 16.248z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.line a::before,.contacts .channels>div>div.line span::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath fill='%2300B900' d='M39.12 0H8.705C3.93-.006.007 3.86 0 8.638v30.415c-.006 4.777 3.86 8.7 8.638 8.707h30.415c4.776.006 8.697-3.86 8.704-8.64V8.705C47.767 3.927 43.897.007 39.12 0zm-1.657 30.46c-3.647 4.2-11.806 9.314-13.662 10.097-1.854.782-1.58-.498-1.505-.938l.25-1.49c.057-.442.118-1.132-.057-1.57-.194-.485-.965-.736-1.532-.858C12.6 34.597 6.414 28.756 6.414 21.78c0-7.78 7.8-14.11 17.388-14.11C33.39 7.67 41.19 14 41.19 21.78c0 3.115-1.208 5.917-3.727 8.68z'/%3E%3Cpath fill='%2300B900' d='M35.398 18.02h-4.873c-.09 0-.174.037-.234.096 0 0 0 .003-.003.004l-.006.006c-.056.06-.093.143-.093.233v7.574c0 .092.037.174.095.234l.005.006c.002 0 .004.002.006.004.06.06.143.095.232.095h4.872c.19 0 .34-.152.34-.34v-1.218c0-.188-.15-.34-.34-.34h-3.31v-1.28h3.31c.19 0 .34-.152.34-.34v-1.22c0-.186-.15-.338-.34-.338h-3.31v-1.28h3.31c.19 0 .34-.15.34-.34v-1.22c0-.185-.15-.337-.34-.337zM17.33 24.375h-3.315v-6.017c0-.187-.15-.34-.338-.34h-1.22c-.187 0-.338.153-.338.34v7.575c0 .092.036.174.093.234 0 .002.003.004.005.006l.005.004c.06.06.143.095.234.095h4.873c.187 0 .338-.152.338-.34v-1.218c0-.187-.152-.34-.34-.34zM28.664 18.02h-1.22c-.188 0-.34.152-.34.338v4.5l-3.47-4.688-.027-.034-.002-.002c-.006-.008-.013-.015-.02-.02l-.007-.006c-.005-.006-.012-.01-.018-.016l-.008-.007-.018-.012-.01-.006-.018-.01c-.003 0-.006-.003-.01-.004l-.02-.01-.01-.003-.02-.006-.012-.003c-.007 0-.013-.002-.02-.003H23.4c-.006-.002-.013-.003-.02-.003h-.016l-.012-.002h-1.22c-.186 0-.338.152-.338.338v7.577c0 .187.152.338.34.338h1.218c.188 0 .34-.15.34-.338v-4.5l3.475 4.694c.025.036.055.063.087.085l.003.003.02.013.01.007.017.007.017.007.01.005.023.008c.002 0 .004 0 .006.002.026.006.056.01.085.01h1.22c.19 0 .34-.15.34-.337V18.36c-.003-.19-.153-.34-.34-.34zM20.27 18.02h-1.22c-.188 0-.34.152-.34.338v7.577c0 .187.153.338.34.338h1.22c.186 0 .338-.15.338-.338v-7.577c0-.187-.152-.338-.34-.338z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.line a[href='']::before,.contacts .channels>div>div.line span[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath fill='%23999' d='M39.12 0H8.705C3.93-.006.007 3.86 0 8.638v30.415c-.006 4.777 3.86 8.7 8.638 8.707h30.415c4.776.006 8.697-3.86 8.704-8.64V8.705C47.767 3.927 43.897.007 39.12 0zm-1.657 30.46c-3.647 4.2-11.806 9.314-13.662 10.097-1.854.782-1.58-.498-1.505-.938l.25-1.49c.057-.442.118-1.132-.057-1.57-.194-.485-.965-.736-1.532-.858C12.6 34.597 6.414 28.756 6.414 21.78c0-7.78 7.8-14.11 17.388-14.11C33.39 7.67 41.19 14 41.19 21.78c0 3.115-1.208 5.917-3.727 8.68z'/%3E%3Cpath fill='%23999' d='M35.398 18.02h-4.873c-.09 0-.174.037-.234.096 0 0 0 .003-.003.004l-.006.006c-.056.06-.093.143-.093.233v7.574c0 .092.037.174.095.234l.005.006c.002 0 .004.002.006.004.06.06.143.095.232.095h4.872c.19 0 .34-.152.34-.34v-1.218c0-.188-.15-.34-.34-.34h-3.31v-1.28h3.31c.19 0 .34-.152.34-.34v-1.22c0-.186-.15-.338-.34-.338h-3.31v-1.28h3.31c.19 0 .34-.15.34-.34v-1.22c0-.185-.15-.337-.34-.337zM17.33 24.375h-3.315v-6.017c0-.187-.15-.34-.338-.34h-1.22c-.187 0-.338.153-.338.34v7.575c0 .092.036.174.093.234 0 .002.003.004.005.006l.005.004c.06.06.143.095.234.095h4.873c.187 0 .338-.152.338-.34v-1.218c0-.187-.152-.34-.34-.34zM28.664 18.02h-1.22c-.188 0-.34.152-.34.338v4.5l-3.47-4.688-.027-.034-.002-.002c-.006-.008-.013-.015-.02-.02l-.007-.006c-.005-.006-.012-.01-.018-.016l-.008-.007-.018-.012-.01-.006-.018-.01c-.003 0-.006-.003-.01-.004l-.02-.01-.01-.003-.02-.006-.012-.003c-.007 0-.013-.002-.02-.003H23.4c-.006-.002-.013-.003-.02-.003h-.016l-.012-.002h-1.22c-.186 0-.338.152-.338.338v7.577c0 .187.152.338.34.338h1.218c.188 0 .34-.15.34-.338v-4.5l3.475 4.694c.025.036.055.063.087.085l.003.003.02.013.01.007.017.007.017.007.01.005.023.008c.002 0 .004 0 .006.002.026.006.056.01.085.01h1.22c.19 0 .34-.15.34-.337V18.36c-.003-.19-.153-.34-.34-.34zM20.27 18.02h-1.22c-.188 0-.34.152-.34.338v7.577c0 .187.153.338.34.338h1.22c.186 0 .338-.15.338-.338v-7.577c0-.187-.152-.338-.34-.338z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.viber a::before,.contacts .channels>div>div.viber span::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='58' height='60' viewBox='0 0 58 60'%3E%3Cpath fill='%237D3DAF' d='M42.707 2.472C33.635.74 24.5.74 15.49 2.46 9.858 3.686 3.793 9.524 2.445 14.965.766 22.63.766 30.336 2.43 37.936 3.733 43.21 9.347 48.78 14.71 50.313v6.073c0 2.198 2.678 3.278 4.2 1.692l6.152-6.396c1.334.074 2.67.115 4.004.115 4.536 0 9.073-.43 13.577-1.288 5.633-1.23 11.7-7.066 13.045-12.508 1.68-7.666 1.68-15.37.016-22.97-1.36-5.507-7.427-11.345-12.997-12.56zm13.97 35.706c-1.454 5.877-7.815 12-13.768 13.297-4.637.887-9.237 1.322-13.842 1.322-1.318 0-2.668-.04-4.06-.117l.776-.306-6.15 6.396c-2.148 2.236-5.923.715-5.923-2.384v-6.073l.726.96C8.706 49.638 2.844 43.776 1.468 38.22c-1.71-7.81-1.71-15.662-.015-23.404C2.913 8.913 9.273 2.79 15.23 1.49c9.206-1.757 18.468-1.757 27.616-.01C48.862 2.79 55.223 8.91 56.66 14.722c1.717 7.835 1.717 15.687.016 23.455z'/%3E%3Cpath fill='%237D3DAF' d='M50.838 16.134c-.898-3.55-5.502-7.963-9.164-8.778-8.365-1.592-16.848-1.592-25.214 0-3.66.815-8.263 5.23-9.164 8.778-1.497 6.868-1.497 13.83 0 20.7.9 3.55 5.504 7.962 9.164 8.777h.002c.164.033.282.175.282.34v10.062c0 .504.613.75.963.387l4.777-4.905 4.492-4.612c.067-.07.16-.106.255-.104 4.825.133 9.653-.257 14.444-1.168 3.66-.815 8.266-5.23 9.164-8.778 1.498-6.87 1.498-13.832 0-20.7zm-9.035 21.212c-.732 1.555-1.797 2.848-3.334 3.673-.435.232-.952.307-1.442.458-.562-.17-1.098-.286-1.596-.492-5.16-2.142-9.908-4.903-13.67-9.14-2.138-2.407-3.812-5.125-5.227-8.002-.67-1.365-1.237-2.782-1.813-4.19-.526-1.286.25-2.613 1.064-3.58.765-.91 1.75-1.605 2.815-2.117.833-.4 1.654-.17 2.262.536 1.313 1.525 2.52 3.128 3.498 4.896.6 1.086.436 2.416-.653 3.156-.265.18-.505.39-.752.594-.216.178-.42.358-.568.6-.27.44-.284.96-.11 1.44 1.344 3.69 3.607 6.562 7.32 8.108.597.248 1.192.535 1.878.455 1.146-.134 1.518-1.392 2.322-2.05.785-.642 1.79-.65 2.635-.114.846.534 1.666 1.11 2.482 1.69.8.57 1.597 1.13 2.336 1.78.707.626.95 1.446.553 2.296zm-6.662-12.03c-.353.005-.163-.003-.034-.006-.54-.005-.833-.31-.89-.815-.042-.36-.073-.727-.16-1.078-.17-.69-.536-1.333-1.118-1.757-.275-.2-.586-.346-.912-.44-.414-.12-.844-.087-1.258-.188-.448-.11-.697-.474-.626-.895.063-.383.437-.682.855-.652 2.616.19 4.486 1.542 4.753 4.623.02.218.04.447-.007.655-.08.345-.33.52-.577.546.034 0 .04 0-.025.005zm-1.627-7.047c-.803-.395-1.67-.64-2.55-.785-.386-.063-.774-.102-1.16-.156-.47-.066-.72-.365-.697-.826.02-.433.337-.744.808-.717 1.55.088 3.045.423 4.422 1.152 2.8 1.482 4.398 3.824 4.865 6.95.022.142.057.282.067.424.026.35.043.703.07 1.166-.012.084-.018.283-.066.47-.18.677-1.206.762-1.442.078-.07-.203-.08-.434-.08-.652-.003-1.43-.313-2.858-1.035-4.102-.74-1.28-1.872-2.355-3.2-3.005zm8.652 9.66c-.54.006-.784-.446-.82-.932-.07-.96-.117-1.925-.25-2.878-.698-5.03-4.707-9.19-9.71-10.083-.754-.134-1.524-.17-2.287-.25-.482-.05-1.114-.08-1.22-.68-.09-.502.333-.902.812-.928.13-.008.26-.002.392-.002 6.75.19-.13 0 0 0 6.75.19 12.292 4.67 13.48 11.343.202 1.138.274 2.3.364 3.455.037.488-.238.95-.76.955z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div.viber a[href='']::before,.contacts .channels>div>div.viber span[href='']::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='58' height='60' viewBox='0 0 58 60'%3E%3Cpath fill='%23999' d='M42.707 2.472C33.635.74 24.5.74 15.49 2.46 9.858 3.686 3.793 9.524 2.445 14.965.766 22.63.766 30.336 2.43 37.936 3.733 43.21 9.347 48.78 14.71 50.313v6.073c0 2.198 2.678 3.278 4.2 1.692l6.152-6.396c1.334.074 2.67.115 4.004.115 4.536 0 9.073-.43 13.577-1.288 5.633-1.23 11.7-7.066 13.045-12.508 1.68-7.666 1.68-15.37.016-22.97-1.36-5.507-7.427-11.345-12.997-12.56zm13.97 35.706c-1.454 5.877-7.815 12-13.768 13.297-4.637.887-9.237 1.322-13.842 1.322-1.318 0-2.668-.04-4.06-.117l.776-.306-6.15 6.396c-2.148 2.236-5.923.715-5.923-2.384v-6.073l.726.96C8.706 49.638 2.844 43.776 1.468 38.22c-1.71-7.81-1.71-15.662-.015-23.404C2.913 8.913 9.273 2.79 15.23 1.49c9.206-1.757 18.468-1.757 27.616-.01C48.862 2.79 55.223 8.91 56.66 14.722c1.717 7.835 1.717 15.687.016 23.455z'/%3E%3Cpath fill='%23999' d='M50.838 16.134c-.898-3.55-5.502-7.963-9.164-8.778-8.365-1.592-16.848-1.592-25.214 0-3.66.815-8.263 5.23-9.164 8.778-1.497 6.868-1.497 13.83 0 20.7.9 3.55 5.504 7.962 9.164 8.777h.002c.164.033.282.175.282.34v10.062c0 .504.613.75.963.387l4.777-4.905 4.492-4.612c.067-.07.16-.106.255-.104 4.825.133 9.653-.257 14.444-1.168 3.66-.815 8.266-5.23 9.164-8.778 1.498-6.87 1.498-13.832 0-20.7zm-9.035 21.212c-.732 1.555-1.797 2.848-3.334 3.673-.435.232-.952.307-1.442.458-.562-.17-1.098-.286-1.596-.492-5.16-2.142-9.908-4.903-13.67-9.14-2.138-2.407-3.812-5.125-5.227-8.002-.67-1.365-1.237-2.782-1.813-4.19-.526-1.286.25-2.613 1.064-3.58.765-.91 1.75-1.605 2.815-2.117.833-.4 1.654-.17 2.262.536 1.313 1.525 2.52 3.128 3.498 4.896.6 1.086.436 2.416-.653 3.156-.265.18-.505.39-.752.594-.216.178-.42.358-.568.6-.27.44-.284.96-.11 1.44 1.344 3.69 3.607 6.562 7.32 8.108.597.248 1.192.535 1.878.455 1.146-.134 1.518-1.392 2.322-2.05.785-.642 1.79-.65 2.635-.114.846.534 1.666 1.11 2.482 1.69.8.57 1.597 1.13 2.336 1.78.707.626.95 1.446.553 2.296zm-6.662-12.03c-.353.005-.163-.003-.034-.006-.54-.005-.833-.31-.89-.815-.042-.36-.073-.727-.16-1.078-.17-.69-.536-1.333-1.118-1.757-.275-.2-.586-.346-.912-.44-.414-.12-.844-.087-1.258-.188-.448-.11-.697-.474-.626-.895.063-.383.437-.682.855-.652 2.616.19 4.486 1.542 4.753 4.623.02.218.04.447-.007.655-.08.345-.33.52-.577.546.034 0 .04 0-.025.005zm-1.627-7.047c-.803-.395-1.67-.64-2.55-.785-.386-.063-.774-.102-1.16-.156-.47-.066-.72-.365-.697-.826.02-.433.337-.744.808-.717 1.55.088 3.045.423 4.422 1.152 2.8 1.482 4.398 3.824 4.865 6.95.022.142.057.282.067.424.026.35.043.703.07 1.166-.012.084-.018.283-.066.47-.18.677-1.206.762-1.442.078-.07-.203-.08-.434-.08-.652-.003-1.43-.313-2.858-1.035-4.102-.74-1.28-1.872-2.355-3.2-3.005zm8.652 9.66c-.54.006-.784-.446-.82-.932-.07-.96-.117-1.925-.25-2.878-.698-5.03-4.707-9.19-9.71-10.083-.754-.134-1.524-.17-2.287-.25-.482-.05-1.114-.08-1.22-.68-.09-.502.333-.902.812-.928.13-.008.26-.002.392-.002 6.75.19-.13 0 0 0 6.75.19 12.292 4.67 13.48 11.343.202 1.138.274 2.3.364 3.455.037.488-.238.95-.76.955z'/%3E%3C/svg%3E")
            }

            .contacts .channels>div>div .logo {
                display: inline-block;
                max-width: 100%
            }

            .contacts .channels>div>div .logo.message a,.contacts .channels>div>div .logo span.title {
                display: none
            }

            .contacts .channels>div>div .logo.message span.title {
                display: flex
            }

            .contacts .channels>div>div a,.contacts .channels>div>div span.title {
                display: flex;
                align-items: center;
                text-align: left;
                position: relative;
                font-weight: 600;
                margin: 0 18px;
                word-wrap: break-word;
                max-width: 100%;
                transition: opacity .1s ease-in-out 0s
            }

            .contacts .channels>div>div a[href=""],.contacts .channels>div>div span.title[href=""] {
                opacity: .3
            }

            .contacts .channels>div>div a:hover,.contacts .channels>div>div span.title:hover {
                opacity: .7
            }

            .contacts .channels>div>div a::before,.contacts .channels>div>div span.title::before {
                width: 24px;
                height: 24px;
                min-width: 24px;
                margin: 0 8px 0 0;
                content: "";
                display: block;
                background-size: contain;
                background-repeat: no-repeat;
                background-position: center center
            }

            .contacts .channels>div>div a>span,.contacts .channels>div>div span.title>span {
                display: block;
                max-width: 100%;
                max-height: 2.4em;
                line-height: 1.2em;
                overflow: hidden
            }

            .contacts .channels>div>div .logo.message a:hover,.contacts .channels>div>div .logo span.title:hover {
                opacity: 1
            }

            .store+.footer {
                margin-top: -32px
            }

            .footer {
                background-color: #efefef
            }

            .footer>div {
                box-sizing: border-box;
                max-width: 624px;
                font-size: 14px;
                line-height: 1.4em;
                text-align: center
            }

            @media (min-width: 1024px) {
                .footer>div {
                    max-width:768px
                }
            }

            .footer .copyright,.footer a {
                margin: 0;
                font-size: 14px;
                font-weight: 400;
                line-height: 1.4em
            }

            .footer .copyright {
                color: #757575
            }

            .footer .copyright__year {
                display: none
            }

            .footer .links {
                display: block;
                margin: 0 auto;
                padding: 0;
                list-style: none
            }

            .footer .links li {
                display: inline-block;
                padding: 0
            }

            .footer .links li:not(:first-child) {
                margin-left: 24px
            }

            .footer .logo {
                display: inline-block;
                margin: 24px auto 0
            }

            .footer .logo,.footer .logo:visited {
                color: #757575;
                transition: color .12s ease-out 0s
            }

            .footer .logo:hover {
                color: #115080
            }

            .footer .logo:active {
                color: #0a263b
            }

            .footer .logo:hover svg path[fill] {
                fill: #115080
            }

            .footer .logo svg {
                display: block;
                margin: 7px auto 8px
            }

            .footer .logo svg path[fill] {
                transition: fill .1s linear 0s
            }

            .footer .ec-likely,.footer .ec-likely__widget {
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
                padding: 0;
                text-indent: 0 !important;
                list-style: none !important;
                font-weight: 400;
                font-family: Helvetica Neue, Arial, sans-serif
            }

            .footer .ec-likely {
                display: inline-block
            }

            .footer .ec-likely__widget {
                margin: 0;
                font-size: inherit
            }

            .footer .ec-likely {
                opacity: 0;
                font-size: 0 !important
            }

            .footer .ec-likely_visible {
                opacity: 1;
                transition: opacity .1s ease-in
            }

            .footer .ec-likely>* {
                display: inline-block;
                visibility: hidden
            }

            .footer .ec-likely_visible>* {
                visibility: inherit
            }

            .footer .ec-likely__widget {
                position: relative;
                white-space: nowrap
            }

            .footer .ec-likely__button,.footer .ec-likely__widget {
                display: inline-block
            }

            .footer .ec-likely__button,.footer .ec-likely__counter {
                text-decoration: none;
                text-rendering: optimizeLegibility;
                margin: 0;
                outline: 0
            }

            .footer .ec-likely__button {
                position: relative;
                user-select: none
            }

            .footer .ec-likely__counter {
                display: none;
                position: relative;
                font-weight: 400
            }

            .footer .ec-likely_ready .ec-likely__counter {
                display: inline-block
            }

            .footer .ec-likely_ready .ec-likely__counter_empty {
                display: none
            }

            .footer .ec-likely__button,.footer .ec-likely__counter,.footer .ec-likely__icon,.footer .ec-likely__widget {
                vertical-align: top
            }

            .footer .ec-likely__widget {
                transition: background .33s ease-out, color .33s ease-out, fill .33s ease-out
            }

            @media (hover: hover) {
                .footer .ec-likely__widget:active,.footer .ec-likely__widget:focus,.footer .ec-likely__widget:hover {
                    transition:none;
                    cursor: pointer
                }
            }

            .footer .ec-likely__icon {
                position: relative;
                text-align: left;
                display: inline-block
            }

            .footer .ec-likely svg {
                position: absolute;
                left: 3px;
                top: 3px;
                width: 16px;
                height: 16px
            }

            .footer .ec-likely__button,.footer .ec-likely__counter {
                line-height: inherit;
                cursor: inherit
            }

            .footer .ec-likely__button:empty {
                display: none
            }

            .footer .ec-likely__counter {
                text-align: center
            }

            .footer .ec-likely .ec-likely__widget {
                color: #000;
                background: rgba(220,220,220,0.8)
            }

            .footer .ec-likely .ec-likely__counter {
                background-size: 1px 1px;
                background-repeat: repeat-y;
                background-image: linear-gradient(to right, rgba(0,0,0,0.2) 0, rgba(0,0,0,0) 0.5px, rgba(0,0,0,0) 100%)
            }

            .footer .ec-likely-light .ec-likely__widget {
                color: #fff;
                fill: #fff;
                background: rgba(236,236,236,0.16);
                text-shadow: rgba(0,0,0,0.2) 0 0 0.33em
            }

            .footer .ec-likely-light .ec-likely__counter {
                background-image: linear-gradient(to right, rgba(255,255,255,0.4) 0, rgba(255,255,255,0) 0.5px, rgba(255,255,255,0) 100%)
            }

            .footer .ec-likely__widget_facebook {
                fill: #425497
            }

            @media (hover: hover) {
                .footer .ec-likely__widget_facebook:hover {
                    background:rgba(207,212,229,0.8)
                }

                .footer .ec-likely-light .ec-likely__widget_facebook:hover,.footer .ec-likely-light .ec-likely__widget_facebook:active,.footer .ec-likely-light .ec-likely__widget_facebook:focus,.footer .ec-likely-light .ec-likely__widget_facebook:hover {
                    text-shadow: #425497 0 0 0.25em;
                    background: rgba(66,84,151,0.7)
                }
            }

            .footer .ec-likely__widget_linkedin {
                fill: #0077b5
            }

            @media (hover: hover) {
                .footer .ec-likely__widget_linkedin:active,.footer .ec-likely__widget_linkedin:focus,.footer .ec-likely__widget_linkedin:hover {
                    background:rgba(191,221,236,0.8)
                }

                .footer .ec-likely-light .ec-likely__widget_linkedin:active,.footer .ec-likely-light .ec-likely__widget_linkedin:focus,.footer .ec-likely-light .ec-likely__widget_linkedin:hover {
                    text-shadow: #0077b5 0 0 0.25em;
                    background: rgba(0,119,181,0.7)
                }
            }

            .footer .ec-likely__widget_odnoklassniki {
                fill: #f6903b
            }

            @media (hover: hover) {
                .footer .ec-likely__widget_odnoklassniki:active,.footer .ec-likely__widget_odnoklassniki:focus,.footer .ec-likely__widget_odnoklassniki:hover {
                    background:rgba(252,227,206,0.8)
                }

                .footer .ec-likely-light .ec-likely__widget_odnoklassniki:active,.footer .ec-likely-light .ec-likely__widget_odnoklassniki:focus,.footer .ec-likely-light .ec-likely__widget_odnoklassniki:hover {
                    text-shadow: #f6903b 0 0 0.25em;
                    background: rgba(246,144,59,0.7)
                }
            }

            .footer .ec-likely__widget_pinterest {
                fill: #bd081c
            }

            @media (hover: hover) {
                .footer .ec-likely__widget_pinterest:hover {
                    background:rgba(238,193,198,0.8)
                }

                .footer .ec-likely-light .ec-likely__widget_pinterest:active,.footer .ec-likely-light .ec-likely__widget_pinterest:focus,.footer .ec-likely-light .ec-likely__widget_pinterest:hover {
                    text-shadow: #bd081c 0 0 0.25em;
                    background: rgba(189,8,28,0.7)
                }
            }

            .footer .ec-likely__widget_telegram {
                fill: #34abde
            }

            @media (hover: hover) {
                .footer .ec-likely__widget_telegram:active,.footer .ec-likely__widget_telegram:focus,.footer .ec-likely__widget_telegram:hover {
                    background:rgba(204,234,246,0.8)
                }

                .footer .ec-likely-light .ec-likely__widget_telegram:active,.footer .ec-likely-light .ec-likely__widget_telegram:focus,.footer .ec-likely-light .ec-likely__widget_telegram:hover {
                    text-shadow: #34abde 0 0 0.25em;
                    background: rgba(52,171,222,0.7)
                }
            }

            .footer .ec-likely__widget_twitter {
                fill: #00b7ec
            }

            @media (hover: hover) {
                .footer .ec-likely__widget_twitter:hover {
                    background:rgba(191,237,250,0.8)
                }

                .footer .ec-likely-light .ec-likely__widget_twitter:active,.footer .ec-likely-light .ec-likely__widget_twitter:focus,.footer .ec-likely-light .ec-likely__widget_twitter:hover {
                    text-shadow: #00b7ec 0 0 0.25em;
                    background: rgba(0,183,236,0.7)
                }
            }

            .footer .ec-likely__widget_vkontakte {
                fill: #526e8f
            }

            @media (hover: hover) {
                .footer .ec-likely__widget_vkontakte:hover {
                    background:rgba(211,218,227,0.8)
                }

                .footer .ec-likely-light .ec-likely__widget_vkontakte:active,.footer .ec-likely-light .ec-likely__widget_vkontakte:focus,.footer .ec-likely-light .ec-likely__widget_vkontakte:hover {
                    text-shadow: #526e8f 0 0 0.25em;
                    background: rgba(82,110,143,0.7)
                }
            }

            .footer .ec-likely__widget_whatsapp {
                fill: #25d366
            }

            @media (hover: hover) {
                .footer .ec-likely__widget_whatsapp:active,.footer .ec-likely__widget_whatsapp:focus,.footer .ec-likely__widget_whatsapp:hover {
                    background:rgba(200,244,216,0.8)
                }

                .footer .ec-likely-light .ec-likely__widget_whatsapp:active,.footer .ec-likely-light .ec-likely__widget_whatsapp:focus,.footer .ec-likely-light .ec-likely__widget_whatsapp:hover {
                    text-shadow: #25d366 0 0 0.25em;
                    background: rgba(37,211,102,0.7)
                }
            }

            .footer .ec-likely {
                margin: 0 -5px 12px
            }

            .footer .ec-likely .ec-likely__widget {
                line-height: 20px;
                font-size: 14px;
                border-radius: 3px;
                height: 22px;
                margin: 0 12px 10px
            }

            .footer .ec-likely .ec-likely__icon {
                width: 18px;
                height: 22px
            }

            .footer .ec-likely .ec-likely__button {
                padding: 1px 4px 1px 0
            }

            .footer .ec-likely .ec-likely__counter {
                padding: 1px 4px
            }

            .footer .ec-likely-big {
                margin: 0 -6px -12px
            }

            .footer .ec-likely-big .ec-likely__widget {
                line-height: 28px;
                font-size: 18px;
                border-radius: 4px;
                height: 32px;
                margin: 0 6px 12px
            }

            .footer .ec-likely-big .ec-likely__icon {
                width: 32px;
                height: 32px
            }

            .footer .ec-likely-big .ec-likely__button {
                padding: 2px 6px 2px 0
            }

            .footer .ec-likely-big .ec-likely__counter {
                padding: 2px 6px
            }

            .footer .ec-likely-big svg {
                left: 4px;
                top: 4px;
                width: 24px;
                height: 24px
            }

            .footer .ec-likely-small {
                margin: 0 -4px -8px
            }

            .footer .ec-likely-small .ec-likely__widget {
                line-height: 14px;
                font-size: 12px;
                border-radius: 2px;
                height: 18px;
                margin: 0 4px 8px
            }

            .footer .ec-likely-small .ec-likely__icon {
                width: 18px;
                height: 18px
            }

            .footer .ec-likely-small .ec-likely__button {
                padding: 2px 3px 2px 0
            }

            .footer .ec-likely-small .ec-likely__counter {
                padding: 2px 3px
            }

            .footer .ec-likely-small svg {
                left: 3px;
                top: 3px;
                width: 12px;
                height: 12px
            }

            .footer .ec-likely .ec-likely__widget svg {
                fill: #333
            }

            .footer-new .copyright {
                margin-top: 14px
            }

            .footer-new .copyright__text,.footer-new .copyright__cover {
                padding-right: 8px
            }

            .footer-new .copyright__text::after,.footer-new .copyright__cover::after {
                content: "\00b7";
                padding-left: 8px;
                font-size: initial;
                font-weight: 600
            }

            .footer-new .logo {
                margin-top: 26px
            }

            .footer-new .legal-links {
                display: block;
                margin: 0 auto;
                padding: 0;
                list-style: none
            }

            .footer-new .legal-links li {
                display: inline-block;
                padding: 0
            }

            .footer-new .legal-links li:not(:first-child) {
                margin-left: 18px
            }

            .footer-new .likely,.footer-new .ec-likely {
                margin: 0 -5px 16px
            }

            html#ecwid_html body#ecwid_body div.ecwid-productBrowser,html#ecwid_html body#ecwid_body .ecwid-lte-600px div.ecwid-productBrowser {
                padding-left: 0 !important;
                padding-right: 0 !important
            }

            html#ecwid_html body#ecwid_body div.ecwid-pager-hasTopSeparator {
                border-top: 0 !important
            }

            html#ecwid_html body#ecwid_body div.ecwid-productBrowser-termsPage div.ecwid-Terms-content {
                max-width: none
            }

            html#ecwid_html body#ecwid_body div.ecwid-productBrowser-productDragLabel {
                display: none
            }

            .disable-ecwid-loader .ecwid-loadingIndicator-over,.disable-ecwid-loader .ecwid-loadingIndicator-over+.ecwid-loadingIndicator,.disable-ecwid-loader .ecwid-loadingIndicator-cursor {
                display: none !important
            }
        </style>
        <script>
            showStore = true;
        </script>
        <style>
            @keyframes button-primary-focus {
                50% {
                    background-color: #595959
                }
            }

            @keyframes button-secondary-focus {
                50% {
                    background-color: #f2f2f2
                }
            }

            @keyframes preloader-rotate {
                0% {
                    transform: rotate(0deg)
                }

                100% {
                    transform: rotate(360deg)
                }
            }

            @keyframes bounce-x {
                0% {
                    transform: translate3d(0, 0, 0)
                }

                10% {
                    transform: translate3d(-6px, 0, 0)
                }

                20% {
                    transform: translate3d(12px, 0, 0)
                }

                29% {
                    transform: translate3d(-12px, 0, 0)
                }

                38% {
                    transform: translate3d(11px, 0, 0)
                }

                47% {
                    transform: translate3d(-9px, 0, 0)
                }

                56% {
                    transform: translate3d(7px, 0, 0)
                }

                65% {
                    transform: translate3d(-5px, 0, 0)
                }

                74% {
                    transform: translate3d(3px, 0, 0)
                }

                83% {
                    transform: translate3d(-1px, 0, 0)
                }

                92% {
                    transform: translate3d(1px, 0, 0)
                }

                100% {
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes bounce-top {
                0% {
                    transform: translate3d(0, 0, 0)
                }

                12% {
                    transform: translate3d(0, -5px, 0)
                }

                25% {
                    transform: translate3d(0, -7px, 0)
                }

                37% {
                    transform: translate3d(0, -5px, 0)
                }

                50% {
                    transform: translate3d(0, 0, 0)
                }

                62% {
                    transform: translate3d(0, -3px, 0)
                }

                75% {
                    transform: translate3d(0, -4px, 0)
                }

                87% {
                    transform: translate3d(0, -3px, 0)
                }

                100% {
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes heartbit-1x {
                0% {
                    transform: scale(1)
                }

                50% {
                    transform: scale(1.2)
                }

                100% {
                    transform: scale(1)
                }
            }

            @keyframes form-control-svg {
                0%,100% {
                    opacity: 0
                }

                6%,94% {
                    opacity: 1
                }
            }

            @keyframes form-control-text {
                0%,100% {
                    opacity: 1
                }

                6%,94% {
                    opacity: 0
                }
            }

            @keyframes form-control-check {
                from {
                    opacity: 1;
                    stroke-dasharray: 50;
                    stroke-dashoffset: 50
                }

                to {
                    opacity: 1;
                    stroke-dasharray: 50;
                    stroke-dashoffset: 0
                }
            }

            @keyframes marker-required {
                0% {
                    opacity: 1;
                    transform: scale(0)
                }

                100% {
                    opacity: 0;
                    transform: scale(2)
                }
            }

            @keyframes progress-bar-stripes {
                from {
                    background-position: 40px 0
                }

                to {
                    background-position: 0 0
                }
            }

            @keyframes move-bg {
                0% {
                    background-position: 200% 0
                }

                100% {
                    background-position: 0 0
                }
            }

            @keyframes showFromTop {
                0% {
                    opacity: 0;
                    transform: translate3d(0, -10px, 0)
                }

                100% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes showFromBottom {
                0% {
                    opacity: 0;
                    transform: translate3d(0, 20px, 0)
                }

                100% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }
            }

            @keyframes hideToTop {
                0% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }

                100% {
                    opacity: 0;
                    transform: translate3d(0, -20px, 0)
                }
            }

            @keyframes hideToBottom {
                0% {
                    opacity: 1;
                    transform: translate3d(0, 0, 0)
                }

                100% {
                    opacity: 0;
                    transform: translate3d(0, 20px, 0)
                }
            }

            @keyframes fade-in {
                from {
                    opacity: 0
                }

                to {
                    opacity: 1
                }
            }

            @keyframes fade-out {
                from {
                    opacity: 1
                }

                to {
                    opacity: 0
                }
            }

            @keyframes popup-show-wrap {
                from {
                    transform: translateX(60px)
                }

                to {
                    transform: translateX(0)
                }
            }

            @keyframes popup-hide-wrap {
                from {
                    transform: translateX(0)
                }

                to {
                    transform: translateX(60px)
                }
            }

            @keyframes popup-show-wrap-from-left {
                from {
                    transform: translateX(-60px)
                }

                to {
                    transform: translateX(0)
                }
            }

            :root {
                --color-cover-title: $color-white;
                --color-cover-text: $color-white;
                --color-cover-button-text: $color-white;
                --color-cover-button-background: $base-color-button-v2;
                --color-menu: $color-white;
                --fontfamily-cover-title: $font-family;
                --fontfamily-cover-text: $font-family
            }

            body.touchable .hero .background>div {
                background-attachment: scroll
            }

            body.sw-activated .hero .background {
                background-image: none !important
            }

            body.sw-activated .hero .background div {
                transition: none
            }

            body.sw-activated .hero .background div.mobileThumbnail,body.sw-activated .hero .background div.desktopThumbnail {
                display: none
            }

            .hero {
                width: 100%;
                height: 100vh;
                box-sizing: border-box;
                background-color: #fff;
                word-wrap: break-word
            }

            .hero>div {
                height: 100%;
                position: relative;
                transition: opacity .6s ease-out 0s
            }

            .hero .background {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100vh;
                overflow: hidden;
                z-index: 0;
                background-size: cover
            }

            .hero .background.transparent::before {
                content: '';
                display: block;
                position: absolute;
                background-color: #efefef;
                top: 50%;
                bottom: 0;
                left: 0;
                right: 0;
                z-index: 1
            }

            .hero .background::after {
                position: absolute;
                width: 100%;
                height: 100%;
                top: 0;
                left: 0;
                content: '';
                display: block;
                background-color: rgba(0,0,0,0.3);
                transition: background-color .2s ease-in-out 0s
            }

            .hero .background div {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: transparent;
                background-size: cover;
                background-position: center center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                transition: opacity .3s ease-in-out .2s;
                opacity: 0
            }

            @media (max-width: 479px) {
                .hero .background div.desktopPicture,.hero .background div.desktopThumbnail {
                    display:none
                }
            }

            @media (min-width: 480px) {
                .hero .background div.mobilePicture,.hero .background div.mobileThumbnail {
                    display:none
                }
            }

            .hero .background div.mobileThumbnail,.hero .background div.desktopThumbnail {
                filter: blur(20px);
                opacity: 1
            }

            .hero .background canvas {
                position: absolute;
                display: none
            }

            .hero .background .video {
                opacity: 0;
                position: absolute;
                width: 100%;
                height: 100%;
                transition: opacity .5s ease 0s
            }

            @media (min-aspect-ratio: 16/9) {
                .hero .background .video {
                    height:300%;
                    top: -100%
                }
            }

            @media (max-aspect-ratio: 16/9) {
                .hero .background .video {
                    width:300%;
                    left: -100%
                }
            }

            .hero .layout {
                position: relative;
                display: table;
                flex-direction: column;
                width: 100%;
                height: 100%;
                box-sizing: border-box;
                padding-right: env(safe-area-inset-right);
                padding-left: env(safe-area-inset-left)
            }

            .hero .layout .top {
                display: table-row;
                height: 0
            }

            .hero .layout .top>div {
                display: table-cell;
                padding: 16px 12px 10px 16px;
                text-align: right
            }

            @media (min-width: 480px) {
                .hero .layout .top>div {
                    padding:16px 6px 0 16px
                }
            }

            @media (min-width: 600px) {
                .hero .layout .top>div {
                    padding:24px 26px 0 24px
                }
            }

            .hero .layout .top>div>div {
                display: inline-block
            }

            .hero .layout .top a {
                font-size: 12px;
                line-height: 1.5em;
                color: #fff;
                margin: 0 7px 0 15px
            }

            @media (min-width: 480px) {
                .hero .layout .top a {
                    margin:0 10px
                }
            }

            @media (min-width: 600px) {
                .hero .layout .top a {
                    font-size:14px
                }
            }

            @media (min-width: 768px) {
                .hero .layout .top a {
                    font-size:16px
                }
            }

            .hero .layout .top a span {
                display: inline-block;
                vertical-align: middle
            }

            .hero .layout .top a span.icon {
                margin: 0 2px;
                position: relative;
                top: 1px
            }

            .hero .layout .top a span.icon svg {
                display: block;
                transform: scale(1.3)
            }

            @media (min-width: 480px) {
                .hero .layout .top a span.icon svg {
                    display:inline;
                    transform: none
                }
            }

            .hero .layout .top a span.text {
                display: none
            }

            @media (min-width: 480px) {
                .hero .layout .top a span.text {
                    display:inline
                }
            }

            .hero .layout .center {
                display: table-row
            }

            .hero .layout .center>div {
                height: 100%;
                display: table-cell;
                padding: 8px 16px 24px;
                vertical-align: middle;
                text-align: center
            }

            .hero .layout .bottom {
                display: table-row;
                height: 0
            }

            .hero .layout .bottom>div {
                display: table-cell;
                text-align: center
            }

            .hero .layout .bottom .forward {
                cursor: pointer;
                margin: 0 auto .6em;
                display: inline-block;
                padding: 0 24px
            }

            @media (min-width: 600px) {
                .hero .layout .bottom .forward {
                    margin:0 auto 1.5em
                }
            }

            .hero .layout .bottom .forward:hover .arrow {
                opacity: .8
            }

            .hero .layout .bottom .forward p {
                display: none
            }

            @media (min-width: 600px) {
                .hero .layout .bottom .forward p {
                    color:#fff;
                    font-size: 1.5em;
                    line-height: 1.3em;
                    font-weight: 400;
                    margin: .75em auto;
                    display: block;
                    text-shadow: 0 1px 1px rgba(0,0,0,0.25);
                    -webkit-font-smoothing: antialiased
                }
            }

            .hero .layout .bottom .forward .arrow {
                width: 3.5em;
                height: 1.875em;
                margin: 0 auto;
                opacity: .6;
                background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='30' viewBox='0 0 56 30'%3E%3Cg fill-rule='evenodd' fill='%23fff' transform='rotate(45 46.435 20.157)'%3E%3Crect rx='5' height='2' width='40' y='38'/%3E%3Crect rx='5' height='2' width='40' y='19' x='19' transform='rotate(-90 39 20)'/%3E%3C/g%3E%3C/svg%3E") center center no-repeat;
                background-size: contain;
                transition: opacity .1s ease-in-out 0s
            }

            .hero h1 {
                font-weight: 600;
                font-size: 1.85em;
                line-height: 1em;
                color: #fff;
                margin: 0 auto .2em;
                padding: .2em 16px;
                max-width: 1024px;
                box-sizing: border-box;
                text-shadow: 0 1px 1px rgba(0,0,0,0.25);
                -webkit-font-smoothing: antialiased
            }

            @media (min-width: 480px) {
                .hero h1 {
                    font-size:2.5em
                }
            }

            @media (min-width: 1024px) {
                .hero h1 {
                    font-size:3.75em
                }
            }

            .hero h2 {
                font-weight: 400;
                font-size: 1em;
                line-height: 1.4em;
                color: #fff;
                margin: 0 auto;
                max-width: 840px;
                padding: .5em 16px;
                box-sizing: border-box;
                text-shadow: 0 1px 1px rgba(0,0,0,0.25);
                -webkit-font-smoothing: antialiased
            }

            @media (min-width: 480px) {
                .hero h2 {
                    font-size:1.125em
                }
            }

            @media (min-width: 1024px) {
                .hero h2 {
                    font-size:1.375em
                }
            }

            .hero a {
                color: #8fcfff;
                font-weight: 600
            }

            .hero a:hover,.hero a:visited:hover {
                color: get-text-hover-color(#8fcfff)
            }

            .hero sup,.hero mark,.hero .nobr {
                font-size: inherit;
                line-height: inherit;
                vertical-align: baseline;
                white-space: nowrap;
                background-color: inherit;
                color: inherit
            }

            .hero.loading .background::after {
                background-color: rgba(0,0,0,0.7)
            }

            body:not(.loading) .hero .background .mobilePicture,body:not(.loading) .hero .background .desktopPicture,body:not(.loading) .hero .background .video {
                opacity: 1
            }

            html#ecwid_html body#ecwid_body .hero .ec-size {
                margin: 1.5em auto .5em
            }

            html#ecwid_html body#ecwid_body .hero .ec-size .ec-store {
                text-align: center
            }

            html#ecwid_html body#ecwid_body .hero .ec-size .ec-store .form-control--primary {
                transition: opacity .1s linear 0s;
                min-height: 40px
            }

            html#ecwid_html body#ecwid_body .hero .ec-size .ec-store .form-control--primary.opacity {
                opacity: .5
            }

            html#ecwid_html body#ecwid_body .hero .ec-size .ec-store .form-control--primary .form-control__button {
                background-color: rgba(0,0,0,0.7);
                color: #fff
            }

            html#ecwid_html body#ecwid_body .hero .ec-size .ec-store .form-control--primary .form-control__button:focus {
                animation: button-primary-focus .5s linear 0s
            }

            html#ecwid_html body#ecwid_body .hero .ec-size .ec-store .form-control--primary .form-control__button:hover {
                background-color: rgba(38,38,38,0.7)
            }

            @media (min-width: 768px) {
                html#ecwid_html body#ecwid_body .hero .ec-size .ec-store .form-control--primary .form-control__button {
                    font-size:16px
                }
            }

            .cover {
                position: relative;
                color: #fff;
                font-size: 18px;
                line-height: 30px;
                transition: opacity .1s ease-out 0s
            }

            .cover * {
                box-sizing: border-box
            }

            .cover .cover-title {
                color: #fff;
                font-weight: 700;
                line-height: 1.05em
            }

            .cover .cover-text {
                font-weight: 400;
                line-height: 1.3em
            }

            .cover .cover-text p {
                margin: 0;
                padding: 0
            }

            .cover .cover-text p+p {
                padding-top: 0.4em
            }

            .cover .cover-text p>br {
                display: none
            }

            .cover .cover-title,.cover .cover-text {
                margin: 0;
                padding: 0;
                -webkit-font-smoothing: antialiased;
                word-wrap: break-word;
                -webkit-hyphens: auto;
                -ms-hyphens: auto;
                hyphens: auto;
                overflow-wrap: break-word;
                opacity: 1;
                transition: opacity .1s ease-in-out 0s
            }

            .cover .social-media {
                display: flex;
                align-items: center;
                margin: 0;
                padding: 0;
                list-style: none
            }

            .cover .social-media__item {
                display: inline-block
            }

            .cover .social-media__item a {
                display: flex;
                align-items: center;
                text-align: left;
                position: relative;
                font-weight: 600;
                margin: 0;
                padding: 10px;
                color: currentColor;
                max-width: 100%;
                transition: opacity .1s ease-in-out 0s
            }

            .cover .social-media__item a:hover {
                opacity: .7
            }

            .cover .social-media__item a svg {
                display: inline-block;
                width: 100%;
                height: 100%;
                fill: currentColor
            }

            .cover .social-media__item[data-name="Facebook"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath fill='%23fff' fill-rule='evenodd' d='M48 45c0 1.656-1.344 3-3 3H3c-1.656 0-3-1.344-3-3V3c0-1.656 1.344-3 3-3h42c1.656 0 3 1.344 3 3v42zm-15 3V30h6l1.5-7.5H33v-3c0-3 1.503-4.5 4.5-4.5h3V7.5h-6c-5.512 0-9 4.322-9 10.5v4.5h-6V30h6v18H33z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Twitter"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='40' viewBox='0 0 50 40'%3E%3Cpath fill='%23fff' fill-rule='evenodd' d='M43.556 6.483c2.06-1.235 3.643-3.19 4.39-5.52-1.93 1.143-4.065 1.976-6.338 2.42-1.822-1.937-4.415-3.15-7.288-3.15-5.51 0-9.977 4.468-9.977 9.98 0 .78.087 1.545.257 2.274C16.306 12.07 8.953 8.097 4.03 2.06c-.858 1.475-1.35 3.188-1.35 5.018 0 3.463 1.762 6.516 4.438 8.307-1.635-.053-3.174-.5-4.52-1.248v.125c0 4.836 3.44 8.87 8.005 9.787-.837.226-1.72.35-2.63.35-.644 0-1.267-.064-1.876-.18 1.268 3.963 4.956 6.85 9.32 6.93-3.413 2.677-7.715 4.275-12.39 4.275-.807 0-1.602-.047-2.382-.14 4.415 2.828 9.66 4.48 15.297 4.48 18.356 0 28.395-15.205 28.395-28.394 0-.43-.012-.862-.03-1.29 1.95-1.407 3.64-3.164 4.98-5.168-1.79.796-3.71 1.332-5.73 1.57z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Pinterest"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='41' height='48' viewBox='0 0 41 48'%3E%3Cpath fill='%23fff' fill-rule='evenodd' d='M8.59 46.524c-.083-2.06-.015-4.528.512-6.76.567-2.397 3.79-16.055 3.79-16.055s-.943-1.88-.943-4.657c0-4.362 2.532-7.623 5.682-7.623 2.677 0 3.972 2.01 3.972 4.42 0 2.69-1.72 6.72-2.6 10.45-.738 3.123 1.57 5.67 4.644 5.67 5.58 0 9.338-7.163 9.338-15.657 0-6.453-4.347-11.283-12.253-11.283-8.934 0-14.498 6.66-14.498 14.102 0 2.567.757 4.377 1.94 5.778.548.644.623.9.423 1.64-.137.545-.46 1.847-.597 2.363-.196.75-.798 1.014-1.474.736C2.41 27.972.496 23.465.496 18.4.496 10.034 7.55 0 21.546 0c11.243 0 18.65 8.138 18.65 16.873 0 11.553-6.43 20.185-15.897 20.185-3.182 0-6.174-1.72-7.194-3.668 0 0-1.713 6.787-2.072 8.094-.626 2.267-1.848 4.54-2.964 6.31-1.31.62-3.472-.264-3.48-1.27z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Instagram"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath d='M592 3920c6.518 0 7.335.028 9.895.144 2.555.117 4.3.523 5.826 1.116 1.58.613 2.918 1.434 4.252 2.768 1.334 1.334 2.155 2.673 2.768 4.25.593 1.528 1 3.272 1.116 5.827.116 2.56.144 3.377.144 9.895s-.028 7.335-.144 9.895c-.117 2.555-.523 4.3-1.116 5.826-.613 1.58-1.434 2.918-2.768 4.252-1.334 1.334-2.673 2.155-4.25 2.768-1.528.593-3.272 1-5.827 1.116-2.56.116-3.377.144-9.895.144s-7.335-.028-9.895-.144c-2.555-.117-4.3-.523-5.826-1.116-1.58-.613-2.918-1.434-4.252-2.768-1.334-1.334-2.155-2.673-2.768-4.25-.593-1.528-1-3.272-1.116-5.827-.116-2.56-.144-3.377-.144-9.895s.028-7.335.144-9.895c.117-2.555.523-4.3 1.116-5.826.613-1.58 1.434-2.918 2.768-4.252 1.334-1.334 2.673-2.155 4.25-2.768 1.528-.593 3.272-1 5.827-1.116 2.56-.116 3.377-.144 9.895-.144zm0 4c-6.514 0-7.285.025-9.858.142-2.378.11-3.67.506-4.53.84-1.14.443-1.95.97-2.805 1.825-.854.854-1.382 1.666-1.825 2.805-.334.86-.73 2.152-.84 4.53-.117 2.573-.142 3.344-.142 9.858 0 6.514.025 7.285.142 9.858.11 2.378.506 3.67.84 4.53.443 1.14.972 1.95 1.825 2.805.854.854 1.666 1.382 2.805 1.825.86.334 2.152.73 4.53.84 2.572.117 3.344.142 9.858.142 6.514 0 7.286-.025 9.858-.142 2.378-.11 3.67-.506 4.53-.84 1.14-.443 1.95-.97 2.805-1.825.854-.854 1.382-1.666 1.825-2.805.334-.86.73-2.152.84-4.53.117-2.573.142-3.344.142-9.858 0-6.514-.025-7.285-.142-9.858-.11-2.378-.506-3.67-.84-4.53-.443-1.14-.97-1.95-1.825-2.805-.854-.854-1.666-1.382-2.805-1.825-.86-.334-2.152-.73-4.53-.84-2.573-.117-3.344-.142-9.858-.142zm0 8c6.627 0 12 5.373 12 12s-5.373 12-12 12-12-5.373-12-12 5.373-12 12-12zm0 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm16-21c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z' transform='translate(-568 -3920)' fill='%23fff' fill-rule='evenodd'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Foursquare"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='36' height='50' viewBox='0 0 36 50'%3E%3Cpath fill='%23fff' fill-rule='evenodd' d='M3.226.89c-.76-.003-1.496.3-2.034.838-.538.536-.842 1.27-.843 2.03L.28 46.185c-.005 1.185.742 2.267 1.85 2.69 1.106.42 2.386.11 3.172-.777L17.88 33.93h8.968c.653 0 1.29-.224 1.8-.633.51-.408.865-.978 1.007-1.616l6.042-27.197c.188-.845-.017-1.74-.558-2.416-.542-.677-1.367-1.077-2.234-1.08L3.23.888h-.004zm3.35 5.147h.003l22.068.07c.298 0 .592.143.778.376.185.233.26.55.194.842l-1.376 6.17c-.1.438-.526.78-.976.78h-10.28c-.458-.005-1.11-.015-1.307.597-.183.572-.758 2.918-.758 3.38 0 .462.188.91.515 1.234.326.32.774.504 1.23.5H25.567c.3 0 .594.14.78.374.187.233.26.552.196.843l-1.458 6.536c-.097.44-.525.784-.976.784h-7.56c-.49-.002-.964.213-1.292.58-.018.02-.036.038-.055.056L5.555 40.198c.006-.02 0-33.162 0-33.162 0-.523.498-1 1.02-1z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Yelp!"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='39' height='52' viewBox='0 0 39 52'%3E%3Cpath fill='%23fff' fill-rule='evenodd' d='M35.508 27.327L25.312 29.97c-2.507.423-3.424-1.573-2.946-2.644.033-.074.054-.155.1-.22.714-.99 4.075-5.638 7.325-10.125 3.252-4.492 7.428 3.973 8.497 6.607 1.074 2.628-.575 3.17-.575 3.17l-2.2.57h-.004zM14.55 35.454l-8.477 10.26s-1.06 1.465 1.444 3.025c2.506 1.56 11.172 6.155 11.172.39V36.138c0-1.266-2.17-2.682-4.14-.684zm-10.93.587c5.184-1.634 10.54-3.326 11.68-3.688 1.142-.36 1.805-2.686-.55-3.87l-2.91-1.156H.53c-.72 3.502-1.422 10.143 3.09 8.715zM.83 26.01c-.09.346-.196.798-.302 1.316H11.84L3.15 23.87s-1.614-.526-2.32 2.14zm36.066 10.95c-4.92-1.62-10.01-3.295-11.1-3.648-1.08-.36-2.9 1.086-1.744 3.335l6.384 10.097s.955 1.314 2.994-.38c2.036-1.693 8.39-7.785 3.466-9.405zM17.03 25.415s2.764 2.194 3.855-1.116c.794-2.407-1.143-22.06-1.143-22.06s.14-3.91-9.42-.42C2.898 4.194 4.897 7.268 4.897 7.268L17.03 25.416z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="VKontakte"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='320' height='180.268' viewBox='90 159.732 320 180.268'%3E%3Cpath fill='%23fff' d='M261.278 159.733c-17.03.08-27.892.1-43.2.1-12.807 0-19.998 5.184-20.227 8.275-.207 2.827 6.328 5.112 10.3 7.4 3.838 2.378 7.303 9.926 7.303 15.025v44.476c0 4.225-.96 7.17-4.375 9.923-1.627 1.312-3.56 1.66-5.65 1.65-1.69-.01-3.992-.325-5.575-2.375-16.867-21.834-16.923-24.53-40.55-68.528-1.147-2.134-2.28-4.398-4.627-6.1s-5.824-2.825-11.4-2.825c-18.99 0-30.713.275-43.2.275-11.82 0-10.684 7.25-9.1 10.55 14.17 29.55 28.56 57.764 45.1 86.402 19.37 33.538 37.08 53.683 66.877 68.152 6.917 3.358 19.388 6.825 33.8 6.825h30.627c3.935 0 10.475-3.104 10.475-7.275V308.71c0-6.57 6.55-8.96 10.125-10.575 4.21-1.903 8.626 1.097 10.85 3.476 17.122 18.305 15.176 16.314 30.776 32.7 3.525 3.706 6.188 5.65 12.85 5.65 44.995 0 45.032.088 55.777 0 2.95-.02 7.332-4.45 8.3-6.173 1.278-2.277 4.184-10.408-.475-15.676-15.812-17.88-31.93-34.25-47.376-50.5-1.178-1.24-2.068-2.917-2.1-4.626-.036-1.87 1.007-3.684 2.1-5.2 17.324-24.046 31.636-44.408 47.2-69.7 5.06-8.223 4.406-14.046 3.476-16.05-1.077-2.324-4.394-5.53-8.2-5.55-20.786-.118-29.777-.41-51.95-.376-6.624.01-12.49-.5-16.126 7.475-9.746 21.368-25.646 53.973-39.45 67.527-2.55 2.5-5.955 4.36-8.926 4.374-2.972.015-6.132-2.01-6.575-6.85-.34-23.255-.056-43.095-.174-65.876-.036-6.964-2.972-8.755-5.2-10.3-3.024-2.096-7.8-2.743-11.477-2.725z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Tumblr"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='27' height='46' viewBox='0 0 27 46'%3E%3Cpath fill='%23fff' fill-rule='nonzero' d='M26.8 43.156c-1.538 1.662-5.102 2.79-8.293 2.844h-.35C7.437 46 5.11 38.022 5.11 33.364V20.426H.884c-.234 0-.46-.094-.626-.262-.167-.17-.26-.397-.26-.634v-6.11c0-.645.402-1.22 1.002-1.434 5.503-1.963 7.23-6.824 7.485-10.52C8.557.48 9.067 0 9.913 0h6.294c.49 0 .886.4.886.896v10.348h7.368c.49 0 .886.4.888.894v7.343c0 .238-.094.466-.26.634-.166.168-.392.263-.627.262h-7.4v11.966c0 3.004 1.955 3.834 3.163 3.834 1.16-.028 2.3-.386 2.872-.62.424-.17.797-.285 1.13-.2.312.078.516.3.654.707l1.952 5.775c.16.463.295.964-.033 1.318z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Etsy"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 52 52'%3E%3Cpath fill='%23fff' fill-rule='evenodd' clip-rule='evenodd' d='M39.93 34.434c-.736.963-1.646 1.375-2.5 1.375-.547 0-.81-.24-.893-.62l-.305-1.558-.852.04c-.163.918-.325 1.938-.55 2.776.51.38 1.36.578 2.03.578 1.4 0 3.53-.18 5.48-4.73l3.266-7.586c.265-.62.365-.68 1.137-.98l.426-.158v-.7l-1.93.1-2.068-.1v.7l.528.158c.527.16.77.36.77.72 0 .18-.06.358-.162.638-.305.76-2.373 5.55-2.373 5.55-.893-2.177-2.07-5.31-2.273-5.93-.04-.12-.06-.22-.06-.32 0-.318.222-.578.708-.678l.67-.14v-.698l-2.78.1-2.212-.1v.7l.365.118c.508.16.63.3.934.998 1.684 3.794 2.413 5.69 3.488 8.404 0 0-.346.688-.845 1.342zm-11.61-4.988c.04.44.063 1 .063 1.52 0 .54-.02 1.04-.062 1.28 0 0 1.546.56 3.11.56 2.115 0 3.803-1 3.803-2.96 0-3.36-5.123-2.86-5.123-5.12 0-.94.854-1.3 1.79-1.3.73 0 1.34.26 1.463.64l.508 1.5.753-.04c.062-.8.102-1.72.225-2.46-.65-.28-2.014-.44-2.867-.44-1.99 0-3.597.86-3.597 2.78 0 3.34 5 2.66 5 5.12 0 .88-.55 1.5-1.788 1.5-1.138 0-1.708-.58-1.93-1.16l-.57-1.438-.774.018zm-7.216-6.625c-.61.4-1.22.54-1.463.56v.76h1.81v6.142c0 1.72 1.16 2.56 2.704 2.56 1.2 0 2.44-.5 2.867-1.54l-.426-.54c-.203.34-.854.84-1.667.84-.895 0-1.382-.6-1.382-2.12v-5.42l3.01.22.162-1.36-3.17.12v-3.04l-.876-.02c-.285 1.24-.57 2.2-1.566 2.84zm-10.49-3.4c0-.2.02-.32.366-.32h4.655c.813 0 1.26.682 1.586 1.962l.265 1.02h.793c.142-2.9.264-4.16.264-4.16s-1.992.22-3.17.22H9.414l-3.192-.1v.84l1.078.2c.753.14.936.3.997.98 0 0 .062 2 .062 5.3s-.063 5.28-.063 5.28c0 .6-.244.82-.996.96l-1.077.2v.84l3.192-.1h5.326c1.2 0 3.985.1 3.985.1.06-.72.468-3.98.53-4.34H18.5l-.792 1.78c-.63 1.4-1.545 1.5-2.562 1.5h-3.03c-1.016 0-1.503-.4-1.503-1.26v-4.56s2.216 0 2.988.06c.57.04.915.2 1.098.98l.245 1.04h.874l-.062-2.62.122-2.64h-.874l-.284 1.16c-.184.76-.305.9-1.098.98-.895.1-3.01.08-3.01.08v-5.38zM26 52c14.36 0 26-11.64 26-26S40.36 0 26 0 0 11.64 0 26s11.64 26 26 26z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Google Plus"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='58' height='38' viewBox='0 0 58 38'%3E%3Cpath fill='%23fff' fill-rule='evenodd' d='M37.53 15.438c.242 1.282.363 2.612.363 3.99C37.893 30.28 30.498 38 19.333 38 8.653 38 0 29.497 0 19 0 8.502 8.652 0 19.333 0c5.22 0 9.57 1.9 12.93 4.94l-5.438 5.367c-2.03-1.9-4.592-2.85-7.492-2.85-6.38 0-11.6 5.225-11.6 11.543 0 6.27 5.22 11.566 11.6 11.566 5.8 0 9.74-3.253 10.537-7.718H19.333v-7.41H37.53zm14.428 1.187v-5.938h-4.833v5.938h-6.042v4.75h6.042v5.938h4.833v-5.938H58v-4.75h-6.042z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Youtube"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='36' viewBox='0 0 50 36'%3E%3Cpath fill='%23fff' fill-rule='evenodd' d='M48.955 5.622C50 9.632 50 18 50 18s0 8.368-1.045 12.38c-.575 2.21-2.27 3.954-4.42 4.546C40.635 36 25 36 25 36S9.364 36 5.465 34.926c-2.15-.592-3.845-2.335-4.42-4.547C0 26.367 0 18 0 18S0 9.632 1.045 5.622c.575-2.213 2.27-3.956 4.42-4.547C9.365 0 25 0 25 0s15.636 0 19.535 1.075c2.15.59 3.845 2.334 4.42 4.547zM19 25l13-7.5L19 10v15z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Vimeo"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath fill='%23fff' d='M22.396 7.164c-.093 2.026-1.507 4.8-4.245 8.32C15.323 19.16 12.93 21 10.97 21c-1.214 0-2.24-1.12-3.08-3.36-.56-2.052-1.118-4.105-1.68-6.158-.622-2.24-1.29-3.36-2.004-3.36-.156 0-.7.328-1.634.98l-.978-1.26c1.027-.903 2.04-1.806 3.037-2.71C6 3.95 7.03 3.328 7.716 3.265c1.62-.156 2.616.95 2.99 3.32.404 2.558.685 4.148.84 4.77.468 2.12.982 3.18 1.543 3.18.435 0 1.09-.687 1.963-2.064.872-1.376 1.34-2.422 1.402-3.142.125-1.187-.343-1.782-1.4-1.782-.5 0-1.013.115-1.542.34 1.023-3.35 2.977-4.976 5.862-4.883 2.14.063 3.148 1.45 3.024 4.16z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="WeChat"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='57' height='48' viewBox='0 0 57 48'%3E%3Cpath fill='%23fff' d='M56.997 30.744c0-8.163-7.95-14.416-17.173-14.416-9.766 0-17.554 6.394-17.554 14.557 0 8.178 7.408 14.947 17.565 15.003 2.044.012 5.09-.51 7.143-1.362 0 0 4.908 2.955 5.183 2.934s.416-.238.428-.424c.01-.185-1.564-4.797-1.564-4.797 4.214-3.28 5.973-6.89 5.973-11.496zm-23.6-3.014c-1.286 0-2.327-1.036-2.327-2.314s1.04-2.314 2.326-2.314 2.327 1.036 2.327 2.314c0 1.28-1.04 2.314-2.327 2.314zm12.44 0c-1.284 0-2.325-1.036-2.325-2.314s1.04-2.314 2.326-2.314 2.328 1.036 2.328 2.314c0 1.28-1.043 2.314-2.328 2.314z'/%3E%3Cpath fill='%23fff' d='M20.55.043C9.48-.123.28 7.957.28 17.485c0 5.5 2.604 10.272 7.647 13.775 0 0-1.848 6.057-1.822 6.18.026.12.428.358.568.28s6.68-3.95 6.68-3.95c5.014 1.708 7.937 1.14 8.104 1.128-.5-1.454-.828-3.72-.455-5.854C22.956 17.872 34.476 14.396 40.79 14.99 39.046 6.92 31.473.206 20.55.043zm-7.695 14.394c-1.453 0-2.63-1.17-2.63-2.612s1.177-2.612 2.63-2.612 2.63 1.17 2.63 2.612-1.177 2.612-2.63 2.612zm15.92 0c-1.452 0-2.63-1.17-2.63-2.612s1.178-2.612 2.63-2.612c1.453 0 2.63 1.17 2.63 2.612s-1.176 2.612-2.63 2.612z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="WhatsApp"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60' viewBox='0 0 60 60'%3E%3Cpath fill='%23fff' d='M19.85 53.367L6.275 57.69 2.164 59l-1.74.553.584-1.73 5.775-17.068.063.737c-1.004-1.848-1.797-3.8-2.36-5.82-.687-2.45-1.034-4.986-1.034-7.536 0-7.484 2.972-14.597 8.295-19.88C17.07 2.973 24.22.036 31.733.036c7.51 0 14.658 2.94 19.977 8.225C57.03 13.546 60 20.66 60 28.145c0 7.483-2.97 14.594-8.293 19.877-5.32 5.283-12.47 8.222-19.98 8.222-2.39 0-4.76-.296-7.058-.884-1.9-.486-3.747-1.172-5.51-2.044l.69.053zm-.28-.88c1.702.842 3.488 1.506 5.328 1.977 2.23.57 4.526.856 6.83.856 7.258 0 14.176-2.837 19.33-7.954 5.138-5.1 8.02-11.974 8.02-19.222 0-7.25-2.88-14.125-8.017-19.23C45.91 3.798 38.995.958 31.736.958c-7.26 0-14.18 2.836-19.336 7.954-5.14 5.102-8.022 11.975-8.022 19.226 0 2.464.335 4.916.998 7.288.547 1.956 1.315 3.845 2.284 5.627L1.883 58.12l4.11-1.31 13.578-4.323z'/%3E%3Cpath fill='%23fff' d='M49.523 10.464C44.97 5.94 38.68 3.14 31.733 3.14c-6.95 0-13.243 2.798-17.8 7.32C9.377 14.984 6.56 21.234 6.56 28.135c0 2.317.32 4.564.917 6.7.594 2.124 1.462 4.134 2.563 5.99L5.678 53.71l-.346 1.02 1.024-.325 13.412-4.27c1.776.956 3.676 1.705 5.67 2.216 2.01.515 4.116.788 6.288.788 6.95 0 13.24-2.797 17.795-7.32 4.558-4.523 7.375-10.772 7.375-17.672 0-6.906-2.817-13.157-7.372-17.682zM46.686 36.1c-.07.574-.224 1.273-.494 2.026-.302.842-1.092 1.642-1.998 2.273-1.09.762-2.388 1.305-3.18 1.38-.177.016-.34.056-.506.096-.98.237-2.075.503-8.132-1.862-6.676-2.61-11.068-9.037-12.023-10.435-.08-.12-.136-.2-.15-.22l-.005-.004-.003-.005c-.38-.5-2.966-3.915-2.966-7.504 0-3.422 1.693-5.204 2.47-6.02l.123-.13c.327-.36.684-.604 1.03-.766.465-.22.908-.286 1.233-.286.245 0 .503.017.753.032.198.013.39.025.587.025.047 0 .083 0 .12-.004.56-.037 1.293-.084 1.955 1.496.07.167.43 1.033.804 1.942.588 1.42 1.226 2.962 1.336 3.185.113.22.206.467.234.744.03.298-.01.615-.177.95h-.003l-.102.207c-.188.386-.328.67-.664 1.063v.002c-.14.16-.253.296-.367.433-.25.3-.498.6-.718.82-.197.2-.413.414-.22.747.247.424.864 1.43 1.777 2.56.564.697 1.24 1.44 2.008 2.12 2.146 1.902 4.03 2.716 4.998 3.134.19.08.346.147.505.228.25.123.43.176.56.16.094-.012.19-.08.3-.207.263-.298.874-1.004 1.388-1.633.324-.397.62-.776.79-1.03v.002c.335-.51.696-.722 1.11-.77.366-.04.706.065 1.098.206.278.1.98.42 1.77.795 1.224.58 2.655 1.28 3.068 1.49.108.053.222.106.327.156.6.283 1 .472 1.23.854l.002.002c.152.252.233.91.13 1.747z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Telegram"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 52 52'%3E%3Cpath fill='%23fff' d='M26 0C11.64 0 0 11.64 0 26s11.64 26 26 26 26-11.64 26-26S40.36 0 26 0zm12.46 17.55l-4.264 20.38c-.2.957-1.32 1.387-2.11.81l-6.436-4.726-3.28 3.35c-.576.588-1.57.35-1.818-.435l-2.368-7.515-6.345-1.874c-.834-.245-.883-1.405-.074-1.72l24.97-9.73c.95-.37 1.932.46 1.723 1.46z'/%3E%3Cpath fill='%23fff' d='M33.246 20.13L19.55 28.622c-.24.15-.35.443-.267.715l1.837 5.92c.04.124.22.107.234-.022l.447-3.97c.018-.152.09-.295.207-.396l11.598-10.256c.278-.247-.044-.68-.36-.485z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Messenger"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='56' viewBox='0 0 56 56'%3E%3Cpath fill='%23fff' d='M28 0C12.536 0 0 11.607 0 25.926c0 8.16 4.072 15.437 10.435 20.19V56l9.534-5.232c2.543.704 5.24 1.084 8.03 1.084 15.465 0 28-11.607 28-25.926S43.465 0 28 0zm2.783 34.914l-7.13-7.605-13.914 7.604 15.303-16.248 7.304 7.605 13.74-7.604-15.304 16.248z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Line"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath fill='%23fff' d='M39.12 0H8.705C3.93-.006.007 3.86 0 8.638v30.415c-.006 4.777 3.86 8.7 8.638 8.707h30.415c4.776.006 8.697-3.86 8.704-8.64V8.705C47.767 3.927 43.897.007 39.12 0zm-1.657 30.46c-3.647 4.2-11.806 9.314-13.662 10.097-1.854.782-1.58-.498-1.505-.938l.25-1.49c.057-.442.118-1.132-.057-1.57-.194-.485-.965-.736-1.532-.858C12.6 34.597 6.414 28.756 6.414 21.78c0-7.78 7.8-14.11 17.388-14.11C33.39 7.67 41.19 14 41.19 21.78c0 3.115-1.208 5.917-3.727 8.68z'/%3E%3Cpath fill='%23fff' d='M35.398 18.02h-4.873c-.09 0-.174.037-.234.096 0 0 0 .003-.003.004l-.006.006c-.056.06-.093.143-.093.233v7.574c0 .092.037.174.095.234l.005.006c.002 0 .004.002.006.004.06.06.143.095.232.095h4.872c.19 0 .34-.152.34-.34v-1.218c0-.188-.15-.34-.34-.34h-3.31v-1.28h3.31c.19 0 .34-.152.34-.34v-1.22c0-.186-.15-.338-.34-.338h-3.31v-1.28h3.31c.19 0 .34-.15.34-.34v-1.22c0-.185-.15-.337-.34-.337zM17.33 24.375h-3.315v-6.017c0-.187-.15-.34-.338-.34h-1.22c-.187 0-.338.153-.338.34v7.575c0 .092.036.174.093.234 0 .002.003.004.005.006l.005.004c.06.06.143.095.234.095h4.873c.187 0 .338-.152.338-.34v-1.218c0-.187-.152-.34-.34-.34zM28.664 18.02h-1.22c-.188 0-.34.152-.34.338v4.5l-3.47-4.688-.027-.034-.002-.002c-.006-.008-.013-.015-.02-.02l-.007-.006c-.005-.006-.012-.01-.018-.016l-.008-.007-.018-.012-.01-.006-.018-.01c-.003 0-.006-.003-.01-.004l-.02-.01-.01-.003-.02-.006-.012-.003c-.007 0-.013-.002-.02-.003H23.4c-.006-.002-.013-.003-.02-.003h-.016l-.012-.002h-1.22c-.186 0-.338.152-.338.338v7.577c0 .187.152.338.34.338h1.218c.188 0 .34-.15.34-.338v-4.5l3.475 4.694c.025.036.055.063.087.085l.003.003.02.013.01.007.017.007.017.007.01.005.023.008c.002 0 .004 0 .006.002.026.006.056.01.085.01h1.22c.19 0 .34-.15.34-.337V18.36c-.003-.19-.153-.34-.34-.34zM20.27 18.02h-1.22c-.188 0-.34.152-.34.338v7.577c0 .187.153.338.34.338h1.22c.186 0 .338-.15.338-.338v-7.577c0-.187-.152-.338-.34-.338z'/%3E%3C/svg%3E")
            }

            .cover .social-media__item[data-name="Viber"] a::before {
                background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='58' height='60' viewBox='0 0 58 60'%3E%3Cpath fill='%23fff' d='M42.707 2.472C33.635.74 24.5.74 15.49 2.46 9.858 3.686 3.793 9.524 2.445 14.965.766 22.63.766 30.336 2.43 37.936 3.733 43.21 9.347 48.78 14.71 50.313v6.073c0 2.198 2.678 3.278 4.2 1.692l6.152-6.396c1.334.074 2.67.115 4.004.115 4.536 0 9.073-.43 13.577-1.288 5.633-1.23 11.7-7.066 13.045-12.508 1.68-7.666 1.68-15.37.016-22.97-1.36-5.507-7.427-11.345-12.997-12.56zm13.97 35.706c-1.454 5.877-7.815 12-13.768 13.297-4.637.887-9.237 1.322-13.842 1.322-1.318 0-2.668-.04-4.06-.117l.776-.306-6.15 6.396c-2.148 2.236-5.923.715-5.923-2.384v-6.073l.726.96C8.706 49.638 2.844 43.776 1.468 38.22c-1.71-7.81-1.71-15.662-.015-23.404C2.913 8.913 9.273 2.79 15.23 1.49c9.206-1.757 18.468-1.757 27.616-.01C48.862 2.79 55.223 8.91 56.66 14.722c1.717 7.835 1.717 15.687.016 23.455z'/%3E%3Cpath fill='%23fff' d='M50.838 16.134c-.898-3.55-5.502-7.963-9.164-8.778-8.365-1.592-16.848-1.592-25.214 0-3.66.815-8.263 5.23-9.164 8.778-1.497 6.868-1.497 13.83 0 20.7.9 3.55 5.504 7.962 9.164 8.777h.002c.164.033.282.175.282.34v10.062c0 .504.613.75.963.387l4.777-4.905 4.492-4.612c.067-.07.16-.106.255-.104 4.825.133 9.653-.257 14.444-1.168 3.66-.815 8.266-5.23 9.164-8.778 1.498-6.87 1.498-13.832 0-20.7zm-9.035 21.212c-.732 1.555-1.797 2.848-3.334 3.673-.435.232-.952.307-1.442.458-.562-.17-1.098-.286-1.596-.492-5.16-2.142-9.908-4.903-13.67-9.14-2.138-2.407-3.812-5.125-5.227-8.002-.67-1.365-1.237-2.782-1.813-4.19-.526-1.286.25-2.613 1.064-3.58.765-.91 1.75-1.605 2.815-2.117.833-.4 1.654-.17 2.262.536 1.313 1.525 2.52 3.128 3.498 4.896.6 1.086.436 2.416-.653 3.156-.265.18-.505.39-.752.594-.216.178-.42.358-.568.6-.27.44-.284.96-.11 1.44 1.344 3.69 3.607 6.562 7.32 8.108.597.248 1.192.535 1.878.455 1.146-.134 1.518-1.392 2.322-2.05.785-.642 1.79-.65 2.635-.114.846.534 1.666 1.11 2.482 1.69.8.57 1.597 1.13 2.336 1.78.707.626.95 1.446.553 2.296zm-6.662-12.03c-.353.005-.163-.003-.034-.006-.54-.005-.833-.31-.89-.815-.042-.36-.073-.727-.16-1.078-.17-.69-.536-1.333-1.118-1.757-.275-.2-.586-.346-.912-.44-.414-.12-.844-.087-1.258-.188-.448-.11-.697-.474-.626-.895.063-.383.437-.682.855-.652 2.616.19 4.486 1.542 4.753 4.623.02.218.04.447-.007.655-.08.345-.33.52-.577.546.034 0 .04 0-.025.005zm-1.627-7.047c-.803-.395-1.67-.64-2.55-.785-.386-.063-.774-.102-1.16-.156-.47-.066-.72-.365-.697-.826.02-.433.337-.744.808-.717 1.55.088 3.045.423 4.422 1.152 2.8 1.482 4.398 3.824 4.865 6.95.022.142.057.282.067.424.026.35.043.703.07 1.166-.012.084-.018.283-.066.47-.18.677-1.206.762-1.442.078-.07-.203-.08-.434-.08-.652-.003-1.43-.313-2.858-1.035-4.102-.74-1.28-1.872-2.355-3.2-3.005zm8.652 9.66c-.54.006-.784-.446-.82-.932-.07-.96-.117-1.925-.25-2.878-.698-5.03-4.707-9.19-9.71-10.083-.754-.134-1.524-.17-2.287-.25-.482-.05-1.114-.08-1.22-.68-.09-.502.333-.902.812-.928.13-.008.26-.002.392-.002 6.75.19-.13 0 0 0 6.75.19 12.292 4.67 13.48 11.343.202 1.138.274 2.3.364 3.455.037.488-.238.95-.76.955z'/%3E%3C/svg%3E")
            }

            .cover .main-nav {
                font-size: 16px;
                font-weight: 600;
                line-height: 1.3em
            }

            .cover .main-nav .top-menu {
                overflow: hidden;
                margin: 0 0 0 -15px;
                padding: 0;
                list-style: none
            }

            .cover .main-nav .top-menu__item {
                display: inline-block
            }

            .cover .main-nav .top-menu__item a {
                display: inline-block;
                margin: 0;
                padding: 4px 15px;
                color: currentColor;
                text-decoration: none;
                opacity: 1;
                transition: opacity .1s ease-in-out 0s
            }

            .cover .main-nav .top-menu__item a:hover {
                opacity: .7
            }

            .cover .cover__phone a,.cover .cover__directions a,.cover .cover__hours a {
                display: inline-block;
                margin: 0;
                padding: 4px 10px;
                line-height: 1.3
            }

            .cover .cover__phone a,.cover .cover__phone svg,.cover .cover__directions a,.cover .cover__directions svg,.cover .cover__hours a,.cover .cover__hours svg {
                color: currentColor;
                text-decoration: none;
                opacity: 1;
                transition: opacity .1s ease-in-out 0s
            }

            .cover .cover__phone a:hover,.cover .cover__phone svg:hover,.cover .cover__directions a:hover,.cover .cover__directions svg:hover,.cover .cover__hours a:hover,.cover .cover__hours svg:hover {
                opacity: .7
            }

            .cover .cover__phone .svg-icon,.cover .cover__directions .svg-icon,.cover .cover__hours .svg-icon {
                vertical-align: middle
            }

            .cover .jarallax-container>div {
                margin-top: 0 !important
            }

            .cover~.body .tiles {
                background-color: #fff
            }

            .cover .nobr {
                background: transparent;
                color: inherit
            }

            .cover-subtitle-size--xxxs .cover-text {
                font-size: 9.6px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--xxxs .cover-text {
                    font-size:10.8px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--xxxs .cover-text {
                    font-size:13.2px
                }
            }

            .cover-subtitle-size--xxs .cover-text {
                font-size: 11.2px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--xxs .cover-text {
                    font-size:12.6px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--xxs .cover-text {
                    font-size:15.4px
                }
            }

            .cover-subtitle-size--xs .cover-text {
                font-size: 12.8px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--xs .cover-text {
                    font-size:14.4px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--xs .cover-text {
                    font-size:17.6px
                }
            }

            .cover-subtitle-size--s .cover-text {
                font-size: 14.4px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--s .cover-text {
                    font-size:16.2px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--s .cover-text {
                    font-size:19.8px
                }
            }

            .cover-subtitle-size--m .cover-text {
                font-size: 16px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--m .cover-text {
                    font-size:18px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--m .cover-text {
                    font-size:22px
                }
            }

            .cover-subtitle-size--l .cover-text {
                font-size: 17.6px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--l .cover-text {
                    font-size:19.8px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--l .cover-text {
                    font-size:24.2px
                }
            }

            .cover-subtitle-size--xl .cover-text {
                font-size: 19.2px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--xl .cover-text {
                    font-size:21.6px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--xl .cover-text {
                    font-size:26.4px
                }
            }

            .cover-subtitle-size--xxl .cover-text {
                font-size: 20.8px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--xxl .cover-text {
                    font-size:23.4px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--xxl .cover-text {
                    font-size:28.6px
                }
            }

            .cover-subtitle-size--xxxl .cover-text {
                font-size: 22.4px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--xxxl .cover-text {
                    font-size:25.2px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--xxxl .cover-text {
                    font-size:30.8px
                }
            }

            .cover-subtitle-size--xxxxl .cover-text {
                font-size: 24px
            }

            @media screen and (min-width: 768px) {
                .cover-subtitle-size--xxxxl .cover-text {
                    font-size:27px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-subtitle-size--xxxxl .cover-text {
                    font-size:33px
                }
            }

            .cover-button-size--xxxs .cover-button {
                height: 30.888px;
                font-size: 10.8px
            }

            .cover-button-size--xxs .cover-button {
                height: 36.036px;
                font-size: 12.6px
            }

            .cover-button-size--xs .cover-button {
                height: 41.184px;
                font-size: 14.4px
            }

            .cover-button-size--s .cover-button {
                height: 46.332px;
                font-size: 16.2px
            }

            .cover-button-size--m .cover-button {
                height: 51.48px;
                font-size: 18px
            }

            .cover-button-size--l .cover-button {
                height: 56.628px;
                font-size: 19.8px
            }

            .cover-button-size--xl .cover-button {
                height: 61.776px;
                font-size: 21.6px
            }

            .cover-button-size--xxl .cover-button {
                height: 66.924px;
                font-size: 23.4px
            }

            .cover-button-size--xxxl .cover-button {
                height: 72.072px;
                font-size: 25.2px
            }

            .cover-button-size--xxxxl .cover-button {
                height: 77.22px;
                font-size: 27px
            }

            div[class*="cover-layout"] {
                opacity: 1
            }

            .cover__header .cover__directions svg,.cover__header .cover__hours svg {
                fill: currentColor
            }

            .cover__header .clone {
                position: relative;
                top: -10000px
            }

            .parallax-container {
                display: flex;
                position: relative;
                flex-direction: column;
                height: auto !important;
                min-height: 100%;
                overflow: hidden
            }

            .cover-align--center .cover__content-inner {
                text-align: center;
                justify-items: center
            }

            .cover-align--center .cover__body .logo {
                margin: 0 auto
            }

            .cover-logo-position--show-on-cover~.body .caption,.cover-logo-position--hide~.body .caption {
                display: none
            }

            .cover-logo-position--show-below-cover~.body .caption,.cover-logo-position--show-on-and-below-cover~.body .caption {
                display: block
            }

            .cover-logo-position--show-below-cover .cover__logo {
                margin: 0 !important
            }

            .cover-logo-position--show-below-cover .cover__logo .content {
                display: none
            }

            .cover-align--left .container {
                align-items: left;
                max-width: 60%;
                margin: 0 auto
            }

            .cover-align--left .cover-title,.cover-align--left .cover-text {
                margin-left: 0;
                text-align: left
            }

            .wf-loading .starter-site .cover .cover-title,.wf-loading .starter-site .cover .cover-text,.wf-loading .starter-site .cover .header__item,.wf-loading .starter-site .cover .cover__button,.wf-loading .starter-site .cover .cover__footer .forward p {
                opacity: 0
            }

            html#ecwid_html body#ecwid_body .cover .ec-minicart .ec-minicart__icon {
                opacity: 1;
                width: 22px;
                height: 22px;
                color: currentColor;
                transition: opacity .1s ease-in-out 0s
            }

            html#ecwid_html body#ecwid_body .cover .ec-minicart .ec-minicart__icon:hover {
                opacity: .7
            }

            html#ecwid_html body.starter-site#ecwid_body .ec-minicart__icon .icon-default path[stroke],html#ecwid_html body.starter-site#ecwid_body .ec-minicart__icon .icon-default circle[stroke],html#ecwid_html body.starter-site#ecwid_body .ec-minicart:hover.ec-minicart--no-shape.ec-minicart--xxxs .ec-minicart__icon .icon-default path[stroke],html#ecwid_html body.starter-site#ecwid_body .ec-minicart:hover.ec-minicart--no-shape.ec-minicart--xxxs .ec-minicart__icon .icon-default circle[stroke],html#ecwid_html body.starter-site#ecwid_body .ec-minicart:hover.ec-minicart--no-shape.ec-minicart--xxs .ec-minicart__icon .icon-default path[stroke],html#ecwid_html body.starter-site#ecwid_body .ec-minicart:hover.ec-minicart--no-shape.ec-minicart--xxs .ec-minicart__icon .icon-default circle[stroke] {
                stroke: currentColor
            }

            .cover~.body .caption * {
                box-sizing: border-box
            }

            .cover:not(.cover-layout--menu) .logo,.cover~.body .caption .logo {
                position: relative;
                max-width: 212px;
                max-height: 112px;
                border-radius: 4px;
                color: transparent
            }

            @media screen and (min-width: 1100px) {
                .cover:not(.cover-layout--menu) .logo,.cover~.body .caption .logo {
                    max-width:252px;
                    max-height: 132px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover:not(.cover-layout--menu) .logo,.cover~.body .caption .logo {
                    max-width:292px;
                    max-height: 152px
                }
            }

            .cover:not(.cover-layout--menu) .logo img,.cover~.body .caption .logo img {
                width: auto;
                height: auto;
                max-width: 212px;
                max-height: 112px;
                margin: auto;
                background-color: currentColor;
                border: 6px solid currentColor;
                border-radius: 4px
            }

            @media screen and (min-width: 1100px) {
                .cover:not(.cover-layout--menu) .logo img,.cover~.body .caption .logo img {
                    max-width:252px;
                    max-height: 132px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover:not(.cover-layout--menu) .logo img,.cover~.body .caption .logo img {
                    max-width:292px;
                    max-height: 152px
                }
            }

            .cover:not(.cover-layout--menu).cover-logo--circle .logo,.cover~.body .caption.cover-logo--circle .logo {
                width: 112px;
                height: 112px;
                border: 6px solid currentColor;
                border-radius: 50%;
                background-color: currentColor;
                background-repeat: no-repeat;
                background-position: center center
            }

            .cover:not(.cover-layout--menu).cover-logo--circle .logo img,.cover~.body .caption.cover-logo--circle .logo img {
                display: none
            }

            @media screen and (min-width: 1100px) {
                .cover:not(.cover-layout--menu).cover-logo--circle .cover__body .logo,.cover~.body .caption.cover-logo--circle .cover__body .logo {
                    width:132px;
                    height: 132px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover:not(.cover-layout--menu).cover-logo--circle .cover__body .logo,.cover~.body .caption.cover-logo--circle .cover__body .logo {
                    width:152px;
                    height: 152px
                }
            }

            .cover-logo--circle~.body .caption .logo {
                width: 112px;
                height: 112px;
                border: 6px solid currentColor;
                border-radius: 50%;
                background-color: currentColor;
                background-repeat: no-repeat;
                background-position: center center;
                background-size: contain
            }

            @media screen and (min-width: 1100px) {
                .cover-logo--circle~.body .caption .logo {
                    width:132px;
                    height: 132px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-logo--circle~.body .caption .logo {
                    width:152px;
                    height: 152px
                }
            }

            .cover-logo--circle~.body .caption .logo img {
                display: none
            }

            .cover-layout--menu.cover-title-size--xxxs .cover-title {
                font-size: 3vw
            }

            .cover-layout--menu.cover-title-size--xxxs .cover-title--long {
                font-size: 2.1vw
            }

            .cover-layout--menu.cover-title-size--xxs .cover-title {
                font-size: 3.5vw
            }

            .cover-layout--menu.cover-title-size--xxs .cover-title--long {
                font-size: 2.45vw
            }

            .cover-layout--menu.cover-title-size--xs .cover-title {
                font-size: 4vw
            }

            .cover-layout--menu.cover-title-size--xs .cover-title--long {
                font-size: 2.8vw
            }

            .cover-layout--menu.cover-title-size--s .cover-title {
                font-size: 4.5vw
            }

            .cover-layout--menu.cover-title-size--s .cover-title--long {
                font-size: 3.15vw
            }

            .cover-layout--menu.cover-title-size--m .cover-title {
                font-size: 5vw
            }

            .cover-layout--menu.cover-title-size--m .cover-title--long {
                font-size: 3.5vw
            }

            .cover-layout--menu.cover-title-size--l .cover-title {
                font-size: 5.5vw
            }

            .cover-layout--menu.cover-title-size--l .cover-title--long {
                font-size: 3.85vw
            }

            .cover-layout--menu.cover-title-size--xl .cover-title {
                font-size: 6vw
            }

            .cover-layout--menu.cover-title-size--xl .cover-title--long {
                font-size: 4.2vw
            }

            .cover-layout--menu.cover-title-size--xxl .cover-title {
                font-size: 6.5vw
            }

            .cover-layout--menu.cover-title-size--xxl .cover-title--long {
                font-size: 4.55vw
            }

            .cover-layout--menu.cover-title-size--xxxl .cover-title {
                font-size: 7vw
            }

            .cover-layout--menu.cover-title-size--xxxl .cover-title--long {
                font-size: 4.9vw
            }

            .cover-layout--menu.cover-title-size--xxxxl .cover-title {
                font-size: 7.5vw
            }

            .cover-layout--menu.cover-title-size--xxxxl .cover-title--long {
                font-size: 5.25vw
            }

            @media screen and (min-width: 768px) {
                .cover-layout--menu.cover-title-size--xxxs .cover-title {
                    font-size:1.2vw
                }

                .cover-layout--menu.cover-title-size--xxxs .cover-title--long {
                    font-size: .9vw
                }

                .cover-layout--menu.cover-title-size--xxs .cover-title {
                    font-size: 1.4vw
                }

                .cover-layout--menu.cover-title-size--xxs .cover-title--long {
                    font-size: 1.05vw
                }

                .cover-layout--menu.cover-title-size--xs .cover-title {
                    font-size: 1.6vw
                }

                .cover-layout--menu.cover-title-size--xs .cover-title--long {
                    font-size: 1.2vw
                }

                .cover-layout--menu.cover-title-size--s .cover-title {
                    font-size: 1.8vw
                }

                .cover-layout--menu.cover-title-size--s .cover-title--long {
                    font-size: 1.35vw
                }

                .cover-layout--menu.cover-title-size--m .cover-title {
                    font-size: 2vw
                }

                .cover-layout--menu.cover-title-size--m .cover-title--long {
                    font-size: 1.5vw
                }

                .cover-layout--menu.cover-title-size--l .cover-title {
                    font-size: 2.2vw
                }

                .cover-layout--menu.cover-title-size--l .cover-title--long {
                    font-size: 1.65vw
                }

                .cover-layout--menu.cover-title-size--xl .cover-title {
                    font-size: 2.4vw
                }

                .cover-layout--menu.cover-title-size--xl .cover-title--long {
                    font-size: 1.8vw
                }

                .cover-layout--menu.cover-title-size--xxl .cover-title {
                    font-size: 2.6vw
                }

                .cover-layout--menu.cover-title-size--xxl .cover-title--long {
                    font-size: 1.95vw
                }

                .cover-layout--menu.cover-title-size--xxxl .cover-title {
                    font-size: 2.8vw
                }

                .cover-layout--menu.cover-title-size--xxxl .cover-title--long {
                    font-size: 2.1vw
                }

                .cover-layout--menu.cover-title-size--xxxxl .cover-title {
                    font-size: 3vw
                }

                .cover-layout--menu.cover-title-size--xxxxl .cover-title--long {
                    font-size: 2.25vw
                }
            }

            .cover-layout--menu .cover__logo .content .logo,.cover-layout--menu~.body .caption .logo {
                display: flex;
                justify-content: center;
                align-items: center;
                min-width: 212px;
                min-height: 62px;
                max-width: 480px;
                margin: 0 auto;
                color: transparent;
                transition: color .1s ease-out 0s
            }

            .cover-layout--menu .cover__logo .content .logo img,.cover-layout--menu~.body .caption .logo img {
                display: block;
                max-width: 100%;
                height: auto;
                max-height: 75px;
                border: 6px solid currentColor;
                border-radius: 4px;
                background-color: currentColor;
                background-size: 0;
                box-sizing: content-box
            }

            .cover-layout--menu.cover-logo--circle .cover__logo .logo,.cover-layout--menu.cover-logo--circle~.body .caption .logo {
                width: 87px;
                height: 87px;
                min-width: auto;
                min-height: auto;
                border: 6px solid currentColor;
                border-radius: 50%;
                background-color: currentColor;
                background-repeat: no-repeat;
                background-position: center center
            }

            .cover-layout--menu.cover-logo--circle .cover__logo .logo img,.cover-layout--menu.cover-logo--circle~.body .caption .logo img {
                display: none
            }

            .cover-layout--menu:not(.cover-logo--circle) .cover__logo .content .logo,.cover-layout--menu:not(.cover-logo--circle)~.body .caption .logo {
                border: none !important;
                background: none !important
            }

            .cover-logo--hide .cover__logo,.cover-logo-position--hide .cover__logo {
                margin: 0 !important
            }

            .cover-logo--hide .cover__logo .content,.cover-logo-position--hide .cover__logo .content {
                display: none
            }

            .cover-logo--hide~.body .caption,.cover-logo-position--hide~.body .caption {
                display: none
            }

            .cover-layout--menu~.body .caption {
                display: none
            }

            .cover-align--left .cover__content-inner {
                justify-items: start
            }

            .cover-align--left .logo {
                background-position: left center
            }

            .cover-align--left.cover-logo--circle .logo,.cover-align--left.cover-logo--circle~.body .caption .logo {
                background-position: center
            }

            .cover-align--left.cover-layout--menu .cover__logo .content .logo {
                justify-content: left
            }

            .cover:not(.cover-logo--circle) .logo,.cover:not(.cover-logo--circle)~.body .caption .logo {
                background-size: 0
            }

            .cover-logo--circle .logo,.cover-logo--circle~.body .caption .logo {
                background-size: cover
            }

            .cover-logo--circle.cover-logo--homogeneity .logo,.cover-logo--circle.cover-logo--homogeneity~.body .caption .logo {
                background-size: contain
            }

            .cover-logo--circle.cover-logo-border--transparent .content .logo,.cover-logo--circle.cover-logo-border--transparent~.body .caption .logo {
                color: #fff
            }

            .cover__cart {
                overflow: hidden;
                min-height: 22px;
                margin-left: auto
            }

            .cover__cart .content {
                min-width: 32px
            }

            .cover-cart--hide .cover__cart {
                display: none
            }

            .cover__image {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                overflow: hidden;
                z-index: 0;
                background-size: cover;
                display: none
            }

            .cover__image div {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: transparent;
                background-size: cover;
                background-position: center center;
                background-repeat: no-repeat;
                background-attachment: scroll;
                transition: opacity .3s ease-in-out .2s;
                opacity: 0
            }

            @media (max-width: 479px) {
                .cover__image div.desktopPicture,.cover__image div.desktopThumbnail {
                    display:none
                }
            }

            @media (min-width: 480px) {
                .cover__image div.mobilePicture,.cover__image div.mobileThumbnail {
                    display:none
                }
            }

            .cover__image div.mobileThumbnail,.cover__image div.desktopThumbnail {
                filter: blur(20px);
                opacity: 1
            }

            .cover__image canvas {
                position: absolute;
                display: none
            }

            .cover-layout--full .cover__image {
                height: 100%
            }

            @media (min-width: 480px) {
                .cover-layout--full .cover__image div {
                    background-attachment:fixed
                }
            }

            body.touchable .cover .cover__image>div {
                background-attachment: scroll
            }

            body:not(.loading) .cover__image .mobilePicture,body:not(.loading) .cover__image .desktopPicture {
                opacity: 1
            }

            .cover-background--image .cover__background,.cover-background--image .cover__image {
                display: block
            }

            .cover-background--video .video {
                background-image: none !important
            }

            .cover-background--video .cover__background:not(.empty) .jarallax-container {
                background-color: #000
            }

            .cover-background--video .cover__background:not(.empty) .jarallax-container>div {
                transition: opacity 1s ease-out 0s;
                opacity: 1
            }

            .cover-background--gradient .parallax-slider {
                background: transparent !important
            }

            .cover-background--gradient .cover__background {
                display: block
            }

            .cover-background--overlay .cover__overlay {
                display: block
            }

            .cover__overlay {
                display: none;
                position: absolute;
                z-index: 20;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%
            }

            .cover__background {
                z-index: 3
            }

            .cover__background::after {
                content: '';
                position: absolute;
                width: 100%;
                height: 100%;
                top: 0;
                left: 0;
                background-color: rgba(0,0,0,0);
                transition: background-color .2s ease-in-out 0s
            }

            .cover__background.loading::after {
                background-color: rgba(0,0,0,0.7)
            }

            .cover__background.empty .jarallax-container div {
                background-size: auto !important;
                background-repeat: repeat !important
            }

            .cover-overlay--color.cover-background--image .cover__overlay,.cover-overlay--color.cover-background--video .cover__overlay,.cover-overlay--gradient.cover-background--image .cover__overlay,.cover-overlay--gradient.cover-background--video .cover__overlay {
                display: block
            }

            .cover-layout--left .cover-video iframe {
                width: 50vw;
                min-width: 185vh
            }

            .cover__slider.active {
                display: block
            }

            .cover__footer .content {
                display: none
            }

            .cover-arrow--show .cover__footer .content {
                display: block
            }

            .cover__button {
                display: inline-block;
                position: relative;
                max-width: 360px;
                padding: 0 1.8em;
                border: 1px solid transparent;
                border-radius: 3px;
                outline: none;
                box-shadow: 0 0 0 transparent;
                font-weight: 600;
                line-height: normal;
                text-align: center;
                word-wrap: break-word;
                opacity: 1;
                transition: background-color .12s ease-out 0s, color .12s ease-out 0s, border-color .12s ease-out 0s, box-shadow .12s ease-out 0s, transform .05s ease-out 0s, opacity .2s ease-out 0s;
                cursor: pointer;
                -webkit-tap-highlight-color: transparent
            }

            .cover__button::after {
                content: '';
                position: absolute;
                top: -1px;
                left: -1px;
                right: -1px;
                bottom: -1px;
                opacity: 0;
                border-radius: 3px;
                background-color: rgba(255,255,255,0.27);
                transition: opacity .2s ease-out 0s
            }

            .cover__button:hover {
                box-shadow: 0 1px 2px rgba(0,0,0,0.15)
            }

            .cover__button:hover::after {
                opacity: 1
            }

            .cover__button:active {
                box-shadow: 0 0 0 rgba(0,0,0,0);
                transform: translate3d(0, 1px, 0)
            }

            .cover__container {
                display: flex;
                position: relative;
                z-index: 100;
                flex-direction: column;
                padding-top: 20px;
                padding-right: 10px;
                padding-bottom: 40px;
                padding-left: 10px
            }

            @media screen and (min-width: 480px) {
                .cover__container {
                    padding-top:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover__container {
                    padding-top:20px
                }
            }

            @media screen and (min-width: 480px) {
                .cover__container {
                    padding-right:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover__container {
                    padding-right:10px
                }
            }

            @media screen and (min-width: 480px) {
                .cover__container {
                    padding-bottom:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover__container {
                    padding-bottom:40px
                }
            }

            @media screen and (min-width: 480px) {
                .cover__container {
                    padding-left:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover__container {
                    padding-left:10px
                }
            }

            @media screen and (min-width: 480px) {
                .cover__container {
                    padding-top:20px;
                    padding-right: 40px;
                    padding-bottom: 40px;
                    padding-left: 40px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) {
                .cover__container {
                    padding-top:16px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 1024px) {
                .cover__container {
                    padding-top:20px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) {
                .cover__container {
                    padding-right:32px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 1024px) {
                .cover__container {
                    padding-right:40px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) {
                .cover__container {
                    padding-bottom:32px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 1024px) {
                .cover__container {
                    padding-bottom:40px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) {
                .cover__container {
                    padding-left:32px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 1024px) {
                .cover__container {
                    padding-left:40px
                }
            }

            .cover-layout--full .cover__container,.cover-layout--right .cover__container,.cover-layout--left .cover__container {
                min-height: 100vh;
                min-height: calc(var(--vh, 1vh) * 100)
            }

            .cover-layout--half .cover__container {
                min-height: 50vh;
                min-height: calc(var(--vh, 1vh) * 50)
            }

            .cover-layout--half .cover__content {
                -ms-grid-rows: minmax(50vh, 1fr)
            }

            .cover-phone--show-in-header .cover__header .cover__phone {
                display: block
            }

            .cover-phone--show-on-cover .cover__body .cover__phone {
                display: block
            }

            .cover-get-directions--show .cover__directions {
                display: block
            }

            .cover-store-hours--show .cover__hours {
                display: block
            }

            .cover-cart--show:not(.cover-layout--menu) .cover__cart {
                display: block
            }

            .cover-social--show-in-header .cover__header .cover__social {
                display: block
            }

            .cover-social--show-on-cover .cover__body .cover__social {
                display: block
            }

            .cover__body {
                display: flex;
                flex-grow: 1;
                min-height: 0
            }

            .cover__body .cover__phone,.cover__body .cover__social {
                line-height: 1.3em
            }

            .cover__body .cover__phone .svg-icon,.cover__body .cover__social .svg-icon {
                display: inline-block;
                width: 1em;
                height: 1em
            }

            .cover__body .cover__phone .text,.cover__body .cover__social .text {
                vertical-align: middle
            }

            .cover__body .social-media__item a {
                padding: 0 16px
            }

            .cover__content {
                display: -ms-grid;
                display: grid;
                -ms-grid-columns: 100%;
                grid-template-columns: 100%;
                width: 100%;
                -ms-grid-rows: minmax(100vh, 1fr)
            }

            .cover__content-inner {
                display: grid;
                word-break: break-word
            }

            .cover-position--center .cover__content {
                align-content: center;
                justify-items: center
            }

            .cover-position--center .cover__content-inner {
                -ms-grid-column-align: center;
                -ms-grid-row-align: center
            }

            .cover-position--top-left .cover__content {
                align-content: start;
                justify-items: start
            }

            .cover-position--top-left .cover__content-inner {
                -ms-grid-column-align: start;
                -ms-grid-row-align: start
            }

            .cover-position--top .cover__content {
                align-content: start;
                justify-items: center
            }

            .cover-position--top .cover__content-inner {
                -ms-grid-column-align: start;
                -ms-grid-row-align: center
            }

            .cover-position--top-right .cover__content {
                align-content: start;
                justify-items: end
            }

            .cover-position--top-right .cover__content-inner {
                -ms-grid-column-align: start;
                -ms-grid-row-align: end
            }

            .cover-position--right .cover__content {
                align-content: center;
                justify-items: end
            }

            .cover-position--right .cover__content-inner {
                -ms-grid-column-align: center;
                -ms-grid-row-align: end
            }

            .cover-position--bottom-right .cover__content {
                align-content: end;
                justify-items: end
            }

            .cover-position--bottom-right .cover__content-inner {
                -ms-grid-column-align: end;
                -ms-grid-row-align: end
            }

            .cover-position--bottom .cover__content {
                align-content: end;
                justify-items: center
            }

            .cover-position--bottom .cover__content-inner {
                -ms-grid-column-align: end;
                -ms-grid-row-align: center
            }

            .cover-position--bottom-left .cover__content {
                align-content: end;
                justify-items: start
            }

            .cover-position--bottom-left .cover__content-inner {
                -ms-grid-column-align: end;
                -ms-grid-row-align: start
            }

            .cover-position--left .cover__content {
                align-content: center;
                justify-items: start
            }

            .cover-position--left .cover__content-inner {
                -ms-grid-column-align: center;
                -ms-grid-row-align: start
            }

            .cover__logo {
                -ms-grid-row: 1;
                grid-row: 1
            }

            .cover__title {
                -ms-grid-row: 2;
                grid-row: 2
            }

            .cover__subtitle {
                -ms-grid-row: 3;
                grid-row: 3
            }

            .cover__cta {
                -ms-grid-row: 4;
                grid-row: 4
            }

            .cover__phone {
                -ms-grid-row: 5;
                grid-row: 5
            }

            .cover__social {
                -ms-grid-row: 6;
                grid-row: 6
            }

            .cover-menu--show .cover__menu {
                display: block
            }

            .cover-menu--hide .cover__menu {
                margin: 0 !important
            }

            .cover-menu--hide .cover__menu .content {
                display: none
            }

            .cover.cover-title--hide .cover__title {
                margin: 0 !important
            }

            .cover.cover-title--hide .cover__title .content {
                display: none
            }

            .cover.cover-subtitle--hide .cover__subtitle {
                margin: 0 !important
            }

            .cover.cover-subtitle--hide .cover__subtitle .content {
                display: none
            }

            .cover.cover-cta--hide .cover__cta {
                margin: 0 !important
            }

            .cover.cover-cta--hide .cover__cta .content {
                display: none
            }

            .cover.cover-phone--hide .cover__phone {
                margin: 0 !important
            }

            .cover.cover-phone--hide .cover__phone .content {
                display: none
            }

            .cover.cover-hours--hide .cover__hours {
                margin: 0 !important
            }

            .cover.cover-hours--hide .cover__hours .content {
                display: none
            }

            .cover.cover-directions--hide .cover__directions {
                margin: 0 !important
            }

            .cover.cover-directions--hide .cover__directions .content {
                display: none
            }

            .cover.cover-social--hide .cover__social {
                margin: 0 !important
            }

            .cover.cover-social--hide .cover__social .content {
                display: none
            }

            .cover.cover-cart--hide .cover__cart {
                margin: 0 !important;
                min-width: 0
            }

            .cover.cover-cart--hide .cover__cart .content {
                display: none
            }

            .cover__footer {
                display: flex;
                align-items: center;
                justify-content: center
            }

            .cover__footer .forward {
                display: inline-block;
                margin: 0 auto;
                padding: 0 24px;
                cursor: pointer
            }

            .cover__footer .forward p {
                display: block;
                margin: 0 auto;
                font-size: 1em;
                font-weight: 400;
                line-height: 1.3em;
                color: currentColor;
                opacity: 1;
                transition: opacity .1s ease-in-out 0s;
                -webkit-font-smoothing: antialiased;
                margin-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .cover__footer .forward p {
                    margin-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover__footer .forward p {
                    margin-bottom:10px
                }
            }

            .cover__footer .forward .svg-icon {
                text-align: center;
                transition: opacity .1s ease-in-out 0s
            }

            .cover__footer .forward .svg-icon svg {
                stroke: currentColor
            }

            .cover-layout--full .cover__content-inner {
                max-width: 80%
            }

            .cover-layout--full.cover-title-size--xxxs .cover-title {
                font-size: 4.2vw
            }

            .cover-layout--full.cover-title-size--xxxs .cover-title--long {
                font-size: 3vw
            }

            .cover-layout--full.cover-title-size--xxs .cover-title {
                font-size: 4.9vw
            }

            .cover-layout--full.cover-title-size--xxs .cover-title--long {
                font-size: 3.5vw
            }

            .cover-layout--full.cover-title-size--xs .cover-title {
                font-size: 5.6vw
            }

            .cover-layout--full.cover-title-size--xs .cover-title--long {
                font-size: 4vw
            }

            .cover-layout--full.cover-title-size--s .cover-title {
                font-size: 6.3vw
            }

            .cover-layout--full.cover-title-size--s .cover-title--long {
                font-size: 4.5vw
            }

            .cover-layout--full.cover-title-size--m .cover-title {
                font-size: 7vw
            }

            .cover-layout--full.cover-title-size--m .cover-title--long {
                font-size: 5vw
            }

            .cover-layout--full.cover-title-size--l .cover-title {
                font-size: 7.7vw
            }

            .cover-layout--full.cover-title-size--l .cover-title--long {
                font-size: 5.5vw
            }

            .cover-layout--full.cover-title-size--xl .cover-title {
                font-size: 8.4vw
            }

            .cover-layout--full.cover-title-size--xl .cover-title--long {
                font-size: 6vw
            }

            .cover-layout--full.cover-title-size--xxl .cover-title {
                font-size: 9.1vw
            }

            .cover-layout--full.cover-title-size--xxl .cover-title--long {
                font-size: 6.5vw
            }

            .cover-layout--full.cover-title-size--xxxl .cover-title {
                font-size: 9.8vw
            }

            .cover-layout--full.cover-title-size--xxxl .cover-title--long {
                font-size: 7vw
            }

            .cover-layout--full.cover-title-size--xxxxl .cover-title {
                font-size: 10.5vw
            }

            .cover-layout--full.cover-title-size--xxxxl .cover-title--long {
                font-size: 7.5vw
            }

            .cover-layout--full .cover__body .cover__logo {
                margin-bottom: 40px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--full .cover__body .cover__logo {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--full .cover__body .cover__logo {
                    margin-bottom:40px
                }
            }

            .cover-layout--full .cover__body .cover__title {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--full .cover__body .cover__title {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--full .cover__body .cover__title {
                    margin-bottom:20px
                }
            }

            .cover-layout--full .cover__body .cover__subtitle {
                margin-bottom: 40px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--full .cover__body .cover__subtitle {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--full .cover__body .cover__subtitle {
                    margin-bottom:40px
                }
            }

            .cover-layout--full .cover__body .cover__cta {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--full .cover__body .cover__cta {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--full .cover__body .cover__cta {
                    margin-bottom:20px
                }
            }

            .cover-layout--full .cover__body .cover__phone {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--full .cover__body .cover__phone {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--full .cover__body .cover__phone {
                    margin-bottom:20px
                }
            }

            .cover-layout--full .cover__body .cover__social {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--full .cover__body .cover__social {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--full .cover__body .cover__social {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--full.cover-title-size--xxxs .cover-title {
                    font-size:3vw
                }

                .cover-layout--full.cover-title-size--xxxs .cover-title--long {
                    font-size: 2.1vw
                }

                .cover-layout--full.cover-title-size--xxs .cover-title {
                    font-size: 3.5vw
                }

                .cover-layout--full.cover-title-size--xxs .cover-title--long {
                    font-size: 2.45vw
                }

                .cover-layout--full.cover-title-size--xs .cover-title {
                    font-size: 4vw
                }

                .cover-layout--full.cover-title-size--xs .cover-title--long {
                    font-size: 2.8vw
                }

                .cover-layout--full.cover-title-size--s .cover-title {
                    font-size: 4.5vw
                }

                .cover-layout--full.cover-title-size--s .cover-title--long {
                    font-size: 3.15vw
                }

                .cover-layout--full.cover-title-size--m .cover-title {
                    font-size: 5vw
                }

                .cover-layout--full.cover-title-size--m .cover-title--long {
                    font-size: 3.5vw
                }

                .cover-layout--full.cover-title-size--l .cover-title {
                    font-size: 5.5vw
                }

                .cover-layout--full.cover-title-size--l .cover-title--long {
                    font-size: 3.85vw
                }

                .cover-layout--full.cover-title-size--xl .cover-title {
                    font-size: 6vw
                }

                .cover-layout--full.cover-title-size--xl .cover-title--long {
                    font-size: 4.2vw
                }

                .cover-layout--full.cover-title-size--xxl .cover-title {
                    font-size: 6.5vw
                }

                .cover-layout--full.cover-title-size--xxl .cover-title--long {
                    font-size: 4.55vw
                }

                .cover-layout--full.cover-title-size--xxxl .cover-title {
                    font-size: 7vw
                }

                .cover-layout--full.cover-title-size--xxxl .cover-title--long {
                    font-size: 4.9vw
                }

                .cover-layout--full.cover-title-size--xxxxl .cover-title {
                    font-size: 7.5vw
                }

                .cover-layout--full.cover-title-size--xxxxl .cover-title--long {
                    font-size: 5.25vw
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--full .cover__content-inner {
                    max-width:60%
                }
            }

            .cover-layout--full .jarallax-container>div,.cover-layout--full .cover__image {
                min-height: 100vh
            }

            .cover-layout--left.cover-title-size--xxxs .cover-title,.cover-layout--right.cover-title-size--xxxs .cover-title {
                font-size: 4.2vw
            }

            .cover-layout--left.cover-title-size--xxxs .cover-title--long,.cover-layout--right.cover-title-size--xxxs .cover-title--long {
                font-size: 3vw
            }

            .cover-layout--left.cover-title-size--xxs .cover-title,.cover-layout--right.cover-title-size--xxs .cover-title {
                font-size: 4.9vw
            }

            .cover-layout--left.cover-title-size--xxs .cover-title--long,.cover-layout--right.cover-title-size--xxs .cover-title--long {
                font-size: 3.5vw
            }

            .cover-layout--left.cover-title-size--xs .cover-title,.cover-layout--right.cover-title-size--xs .cover-title {
                font-size: 5.6vw
            }

            .cover-layout--left.cover-title-size--xs .cover-title--long,.cover-layout--right.cover-title-size--xs .cover-title--long {
                font-size: 4vw
            }

            .cover-layout--left.cover-title-size--s .cover-title,.cover-layout--right.cover-title-size--s .cover-title {
                font-size: 6.3vw
            }

            .cover-layout--left.cover-title-size--s .cover-title--long,.cover-layout--right.cover-title-size--s .cover-title--long {
                font-size: 4.5vw
            }

            .cover-layout--left.cover-title-size--m .cover-title,.cover-layout--right.cover-title-size--m .cover-title {
                font-size: 7vw
            }

            .cover-layout--left.cover-title-size--m .cover-title--long,.cover-layout--right.cover-title-size--m .cover-title--long {
                font-size: 5vw
            }

            .cover-layout--left.cover-title-size--l .cover-title,.cover-layout--right.cover-title-size--l .cover-title {
                font-size: 7.7vw
            }

            .cover-layout--left.cover-title-size--l .cover-title--long,.cover-layout--right.cover-title-size--l .cover-title--long {
                font-size: 5.5vw
            }

            .cover-layout--left.cover-title-size--xl .cover-title,.cover-layout--right.cover-title-size--xl .cover-title {
                font-size: 8.4vw
            }

            .cover-layout--left.cover-title-size--xl .cover-title--long,.cover-layout--right.cover-title-size--xl .cover-title--long {
                font-size: 6vw
            }

            .cover-layout--left.cover-title-size--xxl .cover-title,.cover-layout--right.cover-title-size--xxl .cover-title {
                font-size: 9.1vw
            }

            .cover-layout--left.cover-title-size--xxl .cover-title--long,.cover-layout--right.cover-title-size--xxl .cover-title--long {
                font-size: 6.5vw
            }

            .cover-layout--left.cover-title-size--xxxl .cover-title,.cover-layout--right.cover-title-size--xxxl .cover-title {
                font-size: 9.8vw
            }

            .cover-layout--left.cover-title-size--xxxl .cover-title--long,.cover-layout--right.cover-title-size--xxxl .cover-title--long {
                font-size: 7vw
            }

            .cover-layout--left.cover-title-size--xxxxl .cover-title,.cover-layout--right.cover-title-size--xxxxl .cover-title {
                font-size: 10.5vw
            }

            .cover-layout--left.cover-title-size--xxxxl .cover-title--long,.cover-layout--right.cover-title-size--xxxxl .cover-title--long {
                font-size: 7.5vw
            }

            .cover-layout--left .cover__body .cover__logo,.cover-layout--right .cover__body .cover__logo {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__logo,.cover-layout--right .cover__body .cover__logo {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__logo,.cover-layout--right .cover__body .cover__logo {
                    margin-bottom:20px
                }
            }

            .cover-layout--left .cover__body .cover__title,.cover-layout--right .cover__body .cover__title {
                margin-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__title,.cover-layout--right .cover__body .cover__title {
                    margin-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__title,.cover-layout--right .cover__body .cover__title {
                    margin-bottom:10px
                }
            }

            .cover-layout--left .cover__body .cover__subtitle,.cover-layout--right .cover__body .cover__subtitle {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__subtitle,.cover-layout--right .cover__body .cover__subtitle {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__subtitle,.cover-layout--right .cover__body .cover__subtitle {
                    margin-bottom:20px
                }
            }

            .cover-layout--left .cover__body .cover__cta,.cover-layout--right .cover__body .cover__cta {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__cta,.cover-layout--right .cover__body .cover__cta {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__cta,.cover-layout--right .cover__body .cover__cta {
                    margin-bottom:20px
                }
            }

            .cover-layout--left .cover__body .cover__phone,.cover-layout--right .cover__body .cover__phone {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__phone,.cover-layout--right .cover__body .cover__phone {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__phone,.cover-layout--right .cover__body .cover__phone {
                    margin-bottom:20px
                }
            }

            .cover-layout--left .cover__body .cover__social,.cover-layout--right .cover__body .cover__social {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__social,.cover-layout--right .cover__body .cover__social {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__social,.cover-layout--right .cover__body .cover__social {
                    margin-bottom:20px
                }
            }

            .cover-layout--left .jarallax-container,.cover-layout--left .jarallax-container>div,.cover-layout--left .cover__slider .slide,.cover-layout--left .cover__overlay,.cover-layout--left .cover__image,.cover-layout--right .jarallax-container,.cover-layout--right .jarallax-container>div,.cover-layout--right .cover__slider .slide,.cover-layout--right .cover__overlay,.cover-layout--right .cover__image {
                max-height: 50vh
            }

            @media screen and (min-width: 768px) {
                .cover-layout--left .cover__body,.cover-layout--left .cover__footer,.cover-layout--right .cover__body,.cover-layout--right .cover__footer {
                    padding-right:20px
                }
            }

            @media screen and (min-width: 768px) and (min-width: 480px) {
                .cover-layout--left .cover__body,.cover-layout--left .cover__footer,.cover-layout--right .cover__body,.cover-layout--right .cover__footer {
                    padding-right:16px
                }
            }

            @media screen and (min-width: 768px) and (min-width: 1024px) {
                .cover-layout--left .cover__body,.cover-layout--left .cover__footer,.cover-layout--right .cover__body,.cover-layout--right .cover__footer {
                    padding-right:20px
                }
            }

            .cover-layout--left .cover__container,.cover-layout--right .cover__container {
                background: linear-gradient(to bottom, rgba(0,0,0,0), rgba(0,0,0,0.03))
            }

            .cover-layout--left .cover__content-inner,.cover-layout--right .cover__content-inner {
                width: 100%;
                max-width: 80%
            }

            @media screen and (max-width: 767px) {
                .cover-layout--left .jarallax-container>iframe,.cover-layout--right .jarallax-container>iframe {
                    margin-top:0 !important;
                    max-height: 50vh !important
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--left .cover__content,.cover-layout--right .cover__content {
                    margin-top:-10%
                }

                .cover-layout--left .cover__image,.cover-layout--right .cover__image {
                    min-height: 100%
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--left .cover__header,.cover-layout--right .cover__header {
                    width:50%;
                    padding-right: 40px
                }
            }

            @media screen and (min-width: 768px) and (min-width: 480px) {
                .cover-layout--left .cover__header,.cover-layout--right .cover__header {
                    padding-right:32px
                }
            }

            @media screen and (min-width: 768px) and (min-width: 1024px) {
                .cover-layout--left .cover__header,.cover-layout--right .cover__header {
                    padding-right:40px
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--left .cover__body,.cover-layout--right .cover__body {
                    margin-top:initial
                }

                .cover-layout--left .cover__body,.cover-layout--left .cover__footer,.cover-layout--right .cover__body,.cover-layout--right .cover__footer {
                    width: 50%
                }

                .cover-layout--left .jarallax-container,.cover-layout--left .cover__slider .slide,.cover-layout--left .cover__overlay,.cover-layout--left .cover__image,.cover-layout--right .jarallax-container,.cover-layout--right .cover__slider .slide,.cover-layout--right .cover__overlay,.cover-layout--right .cover__image {
                    max-width: 50%;
                    height: 100%
                }

                .cover-layout--left .jarallax-container,.cover-layout--left .jarallax-container>div,.cover-layout--left .cover__slider .slide,.cover-layout--left .cover__overlay,.cover-layout--left .cover__image,.cover-layout--right .jarallax-container,.cover-layout--right .jarallax-container>div,.cover-layout--right .cover__slider .slide,.cover-layout--right .cover__overlay,.cover-layout--right .cover__image {
                    max-height: unset
                }

                .cover-layout--left.cover-title-size--xxxs .cover-title,.cover-layout--right.cover-title-size--xxxs .cover-title {
                    font-size: 2.7vw
                }

                .cover-layout--left.cover-title-size--xxxs .cover-title--long,.cover-layout--right.cover-title-size--xxxs .cover-title--long {
                    font-size: 1.92vw
                }

                .cover-layout--left.cover-title-size--xxs .cover-title,.cover-layout--right.cover-title-size--xxs .cover-title {
                    font-size: 3.15vw
                }

                .cover-layout--left.cover-title-size--xxs .cover-title--long,.cover-layout--right.cover-title-size--xxs .cover-title--long {
                    font-size: 2.24vw
                }

                .cover-layout--left.cover-title-size--xs .cover-title,.cover-layout--right.cover-title-size--xs .cover-title {
                    font-size: 3.6vw
                }

                .cover-layout--left.cover-title-size--xs .cover-title--long,.cover-layout--right.cover-title-size--xs .cover-title--long {
                    font-size: 2.56vw
                }

                .cover-layout--left.cover-title-size--s .cover-title,.cover-layout--right.cover-title-size--s .cover-title {
                    font-size: 4.05vw
                }

                .cover-layout--left.cover-title-size--s .cover-title--long,.cover-layout--right.cover-title-size--s .cover-title--long {
                    font-size: 2.88vw
                }

                .cover-layout--left.cover-title-size--m .cover-title,.cover-layout--right.cover-title-size--m .cover-title {
                    font-size: 4.5vw
                }

                .cover-layout--left.cover-title-size--m .cover-title--long,.cover-layout--right.cover-title-size--m .cover-title--long {
                    font-size: 3.2vw
                }

                .cover-layout--left.cover-title-size--l .cover-title,.cover-layout--right.cover-title-size--l .cover-title {
                    font-size: 4.95vw
                }

                .cover-layout--left.cover-title-size--l .cover-title--long,.cover-layout--right.cover-title-size--l .cover-title--long {
                    font-size: 3.52vw
                }

                .cover-layout--left.cover-title-size--xl .cover-title,.cover-layout--right.cover-title-size--xl .cover-title {
                    font-size: 5.4vw
                }

                .cover-layout--left.cover-title-size--xl .cover-title--long,.cover-layout--right.cover-title-size--xl .cover-title--long {
                    font-size: 3.84vw
                }

                .cover-layout--left.cover-title-size--xxl .cover-title,.cover-layout--right.cover-title-size--xxl .cover-title {
                    font-size: 5.85vw
                }

                .cover-layout--left.cover-title-size--xxl .cover-title--long,.cover-layout--right.cover-title-size--xxl .cover-title--long {
                    font-size: 4.16vw
                }

                .cover-layout--left.cover-title-size--xxxl .cover-title,.cover-layout--right.cover-title-size--xxxl .cover-title {
                    font-size: 6.3vw
                }

                .cover-layout--left.cover-title-size--xxxl .cover-title--long,.cover-layout--right.cover-title-size--xxxl .cover-title--long {
                    font-size: 4.48vw
                }

                .cover-layout--left.cover-title-size--xxxxl .cover-title,.cover-layout--right.cover-title-size--xxxxl .cover-title {
                    font-size: 6.75vw
                }

                .cover-layout--left.cover-title-size--xxxxl .cover-title--long,.cover-layout--right.cover-title-size--xxxxl .cover-title--long {
                    font-size: 4.8vw
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .cover__logo,.cover-layout--right .cover__logo {
                    margin-bottom:calc(20px + 10 * ((100vw - 1024px) / 416))
                }

                .cover-layout--left .cover__title,.cover-layout--right .cover__title {
                    margin-bottom: calc(10px + 5 * ((100vw - 1024px) / 416))
                }

                .cover-layout--left .cover__subtitle,.cover-layout--right .cover__subtitle {
                    margin-bottom: calc(20px + 10 * ((100vw - 1024px) / 416))
                }

                .cover-layout--left .cover__header,.cover-layout--right .cover__header {
                    width: 62%
                }

                .cover-layout--left .cover__body,.cover-layout--left .cover__footer,.cover-layout--right .cover__body,.cover-layout--right .cover__footer {
                    width: 38%
                }

                .cover-layout--left .jarallax-container,.cover-layout--left .cover__slider .slide,.cover-layout--left .cover__overlay,.cover-layout--left .cover__image,.cover-layout--right .jarallax-container,.cover-layout--right .cover__slider .slide,.cover-layout--right .cover__overlay,.cover-layout--right .cover__image {
                    max-width: 62%
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-layout--left.cover-title-size--xxxs .cover-title,.cover-layout--right.cover-title-size--xxxs .cover-title {
                    font-size:2.1vw
                }

                .cover-layout--left.cover-title-size--xxxs .cover-title--long,.cover-layout--right.cover-title-size--xxxs .cover-title--long {
                    font-size: 2.1vw
                }

                .cover-layout--left.cover-title-size--xxs .cover-title,.cover-layout--right.cover-title-size--xxs .cover-title {
                    font-size: 2.45vw
                }

                .cover-layout--left.cover-title-size--xxs .cover-title--long,.cover-layout--right.cover-title-size--xxs .cover-title--long {
                    font-size: 2.45vw
                }

                .cover-layout--left.cover-title-size--xs .cover-title,.cover-layout--right.cover-title-size--xs .cover-title {
                    font-size: 2.8vw
                }

                .cover-layout--left.cover-title-size--xs .cover-title--long,.cover-layout--right.cover-title-size--xs .cover-title--long {
                    font-size: 2.8vw
                }

                .cover-layout--left.cover-title-size--s .cover-title,.cover-layout--right.cover-title-size--s .cover-title {
                    font-size: 3.15vw
                }

                .cover-layout--left.cover-title-size--s .cover-title--long,.cover-layout--right.cover-title-size--s .cover-title--long {
                    font-size: 3.15vw
                }

                .cover-layout--left.cover-title-size--m .cover-title,.cover-layout--right.cover-title-size--m .cover-title {
                    font-size: 3.5vw
                }

                .cover-layout--left.cover-title-size--m .cover-title--long,.cover-layout--right.cover-title-size--m .cover-title--long {
                    font-size: 3.5vw
                }

                .cover-layout--left.cover-title-size--l .cover-title,.cover-layout--right.cover-title-size--l .cover-title {
                    font-size: 3.85vw
                }

                .cover-layout--left.cover-title-size--l .cover-title--long,.cover-layout--right.cover-title-size--l .cover-title--long {
                    font-size: 3.85vw
                }

                .cover-layout--left.cover-title-size--xl .cover-title,.cover-layout--right.cover-title-size--xl .cover-title {
                    font-size: 4.2vw
                }

                .cover-layout--left.cover-title-size--xl .cover-title--long,.cover-layout--right.cover-title-size--xl .cover-title--long {
                    font-size: 4.2vw
                }

                .cover-layout--left.cover-title-size--xxl .cover-title,.cover-layout--right.cover-title-size--xxl .cover-title {
                    font-size: 4.55vw
                }

                .cover-layout--left.cover-title-size--xxl .cover-title--long,.cover-layout--right.cover-title-size--xxl .cover-title--long {
                    font-size: 4.55vw
                }

                .cover-layout--left.cover-title-size--xxxl .cover-title,.cover-layout--right.cover-title-size--xxxl .cover-title {
                    font-size: 4.9vw
                }

                .cover-layout--left.cover-title-size--xxxl .cover-title--long,.cover-layout--right.cover-title-size--xxxl .cover-title--long {
                    font-size: 4.9vw
                }

                .cover-layout--left.cover-title-size--xxxxl .cover-title,.cover-layout--right.cover-title-size--xxxxl .cover-title {
                    font-size: 5.25vw
                }

                .cover-layout--left.cover-title-size--xxxxl .cover-title--long,.cover-layout--right.cover-title-size--xxxxl .cover-title--long {
                    font-size: 5.25vw
                }

                .cover-layout--left .cover__logo,.cover-layout--right .cover__logo {
                    margin-bottom: calc(30px + 10 * ((100vw - 1440px) / 480))
                }

                .cover-layout--left .cover__title,.cover-layout--right .cover__title {
                    margin-bottom: calc(15px + 5 * ((100vw - 1440px) / 480))
                }

                .cover-layout--left .cover__subtitle,.cover-layout--right .cover__subtitle {
                    margin-bottom: calc(30px + 10 * ((100vw - 1440px) / 480))
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-layout--left .cover__body .cover__logo,.cover-layout--right .cover__body .cover__logo {
                    margin-bottom:40px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__logo,.cover-layout--right .cover__body .cover__logo {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__logo,.cover-layout--right .cover__body .cover__logo {
                    margin-bottom:40px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-layout--left .cover__body .cover__title,.cover-layout--right .cover__body .cover__title {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__title,.cover-layout--right .cover__body .cover__title {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__title,.cover-layout--right .cover__body .cover__title {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-layout--left .cover__body .cover__subtitle,.cover-layout--right .cover__body .cover__subtitle {
                    margin-bottom:40px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__subtitle,.cover-layout--right .cover__body .cover__subtitle {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__subtitle,.cover-layout--right .cover__body .cover__subtitle {
                    margin-bottom:40px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-layout--left .cover__body .cover__cta,.cover-layout--right .cover__body .cover__cta {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__cta,.cover-layout--right .cover__body .cover__cta {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__cta,.cover-layout--right .cover__body .cover__cta {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-layout--left .cover__body .cover__phone,.cover-layout--right .cover__body .cover__phone {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__phone,.cover-layout--right .cover__body .cover__phone {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__phone,.cover-layout--right .cover__body .cover__phone {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-layout--left .cover__body .cover__social,.cover-layout--right .cover__body .cover__social {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 480px) {
                .cover-layout--left .cover__body .cover__social,.cover-layout--right .cover__body .cover__social {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 1024px) {
                .cover-layout--left .cover__body .cover__social,.cover-layout--right .cover__body .cover__social {
                    margin-bottom:20px
                }
            }

            .cover-layout--left .cover__body,.cover-layout--right .cover__body {
                margin-top: calc(50vh - 60px)
            }

            @media screen and (min-width: 768px) {
                .cover-layout--left .cover__body,.cover-layout--right .cover__body {
                    margin-top:initial
                }
            }

            .cover-layout--left.cover-logo--show.cover-logo-position--show-on-cover .cover__body,.cover-layout--left.cover-logo--show.cover-logo-position--show-on-and-below-cover .cover__body,.cover-layout--right.cover-logo--show.cover-logo-position--show-on-cover .cover__body,.cover-layout--right.cover-logo--show.cover-logo-position--show-on-and-below-cover .cover__body {
                margin-top: calc(50vh - 126px)
            }

            @media screen and (min-width: 768px) {
                .cover-layout--left.cover-logo--show.cover-logo-position--show-on-cover .cover__body,.cover-layout--left.cover-logo--show.cover-logo-position--show-on-and-below-cover .cover__body,.cover-layout--right.cover-logo--show.cover-logo-position--show-on-cover .cover__body,.cover-layout--right.cover-logo--show.cover-logo-position--show-on-and-below-cover .cover__body {
                    margin-top:initial
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--right .main-nav {
                    text-align:right
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--right .cover__header {
                    margin-left:50%
                }

                .cover-layout--right .jarallax-container,.cover-layout--right .cover__slider .slide,.cover-layout--right .cover__overlay,.cover-layout--right .cover__image {
                    margin-left: 50%
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--right .cover__header {
                    margin-left:38%;
                    padding-left: 40px
                }
            }

            @media screen and (min-width: 1024px) and (min-width: 480px) {
                .cover-layout--right .cover__header {
                    padding-left:32px
                }
            }

            @media screen and (min-width: 1024px) and (min-width: 1024px) {
                .cover-layout--right .cover__header {
                    padding-left:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--right .cover__body,.cover-layout--right .cover__footer {
                    margin-left:-20px
                }
            }

            @media screen and (min-width: 1024px) and (min-width: 480px) {
                .cover-layout--right .cover__body,.cover-layout--right .cover__footer {
                    margin-left:-16px
                }
            }

            @media screen and (min-width: 1024px) and (min-width: 1024px) {
                .cover-layout--right .cover__body,.cover-layout--right .cover__footer {
                    margin-left:-20px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--right .jarallax-container,.cover-layout--right .cover__slider .slide,.cover-layout--right .cover__overlay,.cover-layout--right .cover__image {
                    margin-left:38%
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--left .cover__header {
                    margin-left:0
                }

                .cover-layout--left .cover__body,.cover-layout--left .cover__footer {
                    margin-left: 50%
                }

                .cover-layout--left .jarallax-container,.cover-layout--left .cover__slider .slide,.cover-layout--left .cover__overlay,.cover-layout--left .cover__image {
                    margin-left: 0
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .cover__header {
                    margin-left:0
                }

                .cover-layout--left .cover__body,.cover-layout--left .cover__footer {
                    margin-left: 62%;
                    padding-right: 0;
                    padding-left: 40px
                }
            }

            @media screen and (min-width: 1024px) and (min-width: 480px) {
                .cover-layout--left .cover__body,.cover-layout--left .cover__footer {
                    padding-left:32px
                }
            }

            @media screen and (min-width: 1024px) and (min-width: 1024px) {
                .cover-layout--left .cover__body,.cover-layout--left .cover__footer {
                    padding-left:40px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--left .jarallax-container,.cover-layout--left .cover__slider .slide,.cover-layout--left .cover__overlay,.cover-layout--left .cover__image {
                    margin-left:0
                }
            }

            .cover-layout--half .cover__content-inner {
                max-width: 80%
            }

            .cover-layout--half.cover-title-size--xxxs .cover-title {
                font-size: 4.2vw
            }

            .cover-layout--half.cover-title-size--xxxs .cover-title--long {
                font-size: 3vw
            }

            .cover-layout--half.cover-title-size--xxs .cover-title {
                font-size: 4.9vw
            }

            .cover-layout--half.cover-title-size--xxs .cover-title--long {
                font-size: 3.5vw
            }

            .cover-layout--half.cover-title-size--xs .cover-title {
                font-size: 5.6vw
            }

            .cover-layout--half.cover-title-size--xs .cover-title--long {
                font-size: 4vw
            }

            .cover-layout--half.cover-title-size--s .cover-title {
                font-size: 6.3vw
            }

            .cover-layout--half.cover-title-size--s .cover-title--long {
                font-size: 4.5vw
            }

            .cover-layout--half.cover-title-size--m .cover-title {
                font-size: 7vw
            }

            .cover-layout--half.cover-title-size--m .cover-title--long {
                font-size: 5vw
            }

            .cover-layout--half.cover-title-size--l .cover-title {
                font-size: 7.7vw
            }

            .cover-layout--half.cover-title-size--l .cover-title--long {
                font-size: 5.5vw
            }

            .cover-layout--half.cover-title-size--xl .cover-title {
                font-size: 8.4vw
            }

            .cover-layout--half.cover-title-size--xl .cover-title--long {
                font-size: 6vw
            }

            .cover-layout--half.cover-title-size--xxl .cover-title {
                font-size: 9.1vw
            }

            .cover-layout--half.cover-title-size--xxl .cover-title--long {
                font-size: 6.5vw
            }

            .cover-layout--half.cover-title-size--xxxl .cover-title {
                font-size: 9.8vw
            }

            .cover-layout--half.cover-title-size--xxxl .cover-title--long {
                font-size: 7vw
            }

            .cover-layout--half.cover-title-size--xxxxl .cover-title {
                font-size: 10.5vw
            }

            .cover-layout--half.cover-title-size--xxxxl .cover-title--long {
                font-size: 7.5vw
            }

            .cover-layout--half .cover__body .cover__logo {
                margin-bottom: 40px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--half .cover__body .cover__logo {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--half .cover__body .cover__logo {
                    margin-bottom:40px
                }
            }

            .cover-layout--half .cover__body .cover__title {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--half .cover__body .cover__title {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--half .cover__body .cover__title {
                    margin-bottom:20px
                }
            }

            .cover-layout--half .cover__body .cover__subtitle {
                margin-bottom: 40px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--half .cover__body .cover__subtitle {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--half .cover__body .cover__subtitle {
                    margin-bottom:40px
                }
            }

            .cover-layout--half .cover__body .cover__cta {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--half .cover__body .cover__cta {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--half .cover__body .cover__cta {
                    margin-bottom:20px
                }
            }

            .cover-layout--half .cover__body .cover__phone {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--half .cover__body .cover__phone {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--half .cover__body .cover__phone {
                    margin-bottom:20px
                }
            }

            .cover-layout--half .cover__body .cover__social {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--half .cover__body .cover__social {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--half .cover__body .cover__social {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 480px) {
                .cover-layout--half .cover__body .cover__content-inner {
                    -ms-grid-columns:minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) 1fr;
                    -ms-grid-columns: minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto) 1fr;
                    grid-template-columns: minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) 1fr;
                    grid-template-columns: minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto) 1fr
                }

                .cover-layout--half .cover__body .cover__logo {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 2;
                    grid-column: 1 / 3;
                    -ms-grid-row: 1;
                    grid-row: 1
                }

                .cover-layout--half .cover__body .cover__title {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 2;
                    grid-column: 1 / 3;
                    -ms-grid-row: 2;
                    grid-row: 2
                }

                .cover-layout--half .cover__body .cover__subtitle {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 2;
                    grid-column: 1 / 3;
                    -ms-grid-row: 3;
                    grid-row: 3
                }

                .cover-layout--half .cover__body .cover__cta {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 2;
                    grid-column: 1 / 3;
                    -ms-grid-row: 4;
                    grid-row: 4
                }

                .cover-layout--half .cover__body .cover__phone {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 1;
                    grid-column: 1 / 2;
                    -ms-grid-row: 5;
                    grid-row: 5;
                    -ms-grid-row-align: center;
                    align-self: center;
                    -ms-grid-column-align: end;
                    justify-self: end
                }

                .cover-layout--half .cover__body .cover__social {
                    -ms-grid-column: 2;
                    -ms-grid-column-span: 1;
                    grid-column: 2 / 3;
                    -ms-grid-row: 5;
                    grid-row: 5;
                    -ms-grid-row-align: center;
                    align-self: center;
                    -ms-grid-column-align: start;
                    justify-self: start
                }

                .cover-layout--half.cover-phone--hide .cover__body .cover__social,.cover-layout--half.cover-phone--show-in-header .cover__body .cover__social {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 2;
                    grid-column: 1 / 3;
                    -ms-grid-column-align: center;
                    justify-self: center
                }

                .cover-layout--half.cover-social--hide .cover__body .cover__phone,.cover-layout--half.cover-social--show-in-header .cover__body .cover__phone {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 2;
                    grid-column: 1 / 3;
                    -ms-grid-column-align: center;
                    justify-self: center
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) {
                .cover-layout--half.cover-phone--show-on-cover.cover-social--show-on-cover .cover__body .cover__content-inner {
                    grid-template-columns:minmax(50%, auto) minmax(50%, auto) minmax(min-content, auto) 1fr
                }

                .cover-layout--half.cover-phone--show-on-cover.cover-social--show-on-cover .cover__body .cover__phone {
                    margin-right: 10px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) and (min-width: 480px) {
                .cover-layout--half.cover-phone--show-on-cover.cover-social--show-on-cover .cover__body .cover__phone {
                    margin-right:8px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) and (min-width: 1024px) {
                .cover-layout--half.cover-phone--show-on-cover.cover-social--show-on-cover .cover__body .cover__phone {
                    margin-right:10px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) {
                .cover-layout--half.cover-phone--show-on-cover.cover-social--show-on-cover .cover__body .cover__social {
                    margin-left:10px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) and (min-width: 480px) {
                .cover-layout--half.cover-phone--show-on-cover.cover-social--show-on-cover .cover__body .cover__social {
                    margin-left:8px
                }
            }

            @media screen and (min-width: 480px) and (min-width: 480px) and (min-width: 1024px) {
                .cover-layout--half.cover-phone--show-on-cover.cover-social--show-on-cover .cover__body .cover__social {
                    margin-left:10px
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--half.cover-title-size--xxxs .cover-title {
                    font-size:3vw
                }

                .cover-layout--half.cover-title-size--xxxs .cover-title--long {
                    font-size: 2.1vw
                }

                .cover-layout--half.cover-title-size--xxs .cover-title {
                    font-size: 3.5vw
                }

                .cover-layout--half.cover-title-size--xxs .cover-title--long {
                    font-size: 2.45vw
                }

                .cover-layout--half.cover-title-size--xs .cover-title {
                    font-size: 4vw
                }

                .cover-layout--half.cover-title-size--xs .cover-title--long {
                    font-size: 2.8vw
                }

                .cover-layout--half.cover-title-size--s .cover-title {
                    font-size: 4.5vw
                }

                .cover-layout--half.cover-title-size--s .cover-title--long {
                    font-size: 3.15vw
                }

                .cover-layout--half.cover-title-size--m .cover-title {
                    font-size: 5vw
                }

                .cover-layout--half.cover-title-size--m .cover-title--long {
                    font-size: 3.5vw
                }

                .cover-layout--half.cover-title-size--l .cover-title {
                    font-size: 5.5vw
                }

                .cover-layout--half.cover-title-size--l .cover-title--long {
                    font-size: 3.85vw
                }

                .cover-layout--half.cover-title-size--xl .cover-title {
                    font-size: 6vw
                }

                .cover-layout--half.cover-title-size--xl .cover-title--long {
                    font-size: 4.2vw
                }

                .cover-layout--half.cover-title-size--xxl .cover-title {
                    font-size: 6.5vw
                }

                .cover-layout--half.cover-title-size--xxl .cover-title--long {
                    font-size: 4.55vw
                }

                .cover-layout--half.cover-title-size--xxxl .cover-title {
                    font-size: 7vw
                }

                .cover-layout--half.cover-title-size--xxxl .cover-title--long {
                    font-size: 4.9vw
                }

                .cover-layout--half.cover-title-size--xxxxl .cover-title {
                    font-size: 7.5vw
                }

                .cover-layout--half.cover-title-size--xxxxl .cover-title--long {
                    font-size: 5.25vw
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--half .cover__content-inner {
                    max-width:60%
                }

                .cover-layout--half.cover-title-size--xxxs .cover-title {
                    font-size: 2.4vw
                }

                .cover-layout--half.cover-title-size--xxxs .cover-title--long {
                    font-size: 1.8vw
                }

                .cover-layout--half.cover-title-size--xxs .cover-title {
                    font-size: 2.8vw
                }

                .cover-layout--half.cover-title-size--xxs .cover-title--long {
                    font-size: 2.1vw
                }

                .cover-layout--half.cover-title-size--xs .cover-title {
                    font-size: 3.2vw
                }

                .cover-layout--half.cover-title-size--xs .cover-title--long {
                    font-size: 2.4vw
                }

                .cover-layout--half.cover-title-size--s .cover-title {
                    font-size: 3.6vw
                }

                .cover-layout--half.cover-title-size--s .cover-title--long {
                    font-size: 2.7vw
                }

                .cover-layout--half.cover-title-size--m .cover-title {
                    font-size: 4vw
                }

                .cover-layout--half.cover-title-size--m .cover-title--long {
                    font-size: 3vw
                }

                .cover-layout--half.cover-title-size--l .cover-title {
                    font-size: 4.4vw
                }

                .cover-layout--half.cover-title-size--l .cover-title--long {
                    font-size: 3.3vw
                }

                .cover-layout--half.cover-title-size--xl .cover-title {
                    font-size: 4.8vw
                }

                .cover-layout--half.cover-title-size--xl .cover-title--long {
                    font-size: 3.6vw
                }

                .cover-layout--half.cover-title-size--xxl .cover-title {
                    font-size: 5.2vw
                }

                .cover-layout--half.cover-title-size--xxl .cover-title--long {
                    font-size: 3.9vw
                }

                .cover-layout--half.cover-title-size--xxxl .cover-title {
                    font-size: 5.6vw
                }

                .cover-layout--half.cover-title-size--xxxl .cover-title--long {
                    font-size: 4.2vw
                }

                .cover-layout--half.cover-title-size--xxxxl .cover-title {
                    font-size: 6vw
                }

                .cover-layout--half.cover-title-size--xxxxl .cover-title--long {
                    font-size: 4.5vw
                }
            }

            @media screen and (min-width: 480px) {
                .cover-layout--half.cover-align--left .cover__phone {
                    -ms-grid-column-align:start;
                    justify-self: start
                }

                .cover-layout--half.cover-align--left .cover__content-inner {
                    -ms-grid-columns: minmax(-webkit-min-content, auto) 1fr;
                    -ms-grid-columns: minmax(min-content, auto) 1fr;
                    grid-template-columns: minmax(-webkit-min-content, auto) 1fr;
                    grid-template-columns: minmax(min-content, auto) 1fr
                }
            }

            .cover-layout--top.cover-title-size--xxxs .cover-title {
                font-size: 4.2vw
            }

            .cover-layout--top.cover-title-size--xxxs .cover-title--long {
                font-size: 3vw
            }

            .cover-layout--top.cover-title-size--xxs .cover-title {
                font-size: 4.9vw
            }

            .cover-layout--top.cover-title-size--xxs .cover-title--long {
                font-size: 3.5vw
            }

            .cover-layout--top.cover-title-size--xs .cover-title {
                font-size: 5.6vw
            }

            .cover-layout--top.cover-title-size--xs .cover-title--long {
                font-size: 4vw
            }

            .cover-layout--top.cover-title-size--s .cover-title {
                font-size: 6.3vw
            }

            .cover-layout--top.cover-title-size--s .cover-title--long {
                font-size: 4.5vw
            }

            .cover-layout--top.cover-title-size--m .cover-title {
                font-size: 7vw
            }

            .cover-layout--top.cover-title-size--m .cover-title--long {
                font-size: 5vw
            }

            .cover-layout--top.cover-title-size--l .cover-title {
                font-size: 7.7vw
            }

            .cover-layout--top.cover-title-size--l .cover-title--long {
                font-size: 5.5vw
            }

            .cover-layout--top.cover-title-size--xl .cover-title {
                font-size: 8.4vw
            }

            .cover-layout--top.cover-title-size--xl .cover-title--long {
                font-size: 6vw
            }

            .cover-layout--top.cover-title-size--xxl .cover-title {
                font-size: 9.1vw
            }

            .cover-layout--top.cover-title-size--xxl .cover-title--long {
                font-size: 6.5vw
            }

            .cover-layout--top.cover-title-size--xxxl .cover-title {
                font-size: 9.8vw
            }

            .cover-layout--top.cover-title-size--xxxl .cover-title--long {
                font-size: 7vw
            }

            .cover-layout--top.cover-title-size--xxxxl .cover-title {
                font-size: 10.5vw
            }

            .cover-layout--top.cover-title-size--xxxxl .cover-title--long {
                font-size: 7.5vw
            }

            .cover-layout--top .cover__body .cover__logo {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--top .cover__body .cover__logo {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top .cover__body .cover__logo {
                    margin-bottom:20px
                }
            }

            .cover-layout--top .cover__body .cover__title {
                margin-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--top .cover__body .cover__title {
                    margin-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top .cover__body .cover__title {
                    margin-bottom:10px
                }
            }

            .cover-layout--top .cover__body .cover__subtitle {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--top .cover__body .cover__subtitle {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top .cover__body .cover__subtitle {
                    margin-bottom:20px
                }
            }

            .cover-layout--top .cover__body .cover__cta {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--top .cover__body .cover__cta {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top .cover__body .cover__cta {
                    margin-bottom:20px
                }
            }

            .cover-layout--top .cover__body .cover__phone {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--top .cover__body .cover__phone {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top .cover__body .cover__phone {
                    margin-bottom:20px
                }
            }

            .cover-layout--top .cover__body .cover__social {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--top .cover__body .cover__social {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top .cover__body .cover__social {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--top.cover-title-size--xxxs .cover-title {
                    font-size:2.4vw
                }

                .cover-layout--top.cover-title-size--xxxs .cover-title--long {
                    font-size: 1.8vw
                }

                .cover-layout--top.cover-title-size--xxs .cover-title {
                    font-size: 2.8vw
                }

                .cover-layout--top.cover-title-size--xxs .cover-title--long {
                    font-size: 2.1vw
                }

                .cover-layout--top.cover-title-size--xs .cover-title {
                    font-size: 3.2vw
                }

                .cover-layout--top.cover-title-size--xs .cover-title--long {
                    font-size: 2.4vw
                }

                .cover-layout--top.cover-title-size--s .cover-title {
                    font-size: 3.6vw
                }

                .cover-layout--top.cover-title-size--s .cover-title--long {
                    font-size: 2.7vw
                }

                .cover-layout--top.cover-title-size--m .cover-title {
                    font-size: 4vw
                }

                .cover-layout--top.cover-title-size--m .cover-title--long {
                    font-size: 3vw
                }

                .cover-layout--top.cover-title-size--l .cover-title {
                    font-size: 4.4vw
                }

                .cover-layout--top.cover-title-size--l .cover-title--long {
                    font-size: 3.3vw
                }

                .cover-layout--top.cover-title-size--xl .cover-title {
                    font-size: 4.8vw
                }

                .cover-layout--top.cover-title-size--xl .cover-title--long {
                    font-size: 3.6vw
                }

                .cover-layout--top.cover-title-size--xxl .cover-title {
                    font-size: 5.2vw
                }

                .cover-layout--top.cover-title-size--xxl .cover-title--long {
                    font-size: 3.9vw
                }

                .cover-layout--top.cover-title-size--xxxl .cover-title {
                    font-size: 5.6vw
                }

                .cover-layout--top.cover-title-size--xxxl .cover-title--long {
                    font-size: 4.2vw
                }

                .cover-layout--top.cover-title-size--xxxxl .cover-title {
                    font-size: 6vw
                }

                .cover-layout--top.cover-title-size--xxxxl .cover-title--long {
                    font-size: 4.5vw
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top .cover__content-inner {
                    max-width:60%
                }
            }

            .cover-layout--top .cover__content-inner {
                width: 100%;
                max-width: 80%
            }

            .cover-layout--top .jarallax-container,.cover-layout--top .jarallax-container>div,.cover-layout--top .cover__slider .slide,.cover-layout--top .cover__overlay,.cover-layout--top .cover__image {
                max-height: 50vh
            }

            .cover-layout--top .cover__content {
                place-content: start;
                -ms-grid-rows: minmax(50vh, 1fr)
            }

            .cover-layout--top .cover__body {
                margin-top: calc(50vh - 131px)
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top .cover__body {
                    margin-top:calc(50vh - 151px)
                }
            }

            .cover-layout--top.cover-logo_position--show-on-top .cover__body {
                margin-top: calc(50vh - 80px)
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--top.cover-logo_position--show-on-top .cover__body {
                    margin-top:calc(50vh - 100px)
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-layout--top.cover-align--left .cover__content-inner {
                    -ms-grid-columns:minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) 1fr;
                    -ms-grid-columns: minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto) 1fr;
                    grid-template-columns: minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) minmax(-webkit-min-content, auto) 1fr;
                    grid-template-columns: minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto) 1fr
                }

                .cover-layout--top.cover-align--left .cover__logo {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 4;
                    grid-column: 1 / 5;
                    -ms-grid-row: 1;
                    grid-row: 1
                }

                .cover-layout--top.cover-align--left .cover__title {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 4;
                    grid-column: 1 / 5;
                    -ms-grid-row: 2;
                    grid-row: 2
                }

                .cover-layout--top.cover-align--left .cover__subtitle {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 4;
                    grid-column: 1 / 5;
                    -ms-grid-row: 3;
                    grid-row: 3
                }

                .cover-layout--top.cover-align--left .cover__cta {
                    -ms-grid-column: 1;
                    -ms-grid-column-span: 1;
                    grid-column: 1 / 2;
                    -ms-grid-row: 4;
                    grid-row: 4;
                    margin-right: 30px
                }
            }

            @media screen and (min-width: 1100px) and (min-width: 480px) {
                .cover-layout--top.cover-align--left .cover__cta {
                    margin-right:24px
                }
            }

            @media screen and (min-width: 1100px) and (min-width: 1024px) {
                .cover-layout--top.cover-align--left .cover__cta {
                    margin-right:30px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-layout--top.cover-align--left .cover__phone {
                    -ms-grid-column:2;
                    -ms-grid-column-span: 1;
                    grid-column: 2 / 3;
                    -ms-grid-row: 4;
                    grid-row: 4;
                    -ms-grid-row-align: center;
                    align-self: center;
                    -ms-grid-column-align: start;
                    justify-self: start;
                    margin-right: 30px
                }
            }

            @media screen and (min-width: 1100px) and (min-width: 480px) {
                .cover-layout--top.cover-align--left .cover__phone {
                    margin-right:24px
                }
            }

            @media screen and (min-width: 1100px) and (min-width: 1024px) {
                .cover-layout--top.cover-align--left .cover__phone {
                    margin-right:30px
                }
            }

            @media screen and (min-width: 1100px) {
                .cover-layout--top.cover-align--left .cover__social {
                    -ms-grid-column:3;
                    -ms-grid-column-span: 1;
                    grid-column: 3 / 4;
                    -ms-grid-row: 4;
                    grid-row: 4;
                    -ms-grid-row-align: center;
                    align-self: center;
                    -ms-grid-column-align: start;
                    justify-self: start
                }
            }

            .cover-layout--top.cover-logo--hide .cover__body,.cover-layout--top.cover-logo-position--hide .cover__body,.cover-layout--top.cover-logo-position--show-below-cover .cover__body {
                margin-top: calc(50vh - 60px)
            }

            .cover:not(.cover-layout--full) .jarallax-container>div,.cover:not(.cover-layout--full) .jarallax-container iframe {
                position: static !important;
                max-height: 100%
            }

            .cover-title--show-under-subtitle .cover__body .cover__title {
                -ms-grid-row: 3;
                grid-row: 3
            }

            .cover-title--show-under-subtitle .cover__body .cover__subtitle {
                -ms-grid-row: 2;
                grid-row: 2
            }

            .cover-title--show-under-subtitle.cover-layout--full .cover__title,.cover-title--show-under-subtitle.cover-layout--half .cover__title {
                margin-bottom: 40px
            }

            @media screen and (min-width: 480px) {
                .cover-title--show-under-subtitle.cover-layout--full .cover__title,.cover-title--show-under-subtitle.cover-layout--half .cover__title {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-title--show-under-subtitle.cover-layout--full .cover__title,.cover-title--show-under-subtitle.cover-layout--half .cover__title {
                    margin-bottom:40px
                }
            }

            .cover-title--show-under-subtitle.cover-layout--full .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--half .cover__subtitle {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-title--show-under-subtitle.cover-layout--full .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--half .cover__subtitle {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-title--show-under-subtitle.cover-layout--full .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--half .cover__subtitle {
                    margin-bottom:20px
                }
            }

            .cover-title--show-under-subtitle.cover-layout--top .cover__title {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-title--show-under-subtitle.cover-layout--top .cover__title {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-title--show-under-subtitle.cover-layout--top .cover__title {
                    margin-bottom:20px
                }
            }

            .cover-title--show-under-subtitle.cover-layout--top .cover__subtitle {
                margin-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .cover-title--show-under-subtitle.cover-layout--top .cover__subtitle {
                    margin-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-title--show-under-subtitle.cover-layout--top .cover__subtitle {
                    margin-bottom:10px
                }
            }

            .cover-title--show-under-subtitle.cover-layout--left .cover__title,.cover-title--show-under-subtitle.cover-layout--right .cover__title {
                margin-bottom: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__title,.cover-title--show-under-subtitle.cover-layout--right .cover__title {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__title,.cover-title--show-under-subtitle.cover-layout--right .cover__title {
                    margin-bottom:20px
                }
            }

            .cover-title--show-under-subtitle.cover-layout--left .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--right .cover__subtitle {
                margin-bottom: 10px
            }

            @media screen and (min-width: 480px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--right .cover__subtitle {
                    margin-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--right .cover__subtitle {
                    margin-bottom:10px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__title,.cover-title--show-under-subtitle.cover-layout--right .cover__title {
                    margin-bottom:40px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 480px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__title,.cover-title--show-under-subtitle.cover-layout--right .cover__title {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 1024px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__title,.cover-title--show-under-subtitle.cover-layout--right .cover__title {
                    margin-bottom:40px
                }
            }

            @media screen and (min-width: 1920px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--right .cover__subtitle {
                    margin-bottom:20px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 480px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--right .cover__subtitle {
                    margin-bottom:16px
                }
            }

            @media screen and (min-width: 1920px) and (min-width: 1024px) {
                .cover-title--show-under-subtitle.cover-layout--left .cover__subtitle,.cover-title--show-under-subtitle.cover-layout--right .cover__subtitle {
                    margin-bottom:20px
                }
            }

            .cover__menu,.cover__phone,.cover__directions,.cover__hours,.cover__social,.cover__cart {
                display: none;
                margin: 0
            }

            .header {
                display: flex;
                flex-flow: row nowrap;
                align-items: center;
                justify-content: space-between;
                width: 100%;
                min-height: 23px;
                margin: 0;
                padding: 0;
                list-style-type: none;
                opacity: 0
            }

            .header .cover__title {
                margin: 0
            }

            @media screen and (min-width: 768px) {
                .header .cover__title {
                    width:auto
                }
            }

            .header.cover-title-size--xxxs .cover-title {
                font-size: 3vw
            }

            .header.cover-title-size--xxxs .cover-title--long {
                font-size: 2.1vw
            }

            .header.cover-title-size--xxs .cover-title {
                font-size: 3.5vw
            }

            .header.cover-title-size--xxs .cover-title--long {
                font-size: 2.45vw
            }

            .header.cover-title-size--xs .cover-title {
                font-size: 4vw
            }

            .header.cover-title-size--xs .cover-title--long {
                font-size: 2.8vw
            }

            .header.cover-title-size--s .cover-title {
                font-size: 4.5vw
            }

            .header.cover-title-size--s .cover-title--long {
                font-size: 3.15vw
            }

            .header.cover-title-size--m .cover-title {
                font-size: 5vw
            }

            .header.cover-title-size--m .cover-title--long {
                font-size: 3.5vw
            }

            .header.cover-title-size--l .cover-title {
                font-size: 5.5vw
            }

            .header.cover-title-size--l .cover-title--long {
                font-size: 3.85vw
            }

            .header.cover-title-size--xl .cover-title {
                font-size: 6vw
            }

            .header.cover-title-size--xl .cover-title--long {
                font-size: 4.2vw
            }

            .header.cover-title-size--xxl .cover-title {
                font-size: 6.5vw
            }

            .header.cover-title-size--xxl .cover-title--long {
                font-size: 4.55vw
            }

            .header.cover-title-size--xxxl .cover-title {
                font-size: 7vw
            }

            .header.cover-title-size--xxxl .cover-title--long {
                font-size: 4.9vw
            }

            .header.cover-title-size--xxxxl .cover-title {
                font-size: 7.5vw
            }

            .header.cover-title-size--xxxxl .cover-title--long {
                font-size: 5.25vw
            }

            @media screen and (min-width: 768px) {
                .header.cover-title-size--xxxs .cover-title {
                    font-size:1.5vw
                }

                .header.cover-title-size--xxxs .cover-title--long {
                    font-size: 1.2vw
                }

                .header.cover-title-size--xxs .cover-title {
                    font-size: 1.75vw
                }

                .header.cover-title-size--xxs .cover-title--long {
                    font-size: 1.4vw
                }

                .header.cover-title-size--xs .cover-title {
                    font-size: 2vw
                }

                .header.cover-title-size--xs .cover-title--long {
                    font-size: 1.6vw
                }

                .header.cover-title-size--s .cover-title {
                    font-size: 2.25vw
                }

                .header.cover-title-size--s .cover-title--long {
                    font-size: 1.8vw
                }

                .header.cover-title-size--m .cover-title {
                    font-size: 2.5vw
                }

                .header.cover-title-size--m .cover-title--long {
                    font-size: 2vw
                }

                .header.cover-title-size--l .cover-title {
                    font-size: 2.75vw
                }

                .header.cover-title-size--l .cover-title--long {
                    font-size: 2.2vw
                }

                .header.cover-title-size--xl .cover-title {
                    font-size: 3vw
                }

                .header.cover-title-size--xl .cover-title--long {
                    font-size: 2.4vw
                }

                .header.cover-title-size--xxl .cover-title {
                    font-size: 3.25vw
                }

                .header.cover-title-size--xxl .cover-title--long {
                    font-size: 2.6vw
                }

                .header.cover-title-size--xxxl .cover-title {
                    font-size: 3.5vw
                }

                .header.cover-title-size--xxxl .cover-title--long {
                    font-size: 2.8vw
                }

                .header.cover-title-size--xxxxl .cover-title {
                    font-size: 3.75vw
                }

                .header.cover-title-size--xxxxl .cover-title--long {
                    font-size: 3vw
                }
            }

            .header .cover__menu {
                flex-grow: 1
            }

            .header .cover__phone,.header .cover__directions,.header .cover__hours {
                font-size: 16px;
                line-height: 22px;
                text-align: right;
                white-space: nowrap
            }

            .header .cover__phone .text,.header .cover__directions .text,.header .cover__hours .text {
                display: inline-block;
                font-weight: 600;
                vertical-align: middle
            }

            .header .cover__directions .text,.header .cover__hours .text {
                padding-left: 2px
            }

            .header .cover__phone {
                order: 1
            }

            .header .cover__directions {
                order: 2
            }

            .header .cover__hours {
                order: 3
            }

            .header .cover__social {
                order: 4
            }

            .header .cover__cart {
                order: 5;
                min-width: 28px;
                height: 22px;
                margin-right: -9px
            }

            .header .cover__cart .ec-cart-widget {
                margin-top: -5px
            }

            .header .svg-icon {
                display: inline-block;
                width: 16px;
                height: 16px;
                text-align: center;
                line-height: 1
            }

            .header .svg-icon svg {
                width: 100%;
                height: 100%
            }

            .header--show {
                opacity: 1
            }

            .header--hide-menu .cover__menu .content {
                display: none
            }

            .header--hide-phone .cover__phone .content {
                display: none
            }

            .header--hide-directions .cover__phone .content {
                display: none
            }

            .header--hide-hours .cover__phone .content {
                display: none
            }

            .header--hide-social .cover__social .content {
                display: none
            }

            .header--hide-cart .cover__phone .content {
                display: none
            }

            .header--hide-icon-text .svg-icon+.text {
                display: none
            }

            .header__item {
                display: flex;
                align-items: center;
                line-height: 22px;
                box-sizing: border-box;
                opacity: 1;
                transition: opacity .1s ease-in-out 0s
            }

            .header__item:first-child {
                display: none;
                flex-basis: 80%;
                order: 1
            }

            @media screen and (min-width: 480px) {
                .header__item:first-child {
                    flex-basis:40%
                }
            }

            .header__item:nth-child(2) {
                order: 2
            }

            @media screen and (min-width: 1024px) {
                .header__item:nth-child(2) {
                    flex-basis:30%
                }
            }

            .header__item:last-child {
                order: 3;
                justify-content: flex-end
            }

            .cover-layout--menu .header__item:first-child,.cover-logo_position--show-on-top .header__item:first-child {
                display: flex
            }

            .cover-logo--hide:not(.cover-layout--menu) .header__item:first-child,.cover-logo-position--hide:not(.cover-layout--menu) .header__item:first-child {
                display: none
            }

            .cover-logo_position--show-on-top .cover__body .cover__logo {
                display: none
            }

            .cover-logo_position--show-on-top .cover__header .cover__logo {
                display: block;
                margin-right: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-logo_position--show-on-top .cover__header .cover__logo {
                    margin-right:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-logo_position--show-on-top .cover__header .cover__logo {
                    margin-right:20px
                }
            }

            .cover:not(.cover-layout--menu) .cover__header {
                margin-bottom: 40px
            }

            @media screen and (min-width: 480px) {
                .cover:not(.cover-layout--menu) .cover__header {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover:not(.cover-layout--menu) .cover__header {
                    margin-bottom:40px
                }
            }

            .cover:not(.cover-layout--menu) .cover__header .cover__title {
                display: none
            }

            .cover:not(.cover-layout--menu):not(.cover-layout--left):not(.cover-layout--right) .header__item:nth-child(2) {
                flex-basis: auto
            }

            .cover-layout--left .header__item:first-child,.cover-layout--right .header__item:first-child {
                display: none
            }

            .cover-layout--left .header__item:nth-child(2),.cover-layout--right .header__item:nth-child(2) {
                flex-basis: 100%
            }

            .cover-store-hours--show .cover__hours {
                display: inline-block
            }

            .cover-layout--menu .cover__body,.cover-layout--menu .cover__footer {
                display: none
            }

            .cover-layout--menu .cover__container {
                border-bottom: 1px solid #E6E6E6;
                padding-top: 10px;
                padding-right: 20px;
                padding-bottom: 10px;
                padding-left: 20px
            }

            @media screen and (min-width: 480px) {
                .cover-layout--menu .cover__container {
                    padding-top:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--menu .cover__container {
                    padding-top:10px
                }
            }

            @media screen and (min-width: 480px) {
                .cover-layout--menu .cover__container {
                    padding-right:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--menu .cover__container {
                    padding-right:20px
                }
            }

            @media screen and (min-width: 480px) {
                .cover-layout--menu .cover__container {
                    padding-bottom:8px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--menu .cover__container {
                    padding-bottom:10px
                }
            }

            @media screen and (min-width: 480px) {
                .cover-layout--menu .cover__container {
                    padding-left:16px
                }
            }

            @media screen and (min-width: 1024px) {
                .cover-layout--menu .cover__container {
                    padding-left:20px
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--menu:not(.cover-menu--hide) .cover__menu {
                    display:block;
                    flex-grow: 3;
                    order: 3
                }

                .cover-layout--menu:not(.cover-menu--hide) .cover__menu .main-nav li {
                    line-height: 22px
                }
            }

            .cover-layout--menu.cover-title--hide .cover__header {
                grid-auto-columns: -webkit-min-content minmax(-webkit-min-content, 60vw) minmax(-webkit-min-content, 1fr) -webkit-min-content -webkit-min-content -webkit-min-content -webkit-min-content;
                grid-auto-columns: min-content minmax(min-content, 60vw) minmax(min-content, 1fr) min-content min-content min-content min-content
            }

            .cover-layout--menu.cover-title--hide .cover__header .cover__title {
                display: none
            }

            .cover-layout--menu.cover-menu--hide .cover__header {
                grid-auto-columns: -webkit-min-content minmax(-webkit-min-content, 60vw) minmax(-webkit-min-content, 1fr) -webkit-min-content -webkit-min-content -webkit-min-content -webkit-min-content;
                grid-auto-columns: min-content minmax(min-content, 60vw) minmax(min-content, 1fr) min-content min-content min-content min-content
            }

            .cover-layout--menu.cover-align--center .header__item:first-child {
                order: 2;
                justify-content: center;
                text-align: center
            }

            .cover-layout--menu.cover-align--center .header__item:nth-child(2) {
                order: 1
            }

            .cover-layout--menu.cover-align--left .header__item {
                flex-basis: calc(100% / 3)
            }

            .cover-layout--menu.cover-logo--show .cover__title,.cover-layout--menu.cover-logo--circle .cover__title {
                display: none
            }

            .cover-layout--menu .cover__logo.hidden+.cover__title {
                display: block
            }

            .cover-layout--menu.cover-logo-position--hide .cover__title {
                display: block
            }

            .shadow:not(button) {
                text-shadow: 0 1px 1px rgba(0,0,0,0.2)
            }

            .shadow .svg-icon,.shadow .icon-default {
                filter: drop-shadow(0 1px 1px rgba(0,0,0,0.2))
            }

            .shadow.cover__header {
                text-shadow: 0 1px 1px rgba(0,0,0,0.3)
            }

            .shadow.cover__header .svg-icon,.shadow.cover__header .ec-minicart__icon {
                filter: drop-shadow(0 1px 1px rgba(0,0,0,0.3))
            }

            button.shadow {
                filter: drop-shadow(0 1px 1px rgba(0,0,0,0.2))
            }

            .pickr {
                z-index: 10000;
                width: 12px
            }

            .tiles {
                background-color: #fff
            }

            .tiles .caption * {
                box-sizing: border-box
            }

            .tiles.cover-logo-position--show-on-cover .caption,.tiles.cover-logo-position--hide .caption {
                display: none
            }

            .tiles.cover-logo-position--show-below-cover .caption,.tiles.cover-logo-position--show-on-and-below-cover .caption {
                display: block
            }

            .tiles.cover-logo-position--show-below-cover .cover__logo {
                margin: 0 !important
            }

            .tiles.cover-logo-position--show-below-cover .cover__logo .content {
                display: none
            }

            .tiles:not(.cover-layout--menu) .tile-cover .logo,.tiles:not(.cover-layout--menu) .tile-store .logo {
                position: relative;
                max-width: 212px;
                max-height: 112px;
                border-radius: 4px;
                color: transparent
            }

            @media screen and (min-width: 1100px) {
                .tiles:not(.cover-layout--menu) .tile-cover .logo,.tiles:not(.cover-layout--menu) .tile-store .logo {
                    max-width:252px;
                    max-height: 132px
                }
            }

            @media screen and (min-width: 1920px) {
                .tiles:not(.cover-layout--menu) .tile-cover .logo,.tiles:not(.cover-layout--menu) .tile-store .logo {
                    max-width:292px;
                    max-height: 152px
                }
            }

            .tiles:not(.cover-layout--menu) .tile-cover .logo img,.tiles:not(.cover-layout--menu) .tile-store .logo img {
                width: auto;
                height: auto;
                max-width: 212px;
                max-height: 112px;
                margin: auto;
                background-color: currentColor;
                border: 6px solid currentColor;
                border-radius: 4px
            }

            @media screen and (min-width: 1100px) {
                .tiles:not(.cover-layout--menu) .tile-cover .logo img,.tiles:not(.cover-layout--menu) .tile-store .logo img {
                    max-width:252px;
                    max-height: 132px
                }
            }

            @media screen and (min-width: 1920px) {
                .tiles:not(.cover-layout--menu) .tile-cover .logo img,.tiles:not(.cover-layout--menu) .tile-store .logo img {
                    max-width:292px;
                    max-height: 152px
                }
            }

            .tiles.cover-logo--circle .tile-cover .logo,.tiles.cover-logo--circle .tile-store .logo {
                width: 112px;
                height: 112px;
                border: 6px solid currentColor;
                border-radius: 50%;
                background-color: currentColor;
                background-repeat: no-repeat;
                background-position: center center
            }

            @media screen and (min-width: 1100px) {
                .tiles.cover-logo--circle .tile-cover .logo,.tiles.cover-logo--circle .tile-store .logo {
                    width:132px;
                    height: 132px
                }
            }

            @media screen and (min-width: 1920px) {
                .tiles.cover-logo--circle .tile-cover .logo,.tiles.cover-logo--circle .tile-store .logo {
                    width:152px;
                    height: 152px
                }
            }

            .tiles.cover-logo--circle .tile-cover .logo img,.tiles.cover-logo--circle .tile-store .logo img {
                display: none
            }

            .tiles.cover-layout--menu .tile-cover .logo,.tiles.cover-layout--menu .tile-cover .logo {
                display: flex;
                justify-content: center;
                align-items: center;
                min-width: 212px;
                min-height: 62px;
                max-width: 480px;
                margin: 0 auto;
                color: transparent;
                transition: color .1s ease-out 0s
            }

            .tiles.cover-layout--menu .tile-cover .logo img,.tiles.cover-layout--menu .tile-cover .logo img {
                display: block;
                max-width: 100%;
                height: auto;
                max-height: 75px;
                border: 6px solid currentColor;
                border-radius: 4px;
                background-color: currentColor;
                background-size: 0;
                box-sizing: content-box
            }

            .tiles.cover-layout--menu.cover-logo--circle .tile-cover .logo,.tiles.cover-layout--menu.cover-logo--circle .tile-store .logo {
                width: 87px;
                height: 87px;
                min-width: auto;
                min-height: auto;
                border: 6px solid currentColor;
                border-radius: 50%;
                background-color: currentColor;
                background-repeat: no-repeat;
                background-position: center center
            }

            .tiles.cover-layout--menu.cover-logo--circle .tile-cover .logo img,.tiles.cover-layout--menu.cover-logo--circle .tile-store .logo img {
                display: none
            }

            .tiles:not(.cover-logo--circle) .tile-cover .logo,.tiles:not(.cover-logo--circle) .tile-store .logo {
                border: none !important;
                background: none !important
            }

            .tiles.cover-logo--hide .cover .cover__logo,.tiles.cover-logo-position--hide .cover .cover__logo {
                margin: 0 !important
            }

            .tiles.cover-logo--hide .cover .cover__logo .content,.tiles.cover-logo-position--hide .cover .cover__logo .content {
                display: none
            }

            .tiles.cover-logo--hide .caption,.tiles.cover-logo-position--hide .caption {
                display: none
            }

            .tiles.cover-align--left .tile-cover .logo,.tiles.cover-align--left .tile-store .logo {
                background-position: left center
            }

            .tiles.cover-align--left.cover-logo--circle .tile-cover .logo,.tiles.cover-align--left.cover-logo--circle .tile-store .logo {
                background-position: center
            }

            .tiles.cover-align--left.cover-layout--menu .cover .logo {
                justify-content: left
            }

            .tiles:not(.cover-logo--circle) .tile-cover .logo,.tiles:not(.cover-logo--circle) .tile-store .logo,.tiles:not(.cover-logo--circle) .tile-cover .logo,.tiles:not(.cover-logo--circle) .tile-store .logo {
                background-size: 0
            }

            .tiles.cover-logo--circle .tile-cover .logo,.tiles.cover-logo--circle .tile-store .logo {
                background-size: cover
            }

            .tiles.cover-logo--circle.cover-logo--homogeneity .tile-cover .logo,.tiles.cover-logo--circle.cover-logo--homogeneity .tile-store .logo {
                background-size: contain
            }

            .tiles.cover-logo--circle.cover-logo-border--transparent .tile-cover .logo,.tiles.cover-logo--circle.cover-logo-border--transparent .tile-store .logo {
                color: #fff
            }

            @media (min-width: 480px) {
                .tiles.cover-layout--full .tile-cover:not(:first-child) .cover__image div {
                    background-attachment:scroll
                }
            }

            .tiles .tile--last-visible .border {
                display: none
            }

            .tiles.cover-layout--menu .cover__header {
                margin-bottom: 0
            }

            .tiles.cover-layout--menu .cover__header .cover__title {
                display: block
            }

            .tiles.cover-layout--menu.cover-logo--show .cover__header .cover__title,.tiles.cover-layout--menu.cover-logo--circle .cover__header .cover__title {
                display: none
            }

            .tiles.cover-layout--menu .cover__logo.hidden+.cover__title {
                display: block
            }

            .tiles.cover-layout--menu.cover-logo-position--hide .cover__header .cover__title {
                display: block
            }

            .tiles:not(.cover-layout--menu) .cover__header {
                margin-bottom: 40px
            }

            @media screen and (min-width: 480px) {
                .tiles:not(.cover-layout--menu) .cover__header {
                    margin-bottom:32px
                }
            }

            @media screen and (min-width: 1024px) {
                .tiles:not(.cover-layout--menu) .cover__header {
                    margin-bottom:40px
                }
            }

            .tiles:not(.cover-layout--menu) .cover__header .cover__title {
                display: none
            }

            .tiles:not(.cover-layout--menu):not(.cover-layout--left):not(.cover-layout--right) .cover .header__item:nth-child(2) {
                flex-basis: auto
            }

            .tiles:not(.cover-layout--menu).cover-background--image.cover-menu--show .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--image.cover-phone--show-in-header .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--image.cover-store-hours--show .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--image.cover-get-directions--show .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--image.cover-cart--show .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--video.cover-menu--show .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--video.cover-phone--show-in-header .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--video.cover-store-hours--show .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--video.cover-get-directions--show .cover__overlay,.tiles:not(.cover-layout--menu).cover-background--video.cover-cart--show .cover__overlay {
                display: block
            }

            .tiles:not(.cover-layout--menu).cover-background--image.cover-menu--show .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--image.cover-phone--show-in-header .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--image.cover-store-hours--show .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--image.cover-get-directions--show .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--image.cover-cart--show .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--video.cover-menu--show .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--video.cover-phone--show-in-header .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--video.cover-store-hours--show .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--video.cover-get-directions--show .cover__overlay::before,.tiles:not(.cover-layout--menu).cover-background--video.cover-cart--show .cover__overlay::before {
                content: "";
                background: linear-gradient(to top, rgba(0,0,0,0), rgba(0,0,0,0.15));
                position: absolute;
                top: 0;
                width: 100%;
                height: 15%;
                z-index: 1
            }

            .cover__badge {
                --sidebar-height: 0px;
                position: absolute;
                z-index: 4;
                top: 0;
                bottom: 16px;
                left: 16px;
                pointer-events: none
            }

            .cover__badge a {
                display: block;
                position: sticky;
                top: calc(16px + var(--sidebar-height));
                pointer-events: auto
            }

            .cover__badge svg {
                display: block;
                width: 120px;
                height: auto
            }

            @media screen and (min-width: 768px) {
                .cover__badge svg {
                    width:auto
                }
            }

            .cover-menu--show .cover__badge a {
                top: 100%
            }

            @media screen and (max-width: 767px) {
                .cover-layout--right .cover__badge {
                    bottom:auto;
                    height: calc(50vh - 16px)
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--right .cover__badge {
                    right:16px;
                    left: auto
                }
            }

            @media screen and (min-width: 768px) {
                .cover-layout--right .cover__badge a {
                    top:100%
                }
            }

            @media screen and (max-width: 767px) {
                .cover-layout--left .cover__badge {
                    bottom:auto;
                    height: calc(50vh - 16px)
                }
            }

            .cover-layout--top .cover__badge {
                bottom: auto;
                height: calc(50vh - 16px)
            }

            .cover-layout--menu .cover__badge {
                position: fixed;
                top: auto;
                left: auto;
                margin-left: 16px
            }

            @media screen and (max-width: 767px) {
                .preview-mode .cover__badge {
                    --sidebar-height: 58px
                }
            }
        </style>
        <div class="body tiles-wrapper">
            <div class="pushmenu">
                <div class="container"></div>
            </div>
            <div class="float-icons hidden">
                <div class="float-icons__wrap">
                    <div class="float-icons__icon float-icons__icon--cart cart-icon off" aria-hidden="true">
                        <div class="ec-cart-widget" data-fixed-shape="PILL" data-show-empty-cart=false></div>
                        <div id="ecwid-cart"></div>
                    </div>
                    <div class="float-icons__icon float-icons__icon--search search-icon off">
                        <div class="ec-minicart ec-minicart--m ec-minicart--inline ec-minicart--pill ec-minicart--responsive">
                            <a href="/search" class="ec-minicart__icon" tabindex="-1" aria-label='Search products'>
                                <svg width="36" height="36" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg">
                                    <g stroke="currentColor" fill="none" fill-rule="evenodd">
                                        <path d="M21 25c5.523 0 10-4.477 10-10S26.523 5 21 5 11 9.477 11 15s4.477 10 10 10z" stroke-width="2"/>
                                        <path d="M13.514 22.486L5.5 30.5" stroke-width="3" stroke-linecap="round"/>
                                    </g>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tiles  cover-layout--left cover-position--center cover-align--center cover-phone--show-in-header cover-social--show-on-cover cover-logo--show cover-logo-position--show-on-cover cover-logo--homogeneity cover-title-size--s cover-subtitle-size--xxxxl cover-button-size--m cover-title--show cover-title--show-under-subtitle cover-background--image cover-overlay--color cover-menu--show cover-store-hours--hide cover-get-directions--hide cover-arrow--show cover-cart--hide">
                <div class="tile tile-cover">
                    <div class="cover">
                        <div class="cover__background parallax-container" data-img-src="https://d2j6dbq0eux0bg.cloudfront.net/startersite/images/83623760/1673498389228.jpg" style=" background-color: rgba(255, 255, 255, 1.0); ">
                            <div class="cover__image">
                                <div class="mobileThumbnail" style="background-image: url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD//gAKLXZlcmJvc2X/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCABpAIwDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAQGAQMFAgcI/8QAQhAAAQQBAQMHBgsGBwAAAAAAAgABAwQFEgYRIhMhMTJBQmIHFCNRUtIVM1VxgYKSlKKxwiRyc6Gy4jRDU2GDkZP/xAAZAQEBAQEBAQAAAAAAAAAAAAAABAIBAwX/xAArEQACAQIEBAUFAQAAAAAAAAAAAgMBBBESIjETFCFCIzIzQVJRYWKhsdH/2gAMAwEAAhEDEQA/AP2WiIgCIiAIiIAiLXJJHGOozER9bkgNiKCWWxgvpLIVP/YVtgt1p/ibUMn8OQSTKCSiIgCIiAIiIAiIgCIiAIiIDHYo121Xp1ynsyDHGPed16uWoqtU7ExMMYDvJ1SgG7tPkyIiKGpG/M3sN7y94Lfiam6LQnmmyaV3JFraLI353rYaAh8WnUXuivMGyl+4TzZO+7E/d67q2Y6jVoQNDViGMfzUl2d+hba4VekVMDUcbd1SrDsVj9PFZsv82n3VGsbEs3FVvGxd3WH6hV0ZYXhxGKVkZdiglNtLs+7vLqnrN7Raw+11hViwG0FTKg4N6KwPWiJ/y9a7RixNpJmdlTNqNnCgcslidQEHE8QdniFYqVxtDcaX0t9S6t0c6buZVzY7Ojk65QzOLWYmbW3tN7SsaUriSSwtE2RjKIiGAiIgCIiAIi8v0ICnbaWzt34sVXdn5x1t6yLqqy4mjFRoBWibhHpf2n9aquyrefbS2b0jdGox+s+4fwq7M/S3qVtz4arFT2IrXxGaUym9lonGUoTGGQQkduEnbezLn+b535Qp/dS95Rl6rRvc66LkebZ35Sp/dX95PNs78pU/ur+8s4m+Gvzp+/8ADr9Kdig0AvxuTXLMMzdmiLR+p1PXTzquFT53tDXPZ/aOLJVB3QylvcR/EKvlWaOeuE0ZagJmIX9a4m3NUbGz8x7m1QaTZ/6v5b158ns7zbPjGXWhkcH/AD/UsLprlPozeParL3LpLKiItnzQiIgCIiALRc5qku72CW9eDHeBM/aiHK7FR8nG79tft9Hv/EoL5jKYvafP37M0tnCQTxRWYXbUVIeQjLlh8PFxj9YeqWqRsM/m2Zt05OF3Hd9YSVtjq1hOaQIYxKctUzs3X4dPF9G5WX/rtUlsfSofMaWWyEt7BwXcjZjwtvBY+S5bCUnLlieTSJP/AJYyd6TwiPDq1L6LUyLz5OxQ8wvxNA3x8kOmE/3S38ST4/GjTnB8dBJEVfzeSIYRdjhHV6PT2jxFw+JeQykQCwjSvCI8P+GJSKla7FLMq7nE8oNKWcatv0lqvSGWaxQisFDJKGn4yMhIfSR93Vw8XdLSTQvhbMTZDNyYeGG7TapXkhkmulFp1QkXCPJl4SXayzYnLCA5LCz2hDq8rSItPrW8LdMTlJsXaYpWZpC80LjYfWu8NzPEQquzsIbRZEKudsWZBr4qnLXqvMQDNygcdgtJekLUOni6unxKLYe8T/A9SSxkqVbaEa8QnkCjIo/NSkKF5R4i5OT2vZ091XCTHYbMRxQWcRvGsGmHloNHJj1dwv2dC6NbG4+rXggr0a8UNYtUABGIjEXF1W7OsX2lytMDStmODjaF/H7G3q+TneQyacwDlil5KMtTjHyhcRafaJavJjvelc3/AOq39LLrbaWBr7OWn385joH6VD8nMHJ4M5XH42UiH5ur+lefefUj02L/AJMWhERbPmhERAEREAREQFG2jCTFbQw5OIfRyFv+nvCrjUsRWawTxPqjMd7Oo+ax8eSonWPhfdvAvZJVTA5OXB25MdkGdodX2PF+6r8vMw9PMv8ACDNy8vXysXtlEvzSVqsksYxbwbV6QtIiPa7upEUgSRsYEJCXQ7dq13K1e5XKvahjmhLrAY6hdQF+5wYc/bkcnKlDCOkt7TT6eTIREi1cPV0l+HxKVjsrYlvw1Z6bQcvW5YeItQuOnUJcPW4lJkw+LkeTlKEEmsRAtQatQtp90fsrfXoU68pTQ1oo5CHS5CPO7ICXzMyxv5nRVzavaCPGQnXrkJWyH7HiJdNRxtI2VTiba3CyGTgxFTiIC3Pz98vd6Vc8XVjpUIacfViBhVb2KwckTfCl4SaaTnjEukdXefxK3tu3us5Sq6kWirCmymURF0jCIiAIiIAiIgMdi5mbxFbKQ6ZW0yD1JB6wrpsnMuqzI2ZTDKrUwYoYfDezplwvNV/7D+1daltdRlH9pA65f78Qqx7mdvWubawOJs6ikqCJP2hwv/JV0uYpfWXr9iZbeSPyN0PIbRYZ25r8bfPvWmxtTiIh5ppJi9UcZLU+yOKfvWW/5Vur7LYaLnKuUv8AEkIlhuX9sShM/ccG5tLkspJ5tiqpRs/ebiP+1TdntlxgNreTIZZusMfSIl4vaJWarWhrx8nBFHEHqAdK3vuXjVviU8SqrlUy3QiIsHkEREAREQBERAEREAREQBERAEREAREQBERAEREAREQH/9k=')"></div>
                                <div class="desktopThumbnail" style="background-image: url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD//gAKLXZlcmJvc2X/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCABpAIwDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAQGAQMFAgcI/8QAPBAAAQMDAgMFBQQIBwAAAAAAAQACAwQFEQYhEjFBE1FhcYEUIpGhsQdCVcEVI1JilNHS4SQyM2NykvD/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAgMEAQX/xAArEQACAQIEBQMEAwAAAAAAAAAAAQIDEQQTITESIkFRoRQjMjNxsdFCUsH/2gAMAwEAAhEDEQA/AP2WiIgCIiAIiIAiLxJJHG0uke1jRzLiAEB7RQXXe1tPCbhSg93bN/mt8FXSz/6FTDL/AMJAfonC+wszeiIgCIiAIiIAiIgCIiAIiIDGVHraqCkpnT1EjY428yfoO9ZrKqGlppKiZ3DHGMuKpcTK7VN0c97nQ0kR6bhg7h3uPU/lgHRh6GZeUnaK3ZnrV+B8MdZMkVmo7lcZzS2ane0ftYBcR3no31XmHSVxrHdrc6/DjzGTI4epIA9Mq2W6hpqCAQ00YY0c+8+JPUqSuyxCjpSVl5JU6clrN3ZVmaJoAzDqqpJ8OED4YUao0O0ZdSV72uHLtGD6jGFc/VFTmSe7NMKko7MoL5tT6ePFNxVNKOZcTIzHnzb67Kx6f1BR3ZnAwmKoAy6Jx38weo+feF2HAOGCMghUzVGmzATc7QDG9h43xs6Y+8zx8Ph3GDb3NdKVKvyzXC+j/Zdd1noq9o+/C60xhnLRVRAcWPvDo4fmOh9FYOq4ndXRlq0pUpOElqjKIi6VhERAEREARFgkAE9yAp2tKuWruMNnp99wXDvceQPgBv6+Cs1ooorfQx0sQ2aNz1cepPmqppNvt+pqqveMhvE8eBJwPgMq7N2W3FPLUaK6b/dmHCrMlKq+u32MrC1VAldC8QvayQjDXObxAHvxkZ+K5/s19/EqP+EP9aw7HowgpdTrIuSKe+/iVJ/CH+pPZr7+J0f8If60uyWWv7Lz+jrLHgodBHcI3PNZVQTNwOHs4SzHfnJOVLPn8l1alclZnz7UVM/T2o4blSNxFI4u4Ry/eb6jcf2V9ppmT07J4zxMkaHNPeCuLrylFRp6Z+PegIkb6c/llePs9qTPp9sZOTA90fpnI+RCrjyya7npV3n4SNV7xdn/AIWMIiKw8wIiIAiIgC0VhIpJiOYYfoVvXlzQ5jmnkQuxdnci1dNFQ+zYDhrT1/V/DBUKS8XW1ap1BcaieaqsUE8MNTDjJoW+zsf27MblmXHjG+Bh45OBkaFeaW81dC84cWkY8WEj6H5K3sp4GPmkZDG107gZSGgF5AwCe84AG/TAWvHr32+9vwZsC/ZS7X/J8vorrXy1thgrrjUx2WqsNvfV1ccxJMzzIGNLgfcEh2MgOSQ1uRxAr6LR3Iz3WpoDb6+EQDIqJIg2GTfk12Tk79w5FZqKC2so5mOt0L4TTinfE2AHjiAOI+EDdoBOG8tzstbLpAxoa2hrwAAAPZX8h6LJGLexpcox0Zx/tDo3zxUtV+tqoKISz1FBDUugklZgAyMcHD32cwCQCXcwcEQP0td5rjfZbPFHXUXsVPLA+aufEWcULyC1vA7GRgk7HJ5bLtXYWi7MYy5WWerEZJYJaJzsZ2I5ciNiOR65UltZRNdK8WuqDpgGyH2M++BkAHbcAHG/RSy5djmZEqmnYW6juEdHfqioljpbTRzU9J27mNm7RhL53YILzxDhGSQ3BOAXZUWsNc9ws1JJU3Ohp9QimhD698bns9ke98TpRlzgx+RuSdg0klpKuD7dZbzDFTVdnBZStAh7amLOzB2ww7EDAAIB5AZXSpbdQU1PT01PQ08UNMeKBjIgGxHBGWgbA4cRt3nvKg1bclGSaujg26319Boyup7pP2jz2742Gd83Yxkksj7R4Dn4GNz5DYBR/suJ9hrM8u1GP+oXX1pUCn05VHOHSN7NvmdlC+zinMdidM4YM0rnDxA2H0VbXOenS5cDNvq14LQiIrDzQiIgCIiAIiICj6liktOo4rnE08EhDzjqRs4eo39VcaWaOpp2TwuD43tBaR1Cj3m3xXOgkppNjzY7G7XDkVVLBdJ7HWSWy4giLi5/sE9R+6f796329TSVvlHyjBf09V3+MvDL0otwmkp6OSaIRZYMkyv4GtGdyTvsBk+i3xPZJGHsc1zSMgg5BC11tNT1lM6nqoY5oX44mPaCDg5GQfEA+iwG84MGoKyVx4qGGAFpwZZiCxzWtc8uGNmgOJHXYZAztMtt1nnuENLUUgg7el7dhLiSCC0Fp2Az72cZyAASBnAkyWe1ydoJLfTv7RoY/iYDxAEEA554IHwHcFup6Cjp5nTQU0UcpaGl7WgEgY2+Q+A7kBJ5LPRFXNV6hjtsTqamcH1bhsOYjz1P5D8l1K5KnTc3wxONrqtfcLpBaKT3yx44scjIdgPQHfz8FcbVSsobfDSs/wAsTA3zx1Vb0NZHxE3auB7eTJia7mAebj4n6eatyilq2asVUioxowekfLMoiLpjCIiAIiIAiIgC5l7tFNdIOGUcErR7kjRu3+Y8F00UoTcHxRdmQlBTTjJaFDaL7puQ+72tLnuLoz497T/7ddai1hQSN/xMckDupxxN+I3+SspAIwRkLl1dgtNSS6SjY1x+8zLT8sLW8RSq/Vjr3RmjQqU37ctOzMN1FZSNq+MDxBH1Cj1Oq7PECWTvnI6Rxk/M4C1nR9qJzx1IHhJ/ZbafStmiPvU75T/uPJHwGyrfp1qrmiDn/I4NZqW6XWQ0tppnx52Jb7z8efJvn81P07pRsEgrLm4TT54hHnLWnnknqfl5qzU1PBTx9nBDHEwfdY0AfJblS5raKNCquKtHQBERQKwiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiA//9k=')"></div>
                                <div class="mobilePicture" style="background-image: url('https://d2j6dbq0eux0bg.cloudfront.net/startersite/images/83623760/1673498385878.jpg')"></div>
                                <div class="desktopPicture" style="background-image: url('https://d2j6dbq0eux0bg.cloudfront.net/startersite/images/83623760/1673498389228.jpg')"></div>
                                &nbsp;
                            </div>
                            <div class="cover__overlay" style=" background-color: rgba(93, 148, 179, 0.5); "></div>
                            <div class="cover__container">
                                <ul class="cover__header header">
                                    <li class="header__item">
                                        <div class="cover__logo">
                                            <div class="content">
                                                <a href="/" aria-label="NK-Store Online">
                                                    <div class="logo" style="background-image: url('https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg');color: rgba(255, 255, 255, 1);">
                                                        <img src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg" alt="NK-Store Online"/>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="cover__title">
                                            <div class="content">
                                                <a href="/" aria-label="NK-Store Online">
                                                    <h1 class="cover-title" style="font-family: 'Nunito'; color: rgb(29, 137, 198);">Welcom to NK-Shop</h1>
                                                </a>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="header__item" style="font-family: Cabin; color: #FFFFFF">
                                        <div class="cover__menu">
                                            <div class="content">
                                                <nav class="main-nav" role="navigation">
                                                    <ul class="top-menu">
                                                        <li class="top-menu__item top-menu__item--store">
                                                            <a href="javascript:void(0);">Store</a>
                                                        </li>
                                                        <li class="top-menu__item top-menu__item--about">
                                                            <a href="javascript:void(0);" onclick="scrollToTile('.tile-about')">About</a>
                                                        </li>
                                                        <li class="top-menu__item top-menu__item--location">
                                                            <a href="javascript:void(0);" onclick="scrollToTile('.tile-location')">Location</a>
                                                        </li>
                                                        <li class="top-menu__item top-menu__item--contacts">
                                                            <a href="javascript:void(0);" onclick="scrollToTile('.tile-contactInfo')">Contact us</a>
        </li>
                                                        <li class="top-menu__item top-menu__item--login">
                                                            <a href="login">Login</a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="header__item" style="font-family: Cabin; color: #FFFFFF">
                                        <div class="cover__phone">
                                            <div class="content">
                                                <a href="tel:2097467996">
                                                    <span class="svg-icon">
                                                        <svg viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M13.332 11.426l-2.16-2.166c-.234-.232-.63-.225-.883.03l-1.357 1.357-.33-.182-.215-.12c-1.193-.663-1.882-1.13-2.732-1.983-.85-.854-1.315-1.54-1.982-2.743-.06-.11-.085-.155-.114-.205l-.19-.33.27-.27.73-.732.36-.36c.255-.256.262-.655.03-.888L2.598.668c-.23-.232-.628-.225-.88.03l-.55.54c-.186.275-.33.54-.433.802-.102.27-.165.525-.194.783-.263 2.19.75 4.225 3.59 7.07 1.724 1.728 3.414 2.77 5 3.278.555.18 1.057.277 1.5.314.267.023.455.02.554.01.267-.033.52-.097.778-.197.276-.108.534-.255.722-.4l.62-.582c.253-.255.26-.655.028-.89zM4.615 5.254l-.267.267-.354-.353.435-.247.12.216c.02.04.043.08.065.118z" stroke="currentColor" fill-rule="nonzero" fill="none"></path>
                                                        </svg>
                                                    </span>
                                                    <span class="text">20 9746 7996</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="cover__directions">
                                            <div class="content">
                                                <a href="#map" onclick="scrollToTile('.tile-location');return false">
                                                    <span class="svg-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 14" height="14">
                                                            <path d="M5 0c2.76 0 5 2.304 5 4.996C10 8.61 5 14 5 14S0 8.61 0 4.996C0 2.304 2.24 0 5 0zm1.68 10.283c.678-.978 1.24-1.923 1.643-2.8C8.767 6.515 9 5.67 9 4.996 9 2.832 7.184 1 5 1S1 2.83 1 4.996c0 .674.233 1.52.677 2.487.404.877.965 1.822 1.644 2.8.53.76 1.098 1.497 1.667 2.178.595-.68 1.163-1.416 1.692-2.177zM5 7c-1.105 0-2-.895-2-2s.895-2 2-2 2 .895 2 2-.895 2-2 2z" fill-rule="nonzero"></path>
                                                        </svg>
                                                    </span>
                                                    <span class="text">Get directions</span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="cover__hours">
                                            <div class="content">
                                                <a href="#storehours" onclick="scrollToTile('.tile-location');return false">
                                                    <span class="svg-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" height="14">
                                                            <path d="M6.5 13C2.91 13 0 10.09 0 6.5S2.91 0 6.5 0 13 2.91 13 6.5 10.09 13 6.5 13zm0-1C9.538 12 12 9.538 12 6.5S9.538 1 6.5 1 1 3.462 1 6.5 3.462 12 6.5 12zM7 2.5V6h2.5c.276 0 .5.224.5.5s-.224.5-.5.5h-3c-.276 0-.5-.224-.5-.5v-4c0-.276.224-.5.5-.5s.5.224.5.5z" fill-rule="nonzero"></path>
                                                        </svg>
                                                    </span>
                                                    <span class="text">Business hours</span>
                                                </a>
                                            </div>
                                        </div>
                                        <nav class="cover__social" role="navigation">
                                            <div class="content">
                                                <ul class="social-media">
                                                    <li class="social-media__item" data-name="Facebook">
                                                        <a href="https://facebook.com/profile.php?id=100082826786770&mibextid=ZbWKwL" target="_blank" rel="noopener noreferrer nofollow">
                                                            <span class="svg-icon">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48">
                                                                    <path fill="currentColor" fill-rule="evenodd" d="M48 45c0 1.656-1.344 3-3 3H3c-1.656 0-3-1.344-3-3V3c0-1.656 1.344-3 3-3h42c1.656 0 3 1.344 3 3v42zm-15 3V30h6l1.5-7.5H33v-3c0-3 1.503-4.5 4.5-4.5h3V7.5h-6c-5.512 0-9 4.322-9 10.5v4.5h-6V30h6v18H33z"/>
                                                                </svg>
                                                            </span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </nav>
                                        <div class="cover__cart">
                                            <div class="content">
                                                <div data-layout="SMALL_ICON" class="ec-cart-widget"></div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <div class="cover__body">
                                    <div class="cover__content">
                                        <div class="cover__content-inner">
                                            <div class="cover__logo">
                                                <div class="content">
                                                    <div class="logo" style="background-image: url('https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg');color: rgba(255, 255, 255, 1);">
                                                        <img src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg" alt="NK-Store Online"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="cover__title">
                                                <div class="content">
                                                    <h1 class="cover-title"  style="font-family: Phetsarath OT; color: rgb(29, 137, 198);">ຍີນດີຕ້ອນຮັບທຸກທ່ານ ສູ່ຮ້ານ NK-Shop ຂອງພວກເຮົາ.</h1>
                                                </div>
                                            </div>
                                            <div class="cover__subtitle">
                                                <div class="content"></div>
                                            </div>
                                            <div class="cover__cta">
                                                <div class="content">
                                                    <button class="cover__button cover-button" style="font-family: 'Cabin';color: rgb(255, 255, 255);background-color: rgb(51, 51, 51)" onclick="scrollToTile('.tile-store')">
                                                        <span class="cover__button-text">Shop Now</span>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="cover__phone cover-text">
                                                <div class="content" style="font-family: Cabin;color: rgb(51, 51, 51)">
                                                    <a href="javascript:void(0);" style="pointer-events: none">
                                                        <span class="svg-icon">
                                                            <svg viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M13.332 11.426l-2.16-2.166c-.234-.232-.63-.225-.883.03l-1.357 1.357-.33-.182-.215-.12c-1.193-.663-1.882-1.13-2.732-1.983-.85-.854-1.315-1.54-1.982-2.743-.06-.11-.085-.155-.114-.205l-.19-.33.27-.27.73-.732.36-.36c.255-.256.262-.655.03-.888L2.598.668c-.23-.232-.628-.225-.88.03l-.55.54c-.186.275-.33.54-.433.802-.102.27-.165.525-.194.783-.263 2.19.75 4.225 3.59 7.07 1.724 1.728 3.414 2.77 5 3.278.555.18 1.057.277 1.5.314.267.023.455.02.554.01.267-.033.52-.097.778-.197.276-.108.534-.255.722-.4l.62-.582c.253-.255.26-.655.028-.89zM4.615 5.254l-.267.267-.354-.353.435-.247.12.216c.02.04.043.08.065.118z" stroke="currentColor" fill-rule="nonzero" fill="none"></path>
                                                            </svg>
                                                        </span>
                                                        <span class="text">20 9746 7996</span>
                                                    </a>
                                                </div>
                                            </div>
                                            <nav class="cover__social cover-text" role="navigation">
                                                <div class="content" style="font-family: Cabin;color: rgb(51, 51, 51)">
                                                    <ul class="social-media">
                                                        <li class="social-media__item" data-name="Facebook">
                                                            <a href="https://facebook.com/profile.php?id=100082826786770&mibextid=ZbWKwL" target="_blank" rel="noopener noreferrer nofollow">
                                                                <span class="svg-icon">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48">
                                                                        <path fill="currentColor" fill-rule="evenodd" d="M48 45c0 1.656-1.344 3-3 3H3c-1.656 0-3-1.344-3-3V3c0-1.656 1.344-3 3-3h42c1.656 0 3 1.344 3 3v42zm-15 3V30h6l1.5-7.5H33v-3c0-3 1.503-4.5 4.5-4.5h3V7.5h-6c-5.512 0-9 4.322-9 10.5v4.5h-6V30h6v18H33z"/>
                                                                    </svg>
                                                                </span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                                <div class="cover__footer cover-text">
                                    <div class="content" style="font-family: Cabin;color: rgb(51, 51, 51)">
                                        <div class="forward" onclick="scrollToTile('.tile-store')">
                                            <div class="svg-icon">
                                                <svg width="32" height="17" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M31 1L16 16 1 1" stroke-width="2" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tile tile-store">
                    <div>
                        <div class="caption" data-block="caption">
                            <div>
                                <a href="/" class="home" aria-label="NK-Store Online">
                                    <div class="logo" style="background-image: url('https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg');color: rgba(255, 255, 255, 1);">
                                        <img src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3414811819.jpg" alt="NK-Store Online"/>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="menu hidden" data-block="menu">
                            <div>
                                <div class="pushmenu-btn">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="438.533" height="438.533" viewBox="0 0 438.533 438.533">
                                        <path fill="{fill-color}" d="M420.265 328.897H18.275c-4.953 0-9.236 1.813-12.852 5.428C1.807 337.938 0 342.225 0 347.172v36.548c0 4.95 1.807 9.23 5.424 12.848 3.62 3.613 7.902 5.424 12.85 5.424h401.992c4.948 0 9.23-1.81 12.847-5.424 3.614-3.617 5.42-7.898 5.42-12.848v-36.548c0-4.948-1.8-9.233-5.42-12.847-3.618-3.614-7.896-5.428-12.848-5.428zM433.112 41.968c-3.617-3.617-7.898-5.426-12.847-5.426H18.275c-4.953 0-9.236 1.81-12.852 5.426C1.807 45.583 0 49.866 0 54.813V91.36c0 4.95 1.807 9.23 5.424 12.847 3.62 3.618 7.902 5.424 12.85 5.424h401.992c4.948 0 9.23-1.806 12.847-5.423 3.614-3.617 5.42-7.898 5.42-12.847V54.813c0-4.947-1.804-9.23-5.42-12.845zM420.265 182.72H18.275c-4.953 0-9.236 1.81-12.852 5.426C1.807 191.76 0 196.044 0 200.992v36.547c0 4.947 1.807 9.235 5.424 12.846 3.62 3.614 7.902 5.428 12.85 5.428h401.992c4.948 0 9.23-1.813 12.847-5.428 3.614-3.61 5.42-7.898 5.42-12.847V200.99c0-4.948-1.806-9.23-5.42-12.847-3.618-3.617-7.896-5.425-12.848-5.425z"/>
                                    </svg>
                                    <span>Categories</span>
                                </div>
                                <div class="container"></div>
                            </div>
                        </div>
                        <script>
                            var hasStaticHtml = true;
                            var isHomePage = true;
                        </script>
                        <div id="static-html" class="store static-product-browser" data-block="store" style="">
                            <div style="min-height: 400px;">
                                <div class="static-content">
                                    <style>
                                        .ec-static-container__wait {
                                            cursor: wait;
                                        }

                                        .ec-static-container__wait a {
                                            cursor: wait !important;
                                        }
                                    </style>
                                    <div class="ec-static-container">
                                        <div class="ecwid ec-size">
                                            <div class="ecwid-productBrowser ecwid-productBrowser-CategoryPage ecwid-productBrowser-CategoryPage-0">
                                                <div class="ec-wrapper">
                                                    <div class="ec-store ec-store__category-page ec-store__category-page--0 ec-store--medium-product-images">
                                                        <div class="ec-store__content-wrapper ec-store__content-wrapper--wide">
                                                            <div class="ec-grid">
                                                                <div class="grid__sort ec-text-muted">
                                                                    <div class="form-control form-control--select-inline grid-sort__item grid-sort__item--sortby">
                                                                        <label for="ec-products-sort-static">
                                                                            <div class="form-control__select-text">Sort by</div>
                                                                        </label>
                                                                        <select class="form-control__select" tabindex="-1" id="ec-products-sort-static">
                                                                            <option value="normal" selected>We recommend</option>
                                                                            <option value="addedTimeDesc">Newest arrivals</option>
                                                                            <option value="priceAsc">Price: Low to High</option>
                                                                            <option value="priceDesc">Price: High to Low</option>
                                                                            <option value="nameAsc">Name: A to Z</option>
                                                                            <option value="nameDesc">Name: Z to A</option>
                                                                        </select>
                                                                        <div class="form-control__arrow">
                                                                            <svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                                                                                <path d="M11 4L6 9 1 4" stroke="currentColor" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"/>
                                                                            </svg>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="grid__wrap">
                                                                    <div class="grid__wrap-inner">
                                                                        <div class="grid__products grid__products--medium-items grid__products--aspect-ratio-0667 grid__products--appearance-frame grid__products--layout-center " data-items="10" data-cols="0">
                                                                            <div class="grid-product grid-product--id-522832912      ">
                                                                                <div class="grid-product__wrap" data-product-id="522832912">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/esyy`ayn-Adidas-p522832912" data-product-id="522832912">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(236,237,239,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3415156624.jpg" style="width:100%;height:auto;margin-top:25%" title="ເສື້ອໃນ Adidas" alt="ເສື້ອໃນ Adidas">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner" style="font-family: Phetsarath OT;">ເສື້ອໃນ Adidas</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/esyy`ayn-Adidas-p522832912" data-product-id="522832912">
                                                                                            <div class="grid-product__title-inner" style="font-family: Phetsarath OT;">ເສື້ອໃນ Adidas</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭75 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522565060      ">
                                                                                <div class="grid-product__wrap" data-product-id="522565060">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/sud-esyy`-osng-p522565060" data-product-id="522565060">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(220,218,219,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183378.jpg" style="width:100%;height:100%" title="ຊຸດ ເສື້ອ+ໂສ້ງ" alt="ຊຸດ ເສື້ອ+ໂສ້ງ">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner" style="font-family: Phetsarath OT;">ຊຸດ ເສື້ອ+ໂສ້ງ</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/sud-esyy`-osng-p522565060" data-product-id="522565060">
                                                                                            <div class="grid-product__title-inner" style="font-family: Phetsarath OT;">ຊຸດ ເສື້ອ+ໂສ້ງ</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭195 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522435698      ">
                                                                                <div class="grid-product__wrap" data-product-id="522435698">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/sud-edkn`nykaopk-p522435698" data-product-id="522435698">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(231,230,226,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188777.jpg" style="width:100%;height:100%" title="ຊຸດ ເດັກນ້ອຍກະໂປກ" alt="ຊຸດ ເດັກນ້ອຍກະໂປກ">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner" style="font-family: Phetsarath OT;">ຊຸດ ເດັກນ້ອຍກະໂປກ</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/sud-edkn`nykaopk-p522435698" data-product-id="522435698">
                                                                                            <div class="grid-product__title-inner"style="font-family: Phetsarath OT;">ຊຸດ ເດັກນ້ອຍກະໂປກ</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭55 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522569005      ">
                                                                                <div class="grid-product__wrap" data-product-id="522569005">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/Yellow-Solid-Jumpsuit-p522569005" data-product-id="522569005">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(230,229,227,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183393.jpg" style="width:100%;height:100%" title="Yellow Solid Jumpsuit" alt="Yellow Solid Jumpsuit">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner">Yellow Solid Jumpsuit</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/Yellow-Solid-Jumpsuit-p522569005" data-product-id="522569005">
                                                                                            <div class="grid-product__title-inner">Yellow Solid Jumpsuit</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭125 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522565061      ">
                                                                                <div class="grid-product__wrap" data-product-id="522565061">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/osngw`m-ehlyy`ngehi-p522565061" data-product-id="522565061">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(225,224,220,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188837.jpg" style="width:100%;height:100%" title="ໂສ້ງວອມ ເຫລືອງເຕິ" alt="ໂສ້ງວອມ ເຫລືອງເຕິ">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner" style="font-family: Phetsarath OT;">ໂສ້ງວອມ ເຫລືອງເຕິ</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/osngw`m-ehlyy`ngehi-p522565061" data-product-id="522565061">
                                                                                            <div class="grid-product__title-inner" style="font-family: Phetsarath OT;">ໂສ້ງວອມ ເຫລືອງເຕິ</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭75 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522450721      ">
                                                                                <div class="grid-product__wrap" data-product-id="522450721">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/esyy`laany-eidng-khaaw-p522450721" data-product-id="522450721">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(228,224,221,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183358.jpg" style="width:100%;height:auto;margin-top:0.075%" title="ເສື້ອລາຍ ແດງ-ຂາວ" alt="ເສື້ອລາຍ ແດງ-ຂາວ">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner" style="font-family: Phetsarath OT;">ເສື້ອລາຍ ແດງ-ຂາວ</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/esyy`laany-eidng-khaaw-p522450721" data-product-id="522450721">
                                                                                            <div class="grid-product__title-inner" style="font-family: Phetsarath OT;">ເສື້ອລາຍ ແດງ-ຂາວ</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭59 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522445241      ">
                                                                                <div class="grid-product__wrap" data-product-id="522445241">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/kaopngnyaaw-phaayiin-p522445241" data-product-id="522445241">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(236,237,241,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188792.jpg" style="width:100%;height:auto;margin-top:0.039%" title="ກະໂປ່ງຍາວ ຜ້າຢີນ" alt="ກະໂປ່ງຍາວ ຜ້າຢີນ">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner" style="font-family: Phetsarath OT;">ກະໂປ່ງຍາວ ຜ້າຢີນ</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/kaopngnyaaw-phaayiin-p522445241" data-product-id="522445241">
                                                                                            <div class="grid-product__title-inner" style="font-family: Phetsarath OT;">ກະໂປ່ງຍາວ ຜ້າຢີນ</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭100 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522453490      ">
                                                                                <div class="grid-product__wrap" data-product-id="522453490">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/Sleeveless-Jeans-Jacket-p522453490" data-product-id="522453490">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(228,227,225,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183368.jpg" style="width:100%;height:auto;margin-top:0.039%" title="Sleeveless Jeans Jacket" alt="Sleeveless Jeans Jacket">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner">Sleeveless Jeans Jacket</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/Sleeveless-Jeans-Jacket-p522453490" data-product-id="522453490">
                                                                                            <div class="grid-product__title-inner">Sleeveless Jeans Jacket</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭99 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522563354      ">
                                                                                <div class="grid-product__wrap" data-product-id="522563354">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/Yellow-Fluffy-Sweater-p522563354" data-product-id="522563354">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(233,236,245,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188822.jpg" style="width:100%;height:100%" title="Yellow Fluffy Sweater" alt="Yellow Fluffy Sweater">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner">Yellow Fluffy Sweater</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/Yellow-Fluffy-Sweater-p522563354" data-product-id="522563354">
                                                                                            <div class="grid-product__title-inner">Yellow Fluffy Sweater</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭130 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="grid-product grid-product--id-522453491      ">
                                                                                <div class="grid-product__wrap" data-product-id="522453491">
                                                                                    <div class="grid-product__wrap-inner">
                                                                                        <a class="grid-product__image" href="https://nakhin.company.site/sud-esyy`eikhnnyaaw-osng-p522453491" data-product-id="522453491">
                                                                                            <div class="grid-product__spacer">
                                                                                                <div class="grid-product__spacer-inner"></div>
                                                                                            </div>
                                                                                            <div class="grid-product__bg" style="background-color: rgba(228,228,230,1);"></div>
                                                                                            <div class="grid-product__image-wrap">
                                                                                                <img class="grid-product__picture" src="https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188807.jpg" style="width:100%;height:100%" title="ຊຸດ ເສືອແຂນຍາວ+ໂສ້ງ" alt="ຊຸດ ເສືອແຂນຍາວ+ໂສ້ງ">
                                                                                            </div>
                                                                                            <div class="grid-product__shadow ec-text-muted">
                                                                                                <div class="grid-product__shadow-inner" style="font-family: Phetsarath OT;">ຊຸດ ເສືອແຂນຍາວ+ໂສ້ງ</div>
                                                                                            </div>
                                                                                            <div class="grid-product__hover-wrap"></div>
                                                                                            <div class="grid__clearfix"></div>
                                                                                        </a>
                                                                                        <a class="grid-product__title" href="https://nakhin.company.site/sud-esyy`eikhnnyaaw-osng-p522453491" data-product-id="522453491">
                                                                                            <div class="grid-product__title-inner" style="font-family: Phetsarath OT;">ຊຸດ ເສືອແຂນຍາວ+ໂສ້ງ</div>
                                                                                        </a>
                                                                                        <div class="grid-product__price">
                                                                                            <div class="grid-product__price-amount">
                                                                                                <div class="grid-product__price-value ec-price-item">₭190 000.00</div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="ec-footer">
                                                                <ul class="ec-footer__row" data-items="3">
                                                                    <li class="ec-footer__cell">
                                                                        <a class="ec-footer__link ec-link ec-link--muted link--icon-top footer__link--my-account" href="https://nakhin.company.site/account">
                                                                            <span class="svg-icon">
                                                                                <svg width="22" height="22" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg">
                                                                                    <g fill-rule="nonzero" fill="currentColor">
                                                                                        <path d="M11 21c5.523 0 10-4.477 10-10S16.523 1 11 1 1 5.477 1 11s4.477 10 10 10zm0 1C4.925 22 0 17.075 0 11S4.925 0 11 0s11 4.925 11 11-4.925 11-11 11z"></path>
                                                                                        <path d="M18.08 18.854c-.502-.617-1.156-1.143-1.974-1.612-.168-.096-.46-.248-.902-.47-.358-.18-.97-.483-.94-.466-.543-.295-.927-.56-1.117-.782l-.155-.824c1.625-.848 2.563-2.847 2.563-5.24 0-2.96-1.872-5.04-4.555-5.04S6.446 6.5 6.446 9.46c0 2.42.945 4.427 2.588 5.26l-.135.725c-.16.214-.7.595-1.188.865.032-.018-.567.28-.973.485-.4.2-.69.353-.856.45-.81.463-1.457.986-1.956 1.595.092.29.512.498.81.588.426-.507.973-.932 1.644-1.317.407-.233 1.794-.914 1.814-.925.352-.195 1.17-.694 1.504-1.143l.14-.186.315-1.69-.67-.34c-1.25-.633-2.04-2.272-2.04-4.365 0-2.472 1.49-4.04 3.555-4.04 2.067 0 3.555 1.568 3.555 4.04 0 2.07-.784 3.705-2.026 4.353l-.657.343.34 1.816.175.204c.33.385.884.73 1.4 1.01.024.01 1.413.69 1.82.924.697.398 1.26.838 1.69 1.368.468-.186.663-.403.782-.624z"></path>
                                                                                    </g>
                                                                                </svg>
                                                                            </span>
                                                                            My Account					
                                                                        </a>
                                                                    </li>
                                                                    <li class="ec-footer__cell">
                                                                        <a class="ec-footer__link ec-link ec-link--muted link--icon-top footer__link--track-order" href="https://nakhin.company.site/account">
                                                                            <span class="svg-icon">
                                                                                <svg width="16" height="18" viewBox="0 0 16 18" xmlns="http://www.w3.org/2000/svg">
                                                                                    <g fill-rule="nonzero" fill="currentColor">
                                                                                        <path d="M1 5.414V17h14V1H5.414L1 5.414zM15 0c.552 0 1 .445 1 .993v16.014c0 .548-.445.993-1 .993H1c-.552 0-1-.445-1-.993V5l5-5h10z"></path>
                                                                                        <path d="M5.108 9.832c-.19-.2-.508-.205-.707-.013-.198.19-.204.507-.012.706l2.823 2.93c.216.225.58.2.765-.05l5.153-7.04c.164-.223.115-.536-.108-.7-.222-.162-.535-.114-.698.11l-4.803 6.56L5.107 9.83zM0 5v1h6V0H5v5"></path>
                                                                                    </g>
                                                                                </svg>
                                                                            </span>
                                                                            Track Orders					
                                                                        </a>
                                                                    </li>
                                                                    <li class="ec-footer__cell">
                                                                        <a class="ec-footer__link ec-link ec-link--muted link--icon-top footer__link--shopping-cart footer__link--empty" href="https://nakhin.company.site/cart">
                                                                            <span class="svg-icon">
                                                                                <svg width="16" height="20" viewBox="0 0 16 20" xmlns="http://www.w3.org/2000/svg">
                                                                                    <g fill="none" fill-rule="evenodd">
                                                                                        <path d="M1 5v13.006c0 .548.446.994.994.994h12.012c.548 0 .994-.446.994-.994V5H1zm15-1v14.006c0 1.1-.895 1.994-1.994 1.994H1.994C.894 20 0 19.105 0 18.006V4h16z" fill="currentColor" fill-rule="nonzero"></path>
                                                                                        <path d="M5 7s-.005.5-.504.5C3.996 7.5 4 7 4 7V4c0-2.21 1.79-4 4-4s4 1.79 4 4v3s-.002.5-.5.5S11 7 11 7V4c0-1.657-1.343-3-3-3S5 2.343 5 4v3z" fill="currentColor"></path>
                                                                                    </g>
                                                                                </svg>
                                                                            </span>
                                                                            Shopping Bag				
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                                <div class="ec-currency-converter-element ec-currency-converter-selector">
                                                                    <div class="form-control form-control--select-inline">
                                                                        <div class="form-control__select-text">
                                                                            <span class="form-control__select-text">Display prices in:</span>
                                                                            <span>LAK</span>
                                                                        </div>
                                                                        <select class="form-control__select" aria-label="Display prices in:"></select>
                                                                        <div class="form-control__arrow">
                                                                            <svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                                                                                <path d="M11 4L6 9 1 4" fill="none" fill-rule="evenodd" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            </svg>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    var EcStaticPageUtils = (function() {

                                        function isEmpty(str) {
                                            return (!str || 0 === str.length);
                                        }

                                        function isNotEmpty(str) {
                                            return !isEmpty(str);
                                        }

                                        function findFirstNotEmpty(urlArray) {
                                            if (!urlArray) {
                                                return "";
                                            }

                                            for (var i = 0; i < urlArray.length; i++) {
                                                if (isNotEmpty(urlArray[i])) {
                                                    return urlArray[i];
                                                }
                                            }

                                            return "";
                                        }

                                        return {
                                            findFirstNotEmpty: function(urlArray) {
                                                return findFirstNotEmpty(urlArray);
                                            },
                                            isEmpty: function(str) {
                                                return isEmpty(str);
                                            },
                                            isNotEmpty: function(str) {
                                                return isNotEmpty(str);
                                            }
                                        };
                                    }
                                    )();

                                    (function processProductPictures() {
                                        var productsPicturesData = buildProductPicturesData();
                                        var lastWidth = document.body.clientWidth;

                                        function buildProductPicturesData() {
                                            return [{
                                                id: "522832912",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3415156624.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3415156620.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3415156623.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3415156622.jpg",
                                            },
                                            {
                                                id: "522565060",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183378.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183376.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183380.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183377.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183384.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183381.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183383.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183385.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "241",
                                                        green: "200",
                                                        blue: "206"
                                                    }
                                                }
                                            },
                                            {
                                                id: "522435698",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188777.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188775.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188779.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188776.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188783.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188780.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188782.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188784.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "192",
                                                        green: "203",
                                                        blue: "217"
                                                    }
                                                }
                                            },
                                            {
                                                id: "522569005",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183393.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183391.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183395.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183392.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183399.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183396.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183398.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183400.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "243",
                                                        green: "243",
                                                        blue: "242"
                                                    }
                                                }
                                            },
                                            {
                                                id: "522565061",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188837.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188835.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188839.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188836.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188843.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188840.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188842.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188844.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "230",
                                                        green: "230",
                                                        blue: "232"
                                                    }
                                                }
                                            },
                                            {
                                                id: "522450721",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183358.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183356.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183360.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183357.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183364.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183361.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183363.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183365.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "227",
                                                        green: "178",
                                                        blue: "190"
                                                    }
                                                }
                                            },
                                            {
                                                id: "522445241",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188792.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188790.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188794.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188791.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188798.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188795.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188797.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188799.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "233",
                                                        green: "232",
                                                        blue: "230"
                                                    }
                                                }
                                            },
                                            {
                                                id: "522453490",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183368.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183366.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183370.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183367.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183374.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183371.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183373.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413183375.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "233",
                                                        green: "233",
                                                        blue: "232"
                                                    }
                                                }
                                            },
                                            {
                                                id: "522563354",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188822.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188820.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188824.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188821.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188828.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188825.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188827.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188829.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "224",
                                                        green: "223",
                                                        blue: "229"
                                                    }
                                                }
                                            },
                                            {
                                                id: "522453491",
                                                thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188807.jpg",
                                                originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188805.jpg",
                                                hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188809.jpg",
                                                pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188806.jpg",
                                                additionalImage: {
                                                    thumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188813.jpg",
                                                    originalImageUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188810.jpg",
                                                    hdThumbnailUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188812.jpg",
                                                    pictureUrl: "https://d2j6dbq0eux0bg.cloudfront.net/images/83623760/3413188814.jpg",
                                                    borderInfo: {
                                                        alpha: "255",
                                                        red: "236",
                                                        green: "209",
                                                        blue: "224"
                                                    }
                                                }
                                            }
                                            ];
                                        }

                                        function addSrcSetAttribute(element, retinaThumbnailUrl) {
                                            if (!element) {
                                                return;
                                            }
                                            var thumbnailUrl = element.getAttribute('src');

                                            var srcSetAttribute;
                                            if (EcStaticPageUtils.isNotEmpty(thumbnailUrl) && EcStaticPageUtils.isNotEmpty(retinaThumbnailUrl)) {
                                                srcSetAttribute = thumbnailUrl + " 1x, " + retinaThumbnailUrl + " 2x";
                                            } else if (EcStaticPageUtils.isNotEmpty(thumbnailUrl)) {
                                                srcSetAttribute = thumbnailUrl + " 1x";
                                            } else if (EcStaticPageUtils.isNotEmpty(retinaThumbnailUrl)) {
                                                srcSetAttribute = retinaThumbnailUrl + " 2x";
                                            }

                                            if (srcSetAttribute) {
                                                var lazyLoadingEnabled = "false";
                                                if (lazyLoadingEnabled === "true") {
                                                    element.setAttribute("data-srcset", srcSetAttribute);
                                                } else {
                                                    element.setAttribute("srcset", srcSetAttribute);
                                                }
                                            }
                                        }

                                        function setBackgroundImageStyle(element, thumbnailUrl, retinaThumbnailUrl, borderInfo) {
                                            if (!element || !borderInfo || (EcStaticPageUtils.isEmpty(thumbnailUrl) && EcStaticPageUtils.isEmpty(retinaThumbnailUrl))) {
                                                return;
                                            }

                                            var notEmptyRetinaThumbnailUrl = retinaThumbnailUrl;
                                            if (EcStaticPageUtils.isEmpty(retinaThumbnailUrl)) {
                                                notEmptyRetinaThumbnailUrl = thumbnailUrl;
                                            }

                                            element.setAttribute("style", "background-image: url(" + thumbnailUrl + "); background-image: -webkit-image-set(url(" + thumbnailUrl + ") 1x, url(" + notEmptyRetinaThumbnailUrl + ") 2x); background-image: -moz-image-set(url(" + thumbnailUrl + ") 1x, url(" + notEmptyRetinaThumbnailUrl + ") 2x); background-image: -o-image-set(url(" + thumbnailUrl + ") 1x, url(" + notEmptyRetinaThumbnailUrl + ") 2x); background-image: -ms-image-set(url(" + thumbnailUrl + ") 1x, url(" + notEmptyRetinaThumbnailUrl + ") 2x);" + backgroundColor(borderInfo));
                                        }

                                        function backgroundColor(borderInfo) {
                                            if (borderInfo.alpha == 0) {
                                                return "";
                                            }

                                            return " background-color: rgba" + "(" + borderInfo.red + ", " + borderInfo.green + ", " + borderInfo.blue + ", 1)"
                                        }

                                        function hdProductImage(pictureModel) {
                                            var imageSize = "MEDIUM";
                                            var browserWidth = document.body.clientWidth;

                                            switch (imageSize) {
                                            case "SMALL":
                                                if (browserWidth < 520) {
                                                    return hdThumbnailUrl(pictureModel);
                                                }

                                                return thumbnailUrl(pictureModel);
                                            case "MEDIUM":
                                                return hdThumbnailUrl(pictureModel);
                                            case "LARGE":
                                                return pictureUrl(pictureModel);
                                            }
                                        }

                                        function productImage(pictureModel) {
                                            var imageSize = "MEDIUM";

                                            switch (imageSize) {
                                            case "SMALL":
                                            case "MEDIUM":
                                                return thumbnailUrl(pictureModel);
                                            case "LARGE":
                                                return hdThumbnailUrl(pictureModel);
                                            }
                                        }

                                        function hdThumbnailUrl(pictureModel) {
                                            var urls = [pictureModel.hdThumbnailUrl, pictureModel.thumbnailUrl, pictureModel.pictureUrl, pictureModel.originalImageUrl];

                                            return EcStaticPageUtils.findFirstNotEmpty(urls);
                                        }

                                        function thumbnailUrl(pictureModel) {
                                            var urls = [pictureModel.thumbnailUrl, pictureModel.hdThumbnailUrl, pictureModel.pictureUrl, pictureModel.originalImageUrl];

                                            return EcStaticPageUtils.findFirstNotEmpty(urls);
                                        }

                                        function pictureUrl(pictureModel) {
                                            var urls = [pictureModel.pictureUrl, pictureModel.hdThumbnailUrl, pictureModel.originalImageUrl, pictureModel.thumbnailUrl];

                                            return EcStaticPageUtils.findFirstNotEmpty(urls);
                                        }

                                        function process() {
                                            if (window.ec && window.ec.storefront && window.ec.storefront.staticPages && window.ec.storefront.staticPages.staticContainerID) {
                                                var staticContainer = document.querySelector('#' + window.ec.storefront.staticPages.staticContainerID);
                                                if (staticContainer == null) {
                                                    window.removeEventListener("resize", onResize);
                                                    return;
                                                }
                                            }

                                            var pictureElements = document.querySelectorAll('.grid-product__image');

                                            if (productsPicturesData.length !== pictureElements.length) {
                                                return;
                                            }

                                            productsPicturesData.forEach(function(item, i) {
                                                var imageWrapper = document.querySelector(".grid-product__image[data-product-id='" + item.id + "']");
                                                var pictureElement = imageWrapper.querySelector('.grid-product__picture');
                                                var additionalPictureElement = imageWrapper.querySelector('.grid-product__picture-additional');

                                                addSrcSetAttribute(pictureElement, hdProductImage(item));

                                                if (additionalPictureElement != null && item.additionalImage != undefined) {
                                                    setBackgroundImageStyle(additionalPictureElement, productImage(item.additionalImage), hdProductImage(item.additionalImage), item.additionalImage.borderInfo);
                                                }
                                            });
                                        }

                                        function onResize() {
                                            if (document.body.clientWidth !== lastWidth) {
                                                lastWidth = document.body.clientWidth;
                                                process();
                                            }
                                        }

                                        window.addEventListener("resize", onResize);
                                        process();
                                    }
                                    )();

                                    (function processRibbonColor() {

                                        function getColorValues(color) {
                                            if (!color)
                                                return;
                                            if (color.toLowerCase() === 'transparent')
                                                return [0, 0, 0, 0];
                                            if (color[0] === '#') {
                                                if (color.length == 6)
                                                    return;
                                                if (color.length < 7) {
                                                    var r = color[1]
                                                      , g = color[2]
                                                      , b = color[3]
                                                      , a = color[4];
                                                    color = '#' + r + r + g + g + b + b + (color.length > 4 ? a + a : '');
                                                }
                                                return [parseInt(color.substr(1, 2), 16), parseInt(color.substr(3, 2), 16), parseInt(color.substr(5, 2), 16), color.length > 7 ? parseInt(color.substr(7, 2), 16) / 255 : 1];
                                            }
                                            if (color.indexOf('rgb') === -1) {
                                                var tmp = document.body.appendChild(document.createElement('fictum'));
                                                var flag = 'rgb(1, 2, 3)';
                                                tmp.style.color = flag;
                                                if (tmp.style.color !== flag)
                                                    return;
                                                tmp.style.color = color;
                                                if (tmp.style.color === flag || tmp.style.color === '')
                                                    return;
                                                color = getComputedStyle(tmp).color;
                                                document.body.removeChild(tmp);
                                            }
                                            if (color.indexOf('rgb') === 0) {
                                                if (color.indexOf('rgba') === -1)
                                                    color += ',1';
                                                return color.match(/[\.\d]+/g).map(function(a) {
                                                    return +a
                                                });
                                            }
                                        }

                                        function isColorDark(color) {
                                            var c = getColorValues(color);
                                            var hsp = Math.sqrt(0.299 * (c[0] * c[0]) + 0.587 * (c[1] * c[1]) + 0.114 * (c[2] * c[2]));
                                            return !!(hsp <= 200);
                                        }

                                        function process() {
                                            var ribbonElements = document.querySelectorAll('.grid-product__label');

                                            if (ribbonElements) {
                                                ribbonElements.forEach(function(item, i) {
                                                    var ribbonElement = ribbonElements[i].querySelector('.ec-label');
                                                    var color = ribbonElement.style.color;
                                                    if (color) {
                                                        ribbonElement.classList.toggle('label--inversed', !isColorDark(color));
                                                    }
                                                });
                                            }
                                        }

                                        process();
                                    }
                                    )();

                                    (function processCategoryPictures() {
                                        var categoryPicturesData = buildCategoryPicturesData();
                                        var lastWidth = document.body.clientWidth;
                                        var sizeBorder = 400;

                                        function buildCategoryPicturesData() {
                                            return [];
                                        }

                                        function setBackgroundImageStyle(element, thumbnailUrl, retinaThumbnailUrl) {
                                            if (!element || (EcStaticPageUtils.isEmpty(thumbnailUrl) && EcStaticPageUtils.isEmpty(retinaThumbnailUrl))) {
                                                return;
                                            }

                                            var notEmptyRetinaThumbnailUrl = retinaThumbnailUrl;
                                            if (EcStaticPageUtils.isEmpty(retinaThumbnailUrl)) {
                                                notEmptyRetinaThumbnailUrl = thumbnailUrl;
                                            }

                                            element.setAttribute("style", "background-image: url(" + thumbnailUrl + "); background-image: -webkit-image-set(url(" + thumbnailUrl + ") 1x, url(" + notEmptyRetinaThumbnailUrl + ") 2x); background-image: -moz-image-set(url(" + thumbnailUrl + ") 1x, url(" + notEmptyRetinaThumbnailUrl + ") 2x); background-image: -o-image-set(url(" + thumbnailUrl + ") 1x, url(" + notEmptyRetinaThumbnailUrl + ") 2x); background-image: -ms-image-set(url(" + thumbnailUrl + ") 1x, url(" + notEmptyRetinaThumbnailUrl + ") 2x);");
                                        }

                                        function categoryImage(pictureModel) {
                                            var imageSize = "MEDIUM";
                                            switch (imageSize) {
                                            case "SMALL":
                                            case "MEDIUM":
                                                return thumbnailUrl(pictureModel);
                                            case "LARGE":
                                                return hdThumbnailUrl(pictureModel);
                                            }
                                        }

                                        function hdCategoryImage(pictureModel) {
                                            var imageSize = "MEDIUM";
                                            var browserWidth = document.body.clientWidth;
                                            switch (imageSize) {
                                            case "SMALL":
                                                if (browserWidth < 520) {
                                                    return hdThumbnailUrl(pictureModel);
                                                }
                                                return thumbnailUrl(pictureModel);
                                            case "MEDIUM":
                                                return hdThumbnailUrl(pictureModel);
                                            case "LARGE":
                                                if (browserWidth < 1060) {
                                                    return hdThumbnailUrl(pictureModel);
                                                }
                                                return mainImageUrl(pictureModel)
                                            }
                                        }

                                        function hdThumbnailUrl(pictureModel) {
                                            var urls = [pictureModel.hdThumbnailUrl, pictureModel.mainImageUrl, pictureModel.originalImageUrl, pictureModel.pictureUrl];

                                            return EcStaticPageUtils.findFirstNotEmpty(urls);
                                        }

                                        function mainImageUrl(pictureModel) {
                                            var urls = [pictureModel.mainImageUrl, pictureModel.originalImageUrl, pictureModel.pictureUrl];

                                            return EcStaticPageUtils.findFirstNotEmpty(urls);
                                        }

                                        function thumbnailUrl(pictureModel) {
                                            if (pictureModel.pictureWidth < sizeBorder && pictureModel.pictureHeight < sizeBorder) {
                                                return hdThumbnailUrl(pictureModel);
                                            } else {
                                                return pictureModel.pictureUrl;
                                            }
                                        }

                                        function process() {
                                            var categoryImageElements = document.querySelectorAll('.grid-category__image');

                                            if (categoryImageElements.length !== categoryPicturesData.length) {
                                                return;
                                            }

                                            categoryPicturesData.forEach(function(item, i) {
                                                var categoryImageUrl = categoryImage(item);
                                                var hdCategoryImageUrl = hdCategoryImage(item);
                                                var categoryPictureElement = categoryImageElements[i].querySelector('.grid-category__picture');
                                                var categoryBgImageElement = categoryImageElements[i].querySelector('.grid-category__bg-image');

                                                setBackgroundImageStyle(categoryPictureElement, categoryImageUrl, hdCategoryImageUrl);
                                                setBackgroundImageStyle(categoryBgImageElement, categoryImageUrl, hdCategoryImageUrl);
                                            });
                                        }

                                        function onResize() {
                                            if (document.body.clientWidth !== lastWidth) {
                                                lastWidth = document.body.clientWidth;
                                                process();
                                            }
                                        }

                                        window.addEventListener("resize", onResize);
                                        process();
                                    }
                                    )();

                                    (function() {

                                        window.ec = window.ec || {};
                                        if (window.ec.static_category_evaluated === true) {
                                            return;
                                        }
                                        window.ec.static_category_evaluated = true;

                                        var Grid = function() {
                                            var params = {
                                                productListImageSize: "MEDIUM",
                                                categoryImageSize: "MEDIUM",
                                                productCellSpacing: "",
                                                categoryCellSpacing: ""
                                            };
                                            var settings = {
                                                productBreakpoints: {
                                                    LARGE: [0, 680, 1060, 1440, 10000],
                                                    MEDIUM: [0, 260, 680, 1060, 1370, 1700, 10000],
                                                    SMALL: [0, 260, 520, 680, 870, 1060, 1280, 1450, 1750, 10000]
                                                },
                                                categoryBreakpoints: {
                                                    LARGE: [0, 680, 1060, 1440, 10000],
                                                    MEDIUM: [0, 480, 680, 1060, 1370, 1700, 10000],
                                                    SMALL: [0, 390, 520, 680, 870, 1060, 1280, 1450, 1750, 10000]
                                                }
                                            };

                                            function setAttributes(grids, breakpoints) {
                                                if (!grids) {
                                                    return;
                                                }
                                                grids.forEach(function(grid) {
                                                    var w = grid.offsetWidth;
                                                    var columnCount = 0;
                                                    for (var i = 1; i <= breakpoints.length; i++) {
                                                        if (w < Math.ceil(breakpoints[i])) {
                                                            if (i !== columnCount) {
                                                                columnCount = i;
                                                                grid.setAttribute('data-cols', i);
                                                            }
                                                            break;
                                                        }
                                                    }
                                                });
                                            }

                                            function checkProductGridsLayout() {
                                                var productGrids = document.querySelectorAll('.grid__products');
                                                var productBreakpoints = settings.productBreakpoints[params.productListImageSize];
                                                setAttributes(productGrids, productBreakpoints);
                                            }

                                            function checkCategoryGridsLayout() {
                                                var categoryGrids = document.querySelectorAll('.grid__categories');
                                                var categoryBreakpoints = settings.categoryBreakpoints[params.categoryImageSize];
                                                setAttributes(categoryGrids, categoryBreakpoints);
                                            }

                                            function checkLayout() {
                                                checkProductGridsLayout();
                                                checkCategoryGridsLayout();
                                            }

                                            function setCellInterval(p, c) {
                                                var style = document.getElementById('customCss') || document.createElement('div');
                                                style.id = 'customCss';
                                                document.body.appendChild(style);

                                                var css = '';
                                                if (+p == p && p != "") {
                                                    p = +p;
                                                    css += '.ec-size .ec-store .grid__products { margin-left: -' + Math.max(0, p / 2 - .4) + 'px; margin-right: -' + p / 2 + 'px; }';
                                                    css += '.ec-size .ec-store .grid__products .grid-product__wrap { padding: ' + p / 2 + 'px; }';

                                                    css += '.ec-size:not(.ec-size--s) .ec-store .grid__products { margin-left: -' + Math.max(0, Math.min(16, p) / 2 - .4) + 'px; margin-right: -' + Math.min(16, p) / 2 + 'px; }';
                                                    css += '.ec-size:not(.ec-size--s) .ec-store .grid__products .grid-product__wrap { padding: ' + Math.min(16, p) / 2 + 'px; }';
                                                }

                                                if (+c == c && c != "") {
                                                    c = +c;
                                                    css += '.ec-size .ec-store .grid__categories { margin-left: -' + Math.max(0, c / 2 - .4) + 'px; margin-right: -' + c / 2 + 'px; }';
                                                    css += '.ec-size .ec-store .grid-category__wrap { padding: ' + c / 2 + 'px; }';

                                                    css += '.ec-size:not(.ec-size--s) .ec-store .grid__categories { margin-left: -' + Math.max(0, Math.min(16, c) / 2 - .4) + 'px; margin-right: -' + Math.min(16, c) / 2 + 'px; }';
                                                    css += '.ec-size:not(.ec-size--s) .ec-store .grid__categories .grid-category__wrap { padding: ' + Math.min(16, c) / 2 + 'px; }';
                                                }

                                                style.innerHTML = '<style>' + css + '</style>';
                                            }

                                            function init() {
                                                setCellInterval(params.productCellSpacing, params.categoryCellSpacing);
                                                checkLayout();
                                                window.addEventListener('resize', function() {
                                                    checkLayout();
                                                });
                                            }

                                            init();
                                        };

                                        var ecwidContainer = document.querySelector('.ec-static-container .ec-size');
                                        var breakpoints = {
                                            320: 'ec-size--xxs',
                                            414: 'ec-size--xs',
                                            480: 'ec-size--s',
                                            768: 'ec-size--m',
                                            1024: 'ec-size--l',
                                            1100: 'ec-size--xl',
                                            1440: 'ec-size--xxl'
                                        };

                                        function onResize() {
                                            var w = ecwidContainer.offsetWidth;
                                            for (var i in breakpoints) {
                                                if (w >= i) {
                                                    ecwidContainer.classList.add(breakpoints[i]);
                                                } else {
                                                    ecwidContainer.classList.remove(breakpoints[i]);
                                                }
                                            }
                                        }
                                        onResize();
                                        window.addEventListener('load', onResize);
                                        window.addEventListener('resize', onResize);

                                        var links = document.querySelectorAll(".ec-static-container a");
                                        for (var i = 0; i < links.length; i++) {
                                            var link = links[i];
                                            link.addEventListener('click', function() {
                                                document.querySelector('.ec-static-container').classList.add("ec-static-container__wait");
                                            })
                                        }

                                        var grid = new Grid();

                                    }
                                    )();
                                </script>
                            </div>
                            <div class="border"></div>
                        </div>
                        <div id="main" class="store dynamic-product-browser" data-block="store">
                            <div>
                                <div id="ecwid-products"></div>
                            </div>
                            <div class="border"></div>
                        </div>
                        <script>
                            if (window.location.pathname.match(/^.*-p\d+$/)) {
                                var pb = document.querySelector('#ecwid-products');
                                if (pb) {
                                    var timeLimit = 3000;
                                    var waiter = setInterval(function() {
                                        var distPbTopToPageBottom = document.body.clientHeight - pb.offsetTop;
                                        if (distPbTopToPageBottom >= window.innerHeight) {
                                            clearInterval(waiter);
                                            pb.scrollIntoView();
                                        }
                                        timeLimit -= 20;
                                        if (timeLimit <= 0)
                                            clearInterval(waiter);
                                    }, 20);
                                }
                            }
                        </script>
                    </div>
                </div>
                <div class="tile tile-info">
                    <div class="whyus" data-block="whyus">
                        <div>
                            <h2>Why Choose Us?</h2>
                            <div class="description">
                                <p style="font-family: Phetsarath OT;">ປະດິດ​ສ້າງ, ນຳພາ, ​ເສີມ​ຂະຫຍາຍ, ສະໜອງ​ຜະລິດ​ຕະພັນ ​ແລະ ການ​ບໍລິການ​ທີ່​ມີ​ຄຸນ​ຄ່າ​ດີ​ທີ່​ສຸດ​ໃຫ້​ແກ່​ລູກ​ຄ້າ​ທົ່ວ​ໂລກ.ເພື່ອສ້າງຄວາມແຕກຕ່າງໂດຍຜ່ານການສ້າງຕາສິນຄ້າຂອງພວກເຮົາໃຫ້ຢູ່ຂ້າງຫນ້າຂອງແນວໂນ້ມຄົນອັບເດດ:, ການປ່ຽນແປງຂອງຕະຫຼາດແລະເຕັກໂນໂລຢີຫລ້າສຸດ.​ເພື່ອ​ຍົກ​ສູງ​ຄຸນ​ນະພາ​ບຊີວິດ​ຂອງ​ຄູ່​ຮ່ວມ​ທຸລະ​ກິດ, ລູກ​ຄ້າ ​ແລະ ພະນັກງານ​ຂອງ​ພວກ​ເຮົາ.</p>
                                <p></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tile tile-reviews">
                    <div class="quote" data-block="quote">
                        <div class="reviews" data-items="3">
                            <div class="reviews__item review" data-key="1">
                                <div class="review__quote">
                                    <svg viewBox="0 0 32 26" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.578 3.28c-1.47.845-2.656 1.572-3.562 2.18-.907.61-1.828 1.415-2.766 2.415-.875.938-1.547 1.922-2.016 2.953-.468 1.03-.796 2.36-.984 3.985H7.5c1.938 0 3.46.476 4.57 1.43 1.11.952 1.664 2.35 1.664 4.195 0 1.312-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.687 0-4.61-.883-5.765-2.648C1.28 21.414.702 19.094.702 16.22c0-2.033.438-3.884 1.313-5.556C2.89 8.992 3.953 7.5 5.203 6.188c1.28-1.344 2.64-2.485 4.078-3.422 1.44-.938 2.642-1.703 3.61-2.297l1.688 2.81zm17.344 0c-1.47.845-2.656 1.572-3.563 2.18-.907.61-1.83 1.415-2.766 2.415-.907.97-1.586 1.96-2.04 2.977-.452 1.015-.773 2.335-.96 3.96h2.25c1.937 0 3.46.477 4.57 1.43 1.11.953 1.664 2.352 1.664 4.195 0 1.313-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.688 0-4.61-.882-5.766-2.647-1.155-1.766-1.733-4.086-1.733-6.96 0-2.033.437-3.884 1.312-5.556.874-1.672 1.937-3.164 3.187-4.476 1.28-1.344 2.64-2.485 4.078-3.422 1.438-.938 2.64-1.703 3.61-2.297l1.687 2.81z" fill-rule="evenodd"></path>
                                    </svg>
                                </div>
                                <div class="review__desc">
                                    <p style="font-family: Phetsarath OT;">ເຄື່ອງຕົງປົກ ຕາມທີ່ສັ່ງເລີຍ</p>
                                    <p></p>
                                </div>
                                <div class="review__avatar">
                                    <img src="https://d1howb1wwyap5o.cloudfront.net/startersite/mdemo/quote-portrait.jpg" alt="" class="keep-dimensions">
                                    <div class="review__quote">
                                        <svg viewBox="0 0 32 26" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M14.578 3.28c-1.47.845-2.656 1.572-3.562 2.18-.907.61-1.828 1.415-2.766 2.415-.875.938-1.547 1.922-2.016 2.953-.468 1.03-.796 2.36-.984 3.985H7.5c1.938 0 3.46.476 4.57 1.43 1.11.952 1.664 2.35 1.664 4.195 0 1.312-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.687 0-4.61-.883-5.765-2.648C1.28 21.414.702 19.094.702 16.22c0-2.033.438-3.884 1.313-5.556C2.89 8.992 3.953 7.5 5.203 6.188c1.28-1.344 2.64-2.485 4.078-3.422 1.44-.938 2.642-1.703 3.61-2.297l1.688 2.81zm17.344 0c-1.47.845-2.656 1.572-3.563 2.18-.907.61-1.83 1.415-2.766 2.415-.907.97-1.586 1.96-2.04 2.977-.452 1.015-.773 2.335-.96 3.96h2.25c1.937 0 3.46.477 4.57 1.43 1.11.953 1.664 2.352 1.664 4.195 0 1.313-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.688 0-4.61-.882-5.766-2.647-1.155-1.766-1.733-4.086-1.733-6.96 0-2.033.437-3.884 1.312-5.556.874-1.672 1.937-3.164 3.187-4.476 1.28-1.344 2.64-2.485 4.078-3.422 1.438-.938 2.64-1.703 3.61-2.297l1.687 2.81z" fill-rule="evenodd"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="review__author">
                                    <div class="review__author-name" style="font-family: Phetsarath OT;">ປະທ່ານ ບໍລິສັດ Dev</div>
                                    <div class="review__author-title"></div>
                                </div>
                            </div>
                            <div class="reviews__item review" data-key="2">
                                <div class="review__quote">
                                    <svg viewBox="0 0 32 26" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.578 3.28c-1.47.845-2.656 1.572-3.562 2.18-.907.61-1.828 1.415-2.766 2.415-.875.938-1.547 1.922-2.016 2.953-.468 1.03-.796 2.36-.984 3.985H7.5c1.938 0 3.46.476 4.57 1.43 1.11.952 1.664 2.35 1.664 4.195 0 1.312-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.687 0-4.61-.883-5.765-2.648C1.28 21.414.702 19.094.702 16.22c0-2.033.438-3.884 1.313-5.556C2.89 8.992 3.953 7.5 5.203 6.188c1.28-1.344 2.64-2.485 4.078-3.422 1.44-.938 2.642-1.703 3.61-2.297l1.688 2.81zm17.344 0c-1.47.845-2.656 1.572-3.563 2.18-.907.61-1.83 1.415-2.766 2.415-.907.97-1.586 1.96-2.04 2.977-.452 1.015-.773 2.335-.96 3.96h2.25c1.937 0 3.46.477 4.57 1.43 1.11.953 1.664 2.352 1.664 4.195 0 1.313-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.688 0-4.61-.882-5.766-2.647-1.155-1.766-1.733-4.086-1.733-6.96 0-2.033.437-3.884 1.312-5.556.874-1.672 1.937-3.164 3.187-4.476 1.28-1.344 2.64-2.485 4.078-3.422 1.438-.938 2.64-1.703 3.61-2.297l1.687 2.81z" fill-rule="evenodd"></path>
                                    </svg>
                                </div>
                                <div class="review__desc">
                                    <p style="font-family: Phetsarath OT;">ການ​ບໍ​ລິ​ການ​ດີ, ການ​ຂົນ​ສົ່ງ​ໄວ​, ແລະ​ລາ​ຄາ​ທີ່​ເຫມາະ​ສົມ​ຫຼາຍ​ສໍາ​ລັບ​ຜະ​ລິດ​ຕະ​ພັນ​ທີ່​ມີ​ຄຸນ​ນະ​ພາບ​ດັ່ງ​ກ່າວ​!</p>
                                    <p></p>
                                </div>
                                <div class="review__avatar">
                                    <img src="https://d1howb1wwyap5o.cloudfront.net/startersite/mdemo/photo-2.jpg" alt="" class="keep-dimensions">
                                    <div class="review__quote">
                                        <svg viewBox="0 0 32 26" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M14.578 3.28c-1.47.845-2.656 1.572-3.562 2.18-.907.61-1.828 1.415-2.766 2.415-.875.938-1.547 1.922-2.016 2.953-.468 1.03-.796 2.36-.984 3.985H7.5c1.938 0 3.46.476 4.57 1.43 1.11.952 1.664 2.35 1.664 4.195 0 1.312-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.687 0-4.61-.883-5.765-2.648C1.28 21.414.702 19.094.702 16.22c0-2.033.438-3.884 1.313-5.556C2.89 8.992 3.953 7.5 5.203 6.188c1.28-1.344 2.64-2.485 4.078-3.422 1.44-.938 2.642-1.703 3.61-2.297l1.688 2.81zm17.344 0c-1.47.845-2.656 1.572-3.563 2.18-.907.61-1.83 1.415-2.766 2.415-.907.97-1.586 1.96-2.04 2.977-.452 1.015-.773 2.335-.96 3.96h2.25c1.937 0 3.46.477 4.57 1.43 1.11.953 1.664 2.352 1.664 4.195 0 1.313-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.688 0-4.61-.882-5.766-2.647-1.155-1.766-1.733-4.086-1.733-6.96 0-2.033.437-3.884 1.312-5.556.874-1.672 1.937-3.164 3.187-4.476 1.28-1.344 2.64-2.485 4.078-3.422 1.438-.938 2.64-1.703 3.61-2.297l1.687 2.81z" fill-rule="evenodd"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="review__author">
                                    <div class="review__author-name" style="font-family: Phetsarath OT;">ເຊັບ ມົງໂກ</div>
                                    <div class="review__author-title" style="font-family: Phetsarath OT;">ຂົ້ວຕັບແມງວັນ</div>
                                </div>
                            </div>
                            <div class="reviews__item review" data-key="3">
                                <div class="review__quote">
                                    <svg viewBox="0 0 32 26" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.578 3.28c-1.47.845-2.656 1.572-3.562 2.18-.907.61-1.828 1.415-2.766 2.415-.875.938-1.547 1.922-2.016 2.953-.468 1.03-.796 2.36-.984 3.985H7.5c1.938 0 3.46.476 4.57 1.43 1.11.952 1.664 2.35 1.664 4.195 0 1.312-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.687 0-4.61-.883-5.765-2.648C1.28 21.414.702 19.094.702 16.22c0-2.033.438-3.884 1.313-5.556C2.89 8.992 3.953 7.5 5.203 6.188c1.28-1.344 2.64-2.485 4.078-3.422 1.44-.938 2.642-1.703 3.61-2.297l1.688 2.81zm17.344 0c-1.47.845-2.656 1.572-3.563 2.18-.907.61-1.83 1.415-2.766 2.415-.907.97-1.586 1.96-2.04 2.977-.452 1.015-.773 2.335-.96 3.96h2.25c1.937 0 3.46.477 4.57 1.43 1.11.953 1.664 2.352 1.664 4.195 0 1.313-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.688 0-4.61-.882-5.766-2.647-1.155-1.766-1.733-4.086-1.733-6.96 0-2.033.437-3.884 1.312-5.556.874-1.672 1.937-3.164 3.187-4.476 1.28-1.344 2.64-2.485 4.078-3.422 1.438-.938 2.64-1.703 3.61-2.297l1.687 2.81z" fill-rule="evenodd"></path>
                                    </svg>
                                </div>
                                <div class="review__desc">
                                    <p style="font-family: Phetsarath OT;">ຄຸນະພາບຂອງຜະລິດຕະພັນແມ່ນດີເລີດ. ການຂົນສົ່ງແມ່ນໄວ. ການບໍລິການລູກຄ້າແມ່ນ AMAZING. ດ້ວຍຄວາມຊື່ສັດຂ້ອຍບໍ່ສາມາດແນະນໍາໃຫ້ພວກເຂົາພຽງພໍ.</p>
                                    <p></p>
                                </div>
                                <div class="review__avatar">
                                    <img src="https://d1howb1wwyap5o.cloudfront.net/startersite/mdemo/photo-3.jpg" alt="" class="keep-dimensions">
                                    <div class="review__quote">
                                        <svg viewBox="0 0 32 26" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M14.578 3.28c-1.47.845-2.656 1.572-3.562 2.18-.907.61-1.828 1.415-2.766 2.415-.875.938-1.547 1.922-2.016 2.953-.468 1.03-.796 2.36-.984 3.985H7.5c1.938 0 3.46.476 4.57 1.43 1.11.952 1.664 2.35 1.664 4.195 0 1.312-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.687 0-4.61-.883-5.765-2.648C1.28 21.414.702 19.094.702 16.22c0-2.033.438-3.884 1.313-5.556C2.89 8.992 3.953 7.5 5.203 6.188c1.28-1.344 2.64-2.485 4.078-3.422 1.44-.938 2.642-1.703 3.61-2.297l1.688 2.81zm17.344 0c-1.47.845-2.656 1.572-3.563 2.18-.907.61-1.83 1.415-2.766 2.415-.907.97-1.586 1.96-2.04 2.977-.452 1.015-.773 2.335-.96 3.96h2.25c1.937 0 3.46.477 4.57 1.43 1.11.953 1.664 2.352 1.664 4.195 0 1.313-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.688 0-4.61-.882-5.766-2.647-1.155-1.766-1.733-4.086-1.733-6.96 0-2.033.437-3.884 1.312-5.556.874-1.672 1.937-3.164 3.187-4.476 1.28-1.344 2.64-2.485 4.078-3.422 1.438-.938 2.64-1.703 3.61-2.297l1.687 2.81z" fill-rule="evenodd"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="review__author">
                                    <div class="review__author-name" style="font-family: Phetsarath OT;">ອະແມນດ້າ</div>
                                    <div class="review__author-title" style="font-family: Phetsarath OT;">ລໍຊໍ</div>
                                </div>
                            </div>
                            <div class="reviews__item review hidden" data-key="4">
                                <div class="review__quote">
                                    <svg viewBox="0 0 32 26" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.578 3.28c-1.47.845-2.656 1.572-3.562 2.18-.907.61-1.828 1.415-2.766 2.415-.875.938-1.547 1.922-2.016 2.953-.468 1.03-.796 2.36-.984 3.985H7.5c1.938 0 3.46.476 4.57 1.43 1.11.952 1.664 2.35 1.664 4.195 0 1.312-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.687 0-4.61-.883-5.765-2.648C1.28 21.414.702 19.094.702 16.22c0-2.033.438-3.884 1.313-5.556C2.89 8.992 3.953 7.5 5.203 6.188c1.28-1.344 2.64-2.485 4.078-3.422 1.44-.938 2.642-1.703 3.61-2.297l1.688 2.81zm17.344 0c-1.47.845-2.656 1.572-3.563 2.18-.907.61-1.83 1.415-2.766 2.415-.907.97-1.586 1.96-2.04 2.977-.452 1.015-.773 2.335-.96 3.96h2.25c1.937 0 3.46.477 4.57 1.43 1.11.953 1.664 2.352 1.664 4.195 0 1.313-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.688 0-4.61-.882-5.766-2.647-1.155-1.766-1.733-4.086-1.733-6.96 0-2.033.437-3.884 1.312-5.556.874-1.672 1.937-3.164 3.187-4.476 1.28-1.344 2.64-2.485 4.078-3.422 1.438-.938 2.64-1.703 3.61-2.297l1.687 2.81z" fill-rule="evenodd"></path>
                                    </svg>
                                </div>
                                <div class="review__desc"></div>
                                <div class="review__avatar empty">
                                    <img src="" alt="" class="keep-dimensions">
                                    <div class="review__quote">
                                        <svg viewBox="0 0 32 26" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M14.578 3.28c-1.47.845-2.656 1.572-3.562 2.18-.907.61-1.828 1.415-2.766 2.415-.875.938-1.547 1.922-2.016 2.953-.468 1.03-.796 2.36-.984 3.985H7.5c1.938 0 3.46.476 4.57 1.43 1.11.952 1.664 2.35 1.664 4.195 0 1.312-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.687 0-4.61-.883-5.765-2.648C1.28 21.414.702 19.094.702 16.22c0-2.033.438-3.884 1.313-5.556C2.89 8.992 3.953 7.5 5.203 6.188c1.28-1.344 2.64-2.485 4.078-3.422 1.44-.938 2.642-1.703 3.61-2.297l1.688 2.81zm17.344 0c-1.47.845-2.656 1.572-3.563 2.18-.907.61-1.83 1.415-2.766 2.415-.907.97-1.586 1.96-2.04 2.977-.452 1.015-.773 2.335-.96 3.96h2.25c1.937 0 3.46.477 4.57 1.43 1.11.953 1.664 2.352 1.664 4.195 0 1.313-.492 2.54-1.476 3.68-.985 1.14-2.336 1.71-4.055 1.71-2.688 0-4.61-.882-5.766-2.647-1.155-1.766-1.733-4.086-1.733-6.96 0-2.033.437-3.884 1.312-5.556.874-1.672 1.937-3.164 3.187-4.476 1.28-1.344 2.64-2.485 4.078-3.422 1.438-.938 2.64-1.703 3.61-2.297l1.687 2.81z" fill-rule="evenodd"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="review__author">
                                    <div class="review__author-name"></div>
                                    <div class="review__author-title"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tile tile-about">
                    <div class="owner" data-block="owner">
                        <div>
                            <h2>About Us</h2>
                            <div class="author">
                                <div class="avatar">
                                    <img src="https://d2j6dbq0eux0bg.cloudfront.net/startersite/images/83623760/1673497807871.jpg" alt="" class="keep-dimensions">
                                </div>
                                <p class="name">NK-Shop</p>
                                <p class="title">2023-2024</p>
                            </div>
                            <div class="description">
                                <p style="font-family: Phetsarath OT;">ແນະນຳສັ້ນໆ&nbsp;ຮ້ານ NK-Shop</p>
                                <p></p>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                            <div class="cb"></div>
                        </div>
                    </div>
                </div>
                <div class="tile tile-location">
                    <div class="location process-it" data-block="location">
                        <div>
                            <h2>Location</h2>
                            <div class="layout">
                                <div class="frame">
                                    <iframe id="google-map" class="google-map" data-base="https://www.google.com/maps/embed/v1/place?key=AIzaSyCNCmAGyN4bJYu5qeLgbASzZafm-M5TA_o&language=en&zoom=16&q=" data-address="Dongdok%20National%20University%20Hostel" allowfullscreen title='Location on map'></iframe>
                                </div>
                                <div class="text">
                                    <div class="description">
                                        <p style="font-family: Phetsarath OT;">ຮ້ານເຮົາຢູ່ ມະຫາວິທາຍາໄລແຫ່ງຊາດ/ນະຄອນຫລວງວຽງຈັນ&nbsp;</p>
                                        <p></p>
                                        <p></p>
                                    </div>
                                    <div class="columns">
                                        <div class="column address">
                                            <p class="title">Address</p>
                                            <p class="address">Dongdok National University Hostel</p>
                                            <div class="ec-size ec-size--xl">
                                                <div class="ec-store">
                                                    <div class="form-control form-control--button form-control--secondary btn-get-direction">
                                                        <a class="form-control__button" href="https://www.google.com/maps/dir/?api=1&destination=Dongdok%20National%20University%20Hostel" target="_blank">
                                                            <span class="form-control__button-text">
                                                                <span>Get Directions</span>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column schedule">
                                            <p class="day" style="font-family: Phetsarath OT;">ຈັນ-ສຸກ</p>
                                            <p class="hour">9:00-20:00</p>
                                            <p class="day" style="font-family: Phetsarath OT;">ເສົາ</p>
                                            <p class="hour">10:30 -17:00</p>
                                            <p class="day" style="font-family: Phetsarath OT;">ອາທິດ</p>
                                            <p class="hour" style="font-family: Phetsarath OT;">ປິດ</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="contacts" class="tile tile-contactInfo">
                    <div class="contacts process-it" data-block="contacts">
                        <div>
                            <h2>Contact us</h2>
                            <div class="data">
                                <div>
                                    <div class="phone value" data-type="phone">
                                        <a href="tel:2097467996">
                                            <span class="icon">
                                                <svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M13.332 11.426l-2.16-2.166c-.234-.232-.63-.225-.883.03l-1.357 1.357-.33-.182-.215-.12c-1.193-.663-1.882-1.13-2.732-1.983-.85-.854-1.315-1.54-1.982-2.743-.06-.11-.085-.155-.114-.205l-.19-.33.27-.27.73-.732.36-.36c.255-.256.262-.655.03-.888L2.598.668c-.23-.232-.628-.225-.88.03l-.55.54c-.186.275-.33.54-.433.802-.102.27-.165.525-.194.783-.263 2.19.75 4.225 3.59 7.07 1.724 1.728 3.414 2.77 5 3.278.555.18 1.057.277 1.5.314.267.023.455.02.554.01.267-.033.52-.097.778-.197.276-.108.534-.255.722-.4l.62-.582c.253-.255.26-.655.028-.89zM4.615 5.254l-.267.267-.354-.353.435-.247.12.216c.02.04.043.08.065.118z" stroke="#999" fill-rule="nonzero" fill="none"/>
                                                </svg>
                                            </span>
                                            <span class="text">20 9746 7996</span>
                                        </a>
                                    </div>
                                </div>
                                <div>
                                    <div class="email value" data-type="email">
                                        <a href="mailto:nluangphet@gmail.com">
                                            <span class="icon">
                                                <svg width="16" height="12" viewBox="0 0 16 12" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M2 0h12c1.105 0 2 .895 2 2v8c0 1.105-.895 2-2 2H2c-1.105 0-2-.895-2-2V2C0 .895.895 0 2 0zm0 1c-.552 0-1 .448-1 1v8c0 .552.448 1 1 1h12c.552 0 1-.448 1-1V2c0-.552-.448-1-1-1H2zm.817 1.114L8 6.368l5.183-4.254c.213-.176.528-.145.703.07.176.212.145.527-.07.702L8.317 7.4c-.183.152-.45.152-.633 0l-5.5-4.514c-.214-.175-.245-.49-.07-.703.176-.214.49-.245.704-.07z" fill-rule="nonzero" fill="#999"/>
                                                </svg>
                                            </span>
                                            <span class="text">nchanthaphavong55@gmail.com</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <h3>Connect with us</h3>
                            </div>
                            <div class="channels" role="region" aria-label="Connect with us">
                                <div>
                                    <div class="facebook">
                                        <div class="logo">
                                            <a data-title="Facebook" href="https://facebook.com/profile.php?id=100082826786770&mibextid=ZbWKwL" target="_blank" rel="noopener noreferrer nofollow">
                                                <span>Facebook</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tile tile-footer">
                    <div class="footer footer-new" data-block="footer">
                        <div>
                            <div class="ec-likely ec-likely_visible">
                                <div class="ec-likely__wrapper">
                                    <a class="ec-likely__widget ec-likely__widget_facebook" onclick="trackElementClick('button [fromStorefront - footer - facebook]')" href="https://facebook.com/sharer/sharer.php?u=https%3A%2F%2Fnakhin.company.site%2F">
                                        <span class="ec-likely__icon ec-likely__icon--facebook">
                                            <svg height="16" viewBox="0 0 16 16" width="16" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M13 0H3C1 0 0 1 0 3v10c0 2 1 3 3 3h5V9H6V7h2V5c0-2 2-2 2-2h3v2h-3v2h3l-.5 2H10v7h3c2 0 3-1 3-3V3c0-2-1-3-3-3z"></path>
                                            </svg>
                                        </span>
                                        <span class="ec-likely__button ec-likely__button--facebook">Share</span>
                                    </a>
                                    <a class="ec-likely__widget ec-likely__widget_twitter" onclick="trackElementClick('button [fromStorefront - footer - twitter]')" href="https://twitter.com/intent/tweet/?url=https%3A%2F%2Fnakhin.company.site%2F&text=Welcom+to+NK-Shop:">
                                        <span class="ec-likely__icon ec-likely__icon--twitter">
                                            <svg height="16" viewBox="0 0 16 16" width="16" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M15.96 3.42c-.04.153-.144.31-.237.414l-.118.058v.118l-.59.532-.237.295c-.05.036-.398.21-.413.237V6.49h-.06v.473h-.058v.294h-.058v.296h-.06v.235h-.06v.237h-.058c-.1.355-.197.71-.295 1.064h-.06v.116h-.06c-.02.1-.04.197-.058.296h-.06c-.04.118-.08.237-.118.355h-.06c-.038.118-.078.236-.117.353l-.118.06-.06.235-.117.06v.116l-.118.06v.12h-.06c-.02.057-.038.117-.058.175l-.118.06v.117c-.06.04-.118.08-.177.118v.118l-.237.177v.118l-.59.53-.532.592h-.117c-.06.078-.118.156-.177.236l-.177.06-.06.117h-.118l-.06.118-.176.06v.058h-.118l-.06.118-.353.12-.06.117c-.078.02-.156.04-.235.058v.06c-.118.038-.236.078-.354.118v.058H8.76v.06h-.12v.06h-.176v.058h-.118v.06H8.17v.058H7.99v.06l-.413.058v.06h-.237c-.667.22-1.455.293-2.36.293h-.886v-.058h-.53v-.06H3.27v-.06h-.295v-.06H2.68v-.057h-.177v-.06h-.236v-.058H2.09v-.06h-.177v-.058h-.177v-.06H1.56v-.058h-.12v-.06l-.294-.06v-.057c-.118-.04-.236-.08-.355-.118v-.06H.674v-.058H.555v-.06H.437v-.058H.32l-.06-.12H.142v-.058c-.13-.08-.083.026-.177-.118H1.56v-.06c.294-.04.59-.077.884-.117v-.06h.177v-.058h.237v-.06h.118v-.06h.177v-.057h.118v-.06h.177v-.058l.236-.06v-.058l.236-.06c.02-.038.04-.078.058-.117l.237-.06c.02-.04.04-.077.058-.117h.118l.06-.118h.118c.036-.025.047-.078.118-.118V12.1c-1.02-.08-1.84-.54-2.303-1.183-.08-.058-.157-.118-.236-.176v-.117l-.118-.06v-.117c-.115-.202-.268-.355-.296-.65.453.004.987.008 1.354-.06v-.06c-.254-.008-.47-.08-.65-.175v-.058H2.32v-.06c-.08-.02-.157-.04-.236-.058l-.06-.118h-.117l-.118-.178h-.12c-.077-.098-.156-.196-.235-.294l-.118-.06v-.117l-.177-.12c-.35-.502-.6-1.15-.59-2.006h.06c.204.234.948.377 1.357.415v-.06c-.257-.118-.676-.54-.827-.768V5.9l-.118-.06c-.04-.117-.08-.236-.118-.354h-.06v-.118H.787c-.04-.196-.08-.394-.118-.59-.06-.19-.206-.697-.118-1.005h.06V3.36h.058v-.177h.06v-.177h.057V2.83h.06c.04-.118.078-.236.117-.355h.118v.06c.12.097.237.196.355.295v.118l.118.058c.08.098.157.197.236.295l.176.06.354.413h.118l.177.236h.118l.06.117h.117c.04.06.08.118.118.177h.118l.06.118.235.06.06.117.356.12.06.117.53.176v.06h.118v.058l.236.06v.06c.118.02.236.04.355.058v.06h.177v.058h.177v.06h.176v.058h.236v.06l.472.057v.06l1.417.18v-.237c-.1-.112-.058-.442-.057-.65 0-.573.15-.99.354-1.358v-.117l.118-.06.06-.235.176-.118v-.118c.14-.118.276-.236.414-.355l.06-.117h.117l.12-.177.235-.06.06-.117h.117v-.058H9.7v-.058h.177v-.06h.177v-.058h.177v-.06h.296v-.058h1.063v.058h.294v.06h.177v.058h.178v.06h.177v.058h.118v.06h.118l.06.117c.08.018.158.038.236.058.04.06.08.118.118.177h.118l.06.117c.142.133.193.163.472.178.136-.12.283-.05.472-.118v-.06h.177v-.058h.177v-.06l.236-.058v-.06h.177l.59-.352v.176h-.058l-.06.295h-.058v.117h-.06v.118l-.117.06v.118l-.177.118v.117l-.118.06-.354.412h-.117l-.177.236h.06c.13-.112.402-.053.59-.117l1.063-.353z"></path>
                                            </svg>
                                        </span>
                                        <span class="ec-likely__button ec-likely__button--twitter">Tweet</span>
                                    </a>
                                    <a class="ec-likely__widget ec-likely__widget_pinterest" onclick="trackElementClick('button [fromStorefront - footer - pinterest]')" href="https://pinterest.com/pin/create/button/?url=https%3A%2F%2Fnakhin.company.site%2F&description=Welcom+to+NK-Shop&media=https%3A%2F%2Fd2j6dbq0eux0bg.cloudfront.net%2Fimages%2F83623760%2F3414811819.jpg">
                                        <span class="ec-likely__icon ec-likely__icon--pinterest">
                                            <svg height="16" viewBox="0 0 16 16" width="16" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7.99 0c-4.417 0-8 3.582-8 8 0 3.39 2.11 6.284 5.086 7.45-.07-.633-.133-1.604.028-2.295.145-.624.938-3.977.938-3.977s-.24-.48-.24-1.188c0-1.112.645-1.943 1.448-1.943.683 0 1.012.512 1.012 1.127 0 .686-.437 1.713-.663 2.664-.19.796.398 1.446 1.184 1.446 1.422 0 2.515-1.5 2.515-3.664 0-1.915-1.377-3.255-3.343-3.255-2.276 0-3.612 1.707-3.612 3.472 0 .688.265 1.425.595 1.826.065.08.075.15.055.23-.06.252-.195.796-.222.907-.035.146-.116.177-.268.107-1-.465-1.624-1.926-1.624-3.1 0-2.523 1.835-4.84 5.287-4.84 2.775 0 4.932 1.977 4.932 4.62 0 2.757-1.74 4.976-4.152 4.976-.81 0-1.573-.42-1.834-.92l-.498 1.903c-.18.695-.668 1.566-.994 2.097.75.232 1.544.357 2.37.357 4.417 0 8-3.582 8-8s-3.583-8-8-8z"></path>
                                            </svg>
                                        </span>
                                        <span class="ec-likely__button ec-likely__button--pinterest">Pin</span>
                                    </a>
                                </div>
                            </div>
                            <ul class="legal-links" id="ecwid-starter-site-links"></ul>
                            <div class="copyright">
                                <span class="copyright__store">
                                    <span class="copyright__sign">&copy;</span>
                                    <span class="copyright__year"></span>
                                    <span class="copyright__text">NK-Store Online</span>
                                </span>
                                <span class="copyright__abuse-report">
                                    <a href="mailto:abuse@company.site?subject=Complaint against store: SID 83623760&body=SID 83623760, https://nakhin.company.site" target="_blank">Report abuse</a>
                                </span>
                            </div>
                            <a class="logo" href="http://www.ecwid.com?utm_source=startersite&utm_medium=powered-by-link&utm_campaign=stores" target="_blank">
                                <span>Powered by</span>
                                <div>
                                    <svg width="92" height="28" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 477" fill="currentColor">
                                        <path d="M574.2 371.7c3.1-5 7-8.8 11.8-11.4 4.8-2.7 10.1-4 15.8-4 6 0 11.4 1.1 16.1 3.3 4.7 2.2 8.8 5.3 12.1 9.4 3.3 4.1 5.9 8.9 7.7 14.6 1.8 5.7 2.7 11.9 2.7 18.8 0 6.3-.9 12.3-2.6 17.9-1.8 5.6-4.3 10.5-7.6 14.7-3.3 4.2-7.3 7.5-12 9.8-4.7 2.4-9.9 3.6-15.7 3.6-7.2 0-13.2-1.4-17.8-4.2-4.6-2.8-8.1-6.3-10.5-10.6v12.9h-13.9V327.8h13.9v43.9zm25.4-3.6c-7.7 0-13.9 2.9-18.7 8.8-4.8 5.9-7.2 14.5-7.2 25.9 0 5.7.7 10.6 2 14.8 1.4 4.2 3.2 7.7 5.5 10.5s5.1 4.8 8.2 6.2c3.2 1.4 6.5 2 10.2 2 8 0 14.5-3.1 19.3-9.2 4.9-6.1 7.3-14.4 7.3-24.8 0-10.6-2.2-19-6.7-25.2-4.4-5.9-11-9-19.9-9zM697.3 451.2c-1.2 3.7-2.6 7.1-4.1 10.3-1.5 3.1-3.3 5.8-5.6 8.1s-5 4-8.2 5.3c-3.2 1.2-7.2 1.9-11.8 1.9-3.8 0-7.1-.3-9.8-1v-10.9c1.6.2 2.8.3 3.7.3h3.6c3.3 0 6-.4 8.1-1.2 2.1-.8 3.9-2 5.3-3.5s2.6-3.5 3.5-5.9c.9-2.4 1.8-5.1 2.7-8.1h-4.6L649 358.1h15.1l25.6 77.5 23.2-77.5h14.4l-30 93.1zM797 433.6h55.3v12.9h-69.4V327.8H797v105.8zM875 325.4c2.5 0 4.6.9 6.4 2.6 1.8 1.8 2.7 3.9 2.7 6.4 0 2.6-.9 4.8-2.7 6.5-1.8 1.8-4 2.6-6.4 2.6-2.6 0-4.8-.9-6.6-2.6-1.8-1.7-2.7-3.9-2.7-6.5 0-2.5.9-4.6 2.7-6.4 1.8-1.7 4-2.6 6.6-2.6zm6.9 121.1H868v-88.3h13.9v88.3zM982.5 364.8c-3.3 0-6 .3-8.2.8-2.2.5-4.3 1.4-6.2 2.8 1.9 2.4 3.4 5 4.3 7.9 1 2.9 1.4 5.9 1.4 9.1 0 4.3-.9 8.1-2.5 11.5-1.7 3.4-4.1 6.3-7.2 8.7s-6.9 4.3-11.3 5.6c-4.4 1.3-9.3 1.9-14.8 1.9-3.3 0-6.5-.3-9.6-.9-3.1-.6-6.1-1.5-8.9-2.8-1.1 1.1-2.1 2.3-2.8 3.6-.7 1.3-1.1 2.6-1.1 3.8 0 2.9.9 5.1 2.8 6.6s4.9 2.2 9.2 2.2h18.5c6.3 0 11.7.7 16.1 1.9 4.4 1.3 8 3.1 10.7 5.3 2.7 2.2 4.7 4.8 5.9 7.9 1.2 3.1 1.9 6.3 1.9 9.7 0 7.9-3.6 14.3-10.9 19.1-7.3 4.8-17.4 7.2-30.3 7.2-7.4 0-13.6-.6-18.7-1.9-5.1-1.2-9.3-2.9-12.5-5.1-3.2-2.2-5.5-4.7-6.9-7.5-1.4-2.9-2.1-6-2.1-9.4 0-8 4.6-14.2 13.7-18.7-6.4-3.1-9.7-7.9-9.7-14.4 0-5.3 3-10.1 9-14.4-3.2-2.4-5.7-5.2-7.5-8.6-1.8-3.3-2.7-7.1-2.7-11.4 0-3.8.7-7.5 2.2-11 1.5-3.5 3.7-6.6 6.7-9.2 3-2.7 6.7-4.8 11.1-6.4 4.4-1.6 9.5-2.4 15.4-2.4 4.8 0 9 .5 12.7 1.4 3.7 1 7.1 2.3 10 4 4.6-6.2 12-9.3 22-9.3v12.4zM923 437c-4.2 2.3-7 4.5-8.5 6.8s-2.2 4.7-2.2 7.3c0 4.5 2 8.1 6.1 10.8 4.1 2.7 11.2 4.1 21.4 4.1 9 0 15.9-1.4 20.5-4.1 4.6-2.7 7-6.4 7-11 0-2.3-.4-4.3-1.2-6-.8-1.7-2.1-3.2-4.1-4.4-1.9-1.2-4.5-2.1-7.7-2.6-3.2-.6-7.3-.8-12.1-.8H923zm15.1-70.2c-7.3 0-12.9 1.7-16.6 5.1-3.7 3.4-5.6 7.7-5.6 13.1 0 5.5 1.9 9.9 5.8 13.1 3.8 3.2 9.2 4.7 16.1 4.7 7.2 0 12.8-1.6 16.6-4.7 3.8-3.1 5.8-7.5 5.8-13.1 0-5.4-1.8-9.8-5.3-13.1-3.7-3.4-9.3-5.1-16.8-5.1zM1011.1 371.7c2.9-4.9 6.8-8.6 11.5-11.4 4.8-2.7 10-4.1 15.8-4.1 9.9 0 17.5 3 22.6 9 5.1 6 7.7 14.3 7.7 24.9v56.3h-13.9v-52.9c0-3.7-.3-7.2-.9-10.3-.6-3.2-1.7-5.8-3.1-8.1-1.5-2.2-3.4-3.9-5.9-5.2-2.5-1.2-5.6-1.9-9.3-1.9-3.4 0-6.6.7-9.5 2-2.9 1.4-5.5 3.3-7.7 5.8s-4 5.5-5.3 9.2c-1.3 3.6-2 7.7-2 12.2v49.2h-13.9V327.8h13.9v43.9zM1109 358.1h24.8v10.7H1109v54.1c0 4.3.9 7.7 2.7 10.1 1.8 2.4 5.3 3.6 10.3 3.6 2.6 0 5.1-.2 7.6-.7 2.5-.4 4.7-1 6.6-1.5v11.2c-2.3.8-4.8 1.4-7.7 1.9-2.9.5-6 .8-9.2.8-4.6 0-8.5-.6-11.5-1.8-3.1-1.2-5.5-2.8-7.5-4.9-1.9-2.1-3.3-4.6-4.1-7.5-.8-2.9-1.2-6-1.2-9.4v-55.9h-12.6v-10.7h12.6v-23.6h13.9v23.6zM1183.9 356.3c7.8 0 14.5 1.2 20.2 3.5 5.7 2.3 10.5 5.5 14.6 9.4l-8.3 8.3c-3.4-3-7.3-5.4-11.7-7.1-4.4-1.7-9.3-2.5-14.8-2.5-6.4 0-11.4 1.2-14.8 3.6-3.4 2.4-5.2 5.4-5.2 9.2 0 2 .4 3.8 1.2 5.3.8 1.5 2.1 2.8 4 3.9s4.3 2.1 7.4 2.9c3.1.8 6.9 1.5 11.5 2.2 5.4.9 10.2 2 14.2 3.3 4.1 1.3 7.5 3 10.3 5.1 2.8 2.1 4.9 4.6 6.4 7.6 1.4 3 2.1 6.6 2.1 10.9 0 3.8-.8 7.4-2.4 10.6-1.6 3.2-4 6-7.1 8.4-3.2 2.4-7.1 4.2-11.7 5.6-4.6 1.4-10 2-16.1 2-8.5 0-16.1-1.3-22.7-4-6.7-2.7-12.2-6.4-16.6-11.1l9-8.8c3.6 4 8 7 13.1 9.1 5.1 2.1 10.8 3.1 16.9 3.1 8 0 13.9-1.4 17.7-4.1 3.8-2.7 5.7-6.2 5.7-10.3 0-2.1-.4-4-1.1-5.7-.7-1.6-2.1-3.1-4.1-4.3-2-1.2-4.7-2.3-8.1-3.3-3.4-1-7.7-1.8-13.1-2.6-10.6-1.7-18.4-4.6-23.2-8.7-4.9-4.1-7.3-9.6-7.3-16.4 0-3.8.8-7.3 2.5-10.3 1.6-3.1 3.9-5.7 6.9-7.8 2.9-2.2 6.5-3.8 10.7-5 4.2-1.4 8.8-2 13.9-2zM1280.2 356.3c5.9 0 11.2 1.1 15.9 3.4 4.7 2.3 8.8 5.4 12 9.4 3.3 4 5.8 8.8 7.6 14.4 1.8 5.6 2.7 11.7 2.7 18.2 0 6.4-.8 12.5-2.5 18.2-1.7 5.7-4.2 10.7-7.5 14.8-3.3 4.2-7.4 7.5-12.1 9.9s-10.2 3.6-16.3 3.6c-6.6 0-12.2-1.3-16.9-4-4.7-2.7-8.3-6.2-10.9-10.8v40.2h-13.7V358.1h13.7v13.2c3-4.7 7-8.4 11.9-11.1 4.9-2.6 10.2-3.9 16.1-3.9zm-2.2 11.8c-7.8 0-14.1 2.9-18.9 8.7-4.8 5.8-7.2 14.3-7.2 25.5 0 5.9.7 11 2 15.3 1.4 4.3 3.2 7.8 5.5 10.6s5 4.8 8.1 6.2c3.1 1.4 6.5 2 10.1 2 8 0 14.5-3.1 19.3-9.2 4.9-6.1 7.3-14.6 7.3-25.6 0-5-.6-9.5-1.7-13.6s-2.8-7.7-5-10.6c-2.2-2.9-5-5.2-8.2-6.9-3.2-1.5-7-2.4-11.3-2.4zM1373.5 356.3c6.3 0 11.9 1.2 16.8 3.6s9 5.7 12.3 9.8c3.3 4.1 5.9 9 7.5 14.6 1.7 5.6 2.5 11.5 2.5 17.7v3.2h-65.8c.2 9.9 2.8 17.7 7.6 23.1 4.9 5.5 11.8 8.2 20.7 8.2 6 0 11-1.3 15.2-3.9 4.1-2.6 7.4-6 9.9-10.2l11.5 6.3c-4 6.2-9 11.1-15.2 14.5-6.2 3.4-13.5 5.2-22 5.2-6.8 0-12.8-1.2-18.1-3.6-5.3-2.4-9.7-5.7-13.2-9.8-3.6-4.1-6.2-9-8.1-14.7-1.8-5.7-2.7-11.7-2.7-18.1 0-6.4.9-12.5 2.6-18.1 1.8-5.6 4.3-10.5 7.7-14.6 3.4-4.1 7.6-7.4 12.7-9.7 5.4-2.3 11.3-3.5 18.1-3.5zm-.4 11.5c-7.9 0-14.1 2.5-18.6 7.4-4.5 4.9-7 11.4-7.5 19.4h51.2c-.6-8.1-3-14.6-7.2-19.5s-10.2-7.3-17.9-7.3zM1467.1 356.3c6.3 0 11.9 1.2 16.8 3.6s9 5.7 12.3 9.8c3.3 4.1 5.9 9 7.5 14.6 1.7 5.6 2.5 11.5 2.5 17.7v3.2h-65.8c.2 9.9 2.8 17.7 7.6 23.1 4.9 5.5 11.8 8.2 20.7 8.2 6 0 11-1.3 15.2-3.9 4.1-2.6 7.4-6 9.9-10.2l11.5 6.3c-4 6.2-9 11.1-15.2 14.5-6.2 3.4-13.5 5.2-22 5.2-6.8 0-12.8-1.2-18.1-3.6s-9.7-5.7-13.2-9.8c-3.6-4.1-6.2-9-8.1-14.7-1.8-5.7-2.7-11.7-2.7-18.1 0-6.4.9-12.5 2.6-18.1 1.8-5.6 4.3-10.5 7.7-14.6 3.4-4.1 7.6-7.4 12.7-9.7 5.4-2.3 11.3-3.5 18.1-3.5zm-.4 11.5c-7.9 0-14.1 2.5-18.6 7.4-4.5 4.9-7 11.4-7.5 19.4h51.2c-.6-8.1-3-14.6-7.2-19.5s-10.2-7.3-17.9-7.3zM1600 446.5h-13.9v-13.6c-2.9 4.9-6.9 8.6-11.8 11.4-4.9 2.7-10.3 4.1-16.2 4.1-6 0-11.4-1.1-16.1-3.4-4.7-2.3-8.8-5.4-12-9.4-3.3-4-5.8-8.8-7.6-14.4-1.7-5.6-2.6-11.7-2.6-18.4 0-6.7.9-12.8 2.7-18.5s4.4-10.6 7.7-14.8c3.3-4.2 7.4-7.4 12.2-9.7s10.2-3.5 16.2-3.5c6.7 0 12.3 1.3 16.8 4s8.1 6.1 10.7 10.4v-42.9h13.9v118.7zm-39.3-78.4c-8.5 0-15 3.1-19.6 9.2-4.6 6.1-6.9 14.5-6.9 25.1 0 10.6 2.2 19 6.5 25s10.9 9.1 19.8 9.1c7.7 0 14-2.9 18.8-8.6 4.9-5.8 7.3-14.4 7.3-25.8 0-5.7-.7-10.6-2-14.8-1.4-4.2-3.2-7.8-5.5-10.6s-5.1-4.9-8.2-6.4c-3.2-1.4-6.6-2.2-10.2-2.2z"/>
                                        <g>
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M345.1 0H101.6C45.5 0 0 45.5 0 101.6v243.6c0 56.1 45.5 101.6 101.6 101.6h243.6c56.1 0 101.6-45.5 101.6-101.6V101.6C446.7 45.5 401.2 0 345.1 0zm-65.8 120.2c11.1 0 20.2 9 20.2 20.2 0 11.1-9 20.2-20.2 20.2s-20.2-9-20.2-20.2 9.1-20.2 20.2-20.2zm0 56.9c11.1 0 20.2 9 20.2 20.2 0 11.1-9 20.2-20.2 20.2s-20.2-9-20.2-20.2 9.1-20.2 20.2-20.2zm-56.8-56.9c11.1 0 20.2 9 20.2 20.2 0 11.1-9 20.2-20.2 20.2s-20.2-9-20.2-20.2 9.1-20.2 20.2-20.2zm0 56.9c11.1 0 20.2 9 20.2 20.2 0 11.1-9 20.2-20.2 20.2s-20.2-9-20.2-20.2 9.1-20.2 20.2-20.2zm-56.8-56.9c11.1 0 20.2 9 20.2 20.2 0 11.1-9 20.2-20.2 20.2-11.1 0-20.2-9-20.2-20.2s9.1-20.2 20.2-20.2zm0 56.9c11.1 0 20.2 9 20.2 20.2 0 11.1-9 20.2-20.2 20.2-11.1 0-20.2-9-20.2-20.2s9.1-20.2 20.2-20.2zM111.1 390c-21.3 0-38.5-17.3-38.5-38.5 0-21.3 17.3-38.6 38.5-38.6 21.3 0 38.6 17.3 38.6 38.6S132.4 390 111.1 390zm222.7 1.7c-21.3 0-38.5-17.3-38.5-38.5 0-21.3 17.3-38.6 38.5-38.6 21.3 0 38.6 17.3 38.6 38.6s-17.3 38.5-38.6 38.5zm67.8-313.5-39.8 148.4c-10.6 39.6-44.2 64.5-85.2 64.5h-26.3c-8.7 0-21.3-4.7-26.5-9.6-.9-.8-2.2-.8-3.1 0-5.2 4.9-17.8 9.6-26.5 9.6h-28.9c-39.7 0-69.8-22.6-81.9-60.5L49.5 124.4c-.7-2.1-.3-4.4 1-6.2 1.3-1.8 3.3-2.8 5.6-2.8h6.5c15.6.1 29.3 10.1 34 25l24.9 78.2c6.7 21.2 28.3 35.4 50.5 35.4h9.7c10 0 17-5.1 21.2-9.7 2.2-2.4 5.3-3.8 8.5-3.8h21.7c3.1 0 6.1 1.2 8.1 3.5 4.1 4.5 11.4 10 21.5 10h9.2c22.9 0 45.2-15.5 51.2-37.6l32.3-120.2c4.2-15.6 18.4-26.6 34.6-26.6h5.7c.5 0 1.1.1 1.6.3 3.5 1.5 5.1 5.1 4.3 8.3z"/>
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M333.8 339.4c-7.6 0-13.8 6.2-13.8 13.8s6.2 13.8 13.8 13.8c7.6 0 13.8-6.2 13.8-13.8.1-7.6-6.1-13.8-13.8-13.8zM111.1 337.6c-7.6 0-13.8 6.2-13.8 13.8s6.2 13.8 13.8 13.8c7.6 0 13.8-6.2 13.8-13.8 0-7.6-6.2-13.8-13.8-13.8z"/>
                                        </g>
                                        <g>
                                            <path d="M972.8 217.1c-7.1 0-14.9-.3-18.3 5.9-10.8 19.5-35.5 25.7-55.8 25.7-40.3 0-71-32.8-71-73s30.6-73 71-73c17.9 0 41.2 3.5 55.1 24.4 3.9 5.9 11.7 4.6 18.8 4.6 10 0 7.6-11.9 3.7-17.8C956.2 83.4 923 77 898.8 77c-54.5 0-98.9 44.3-98.9 98.7s44.4 98.7 98.9 98.7c35.3 0 65.6-15.2 79.2-39.8 3.3-6.2 5.3-17.5-5.2-17.5zM1344.3 82c-7.1 0-12.9 3.1-12.9 10.2v170.4c0 7.1 5.8 9.3 12.9 9.3 7.1 0 12.9-2.2 12.9-9.3V92.2c-.1-7.1-5.8-10.2-12.9-10.2zM1344.3 0c-9 0-16.3 7.3-16.3 16.3s7.3 16.3 16.3 16.3 16.3-7.3 16.3-16.3S1353.3 0 1344.3 0zM1271.4 83h-.8s-12.1 0-15.8 9.2c-3.5 8.9-22.9 69.8-43.4 129.1-.7 1.9-1.5 3.8-2.2 5.7l-44-110.6c-2-4.7-4.9-8.3-8.7-10.4-2.2-1.3-4.6-2.2-7.7-2.2h-.2c-3 0-5.5.9-7.7 2.2-3.8 2.1-6.7 5.7-8.7 10.4l-44 110.6c-.7-1.9-1.5-3.8-2.2-5.7-20.6-59.8-39.8-120.2-43.4-129.1-3.7-9.2-16.3-9.2-16.6-9.2-6.5.1-9.1 1.8-8.9 6 0 1 0 2 .4 3.2 1 3.8 31.8 97.6 56.9 168.8 1.6 4.6 5.2 11.2 13.5 11.2 5.5 0 9.6-3.7 11.1-7.4l47.1-120c.5-1.1 1.5-1.6 2.5-1.7 1 0 2 .6 2.5 1.7l47.1 120c1.5 3.8 5.9 7.4 11.1 7.4 8.5 0 12-6.6 13.5-11.2 23.5-71.5 55.9-165.1 56.9-168.8.3-1.2.4-2.3.4-3.2.3-4.2-2.2-5.9-8.7-6zM560.3 261.4c0 6 4.8 10.8 10.8 10.8h191.6c6.9 0 9.9-6 9.9-13.4s-3-13.4-9.9-13.4H594c-2.8 0-5.1-2.3-5.1-5.1v-95.5h147.5c6.9 0 9.9-6 9.9-13.4s-3-13.4-9.9-13.4H588.9V32.2c0-3 2.4-5.4 5.4-5.4h168.5c6.9 0 9.9-6 9.9-13.4S769.6 0 762.7 0H571.1c-6 0-10.8 4.8-10.8 10.8v250.6zM1587.1 0c-7.1 0-12.9 3.1-12.9 10.2v99c-14.6-23.9-42.9-32.1-67.8-32.1-54.5 0-98.8 44.3-98.8 98.6s44.3 98.6 98.8 98.6c21.3 0 54.4-10.6 67.8-33.8v21.8c0 .3 0 .4.1.4.3 6.6 5.9 8.8 12.8 8.8 7.1 0 12.9-2.2 12.9-9.3v-252c0-7.1-5.8-10.2-12.9-10.2zm-80.6 248.7c-40.3 0-70.6-32.7-70.6-73s30.3-73 70.6-73c23.4 0 67.4 14 67.8 66.1v11.8c-.4 51.4-46.7 68.1-67.8 68.1z"/>
                                        </g>
                                    </svg>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            if ('serviceWorker'in navigator) {
                var controller = navigator.serviceWorker.controller;
                if (controller && controller.state == 'activated') {
                    document.body.classList.remove('loading');
                    document.body.classList.add('sw-activated');
                }
            }
        </script>
        <script data-cfasync="false">
            var $jscomp = {
                scope: {},
                getGlobal: function(a) {
                    return "undefined" != typeof window && window === a ? a : "undefined" != typeof global ? global : a
                }
            };
            $jscomp.global = $jscomp.getGlobal(this);
            $jscomp.initSymbol = function() {
                $jscomp.global.Symbol || ($jscomp.global.Symbol = $jscomp.Symbol);
                $jscomp.initSymbol = function() {}
            }
            ;
            $jscomp.symbolCounter_ = 0;
            $jscomp.Symbol = function(a) {
                return "jscomp_symbol_" + a + $jscomp.symbolCounter_++
            }
            ;
            $jscomp.initSymbolIterator = function() {
                $jscomp.initSymbol();
                $jscomp.global.Symbol.iterator || ($jscomp.global.Symbol.iterator = $jscomp.global.Symbol("iterator"));
                $jscomp.initSymbolIterator = function() {}
            }
            ;
            $jscomp.makeIterator = function(a) {
                $jscomp.initSymbolIterator();
                if (a[$jscomp.global.Symbol.iterator])
                    return a[$jscomp.global.Symbol.iterator]();
                if (!(a instanceof Array || "string" == typeof a || a instanceof String))
                    throw new TypeError(a + " is not iterable");
                var b = 0;
                return {
                    next: function() {
                        return b == a.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: a[b++]
                        }
                    }
                }
            }
            ;
            $jscomp.arrayFromIterator = function(a) {
                for (var b, c = []; !(b = a.next()).done; )
                    c.push(b.value);
                return c
            }
            ;
            $jscomp.arrayFromIterable = function(a) {
                return a instanceof Array ? a : $jscomp.arrayFromIterator($jscomp.makeIterator(a))
            }
            ;
            $jscomp.arrayFromArguments = function(a) {
                for (var b = [], c = 0; c < a.length; c++)
                    b.push(a[c]);
                return b
            }
            ;
            $jscomp.inherits = function(a, b) {
                function c() {}
                c.prototype = b.prototype;
                a.prototype = new c;
                a.prototype.constructor = a;
                for (var d in b)
                    if ($jscomp.global.Object.defineProperties) {
                        var e = $jscomp.global.Object.getOwnPropertyDescriptor(b, d);
                        $jscomp.global.Object.defineProperty(a, d, e)
                    } else
                        a[d] = b[d]
            }
            ;
            $jscomp.array = $jscomp.array || {};
            $jscomp.array.done_ = function() {
                return {
                    done: !0,
                    value: void 0
                }
            }
            ;
            $jscomp.array.arrayIterator_ = function(a, b) {
                a instanceof String && (a = String(a));
                var c = 0;
                $jscomp.initSymbol();
                $jscomp.initSymbolIterator();
                var d = {}
                  , e = (d.next = function() {
                    if (c < a.length) {
                        var d = c++;
                        return {
                            value: b(d, a[d]),
                            done: !1
                        }
                    }
                    e.next = $jscomp.array.done_;
                    return $jscomp.array.done_()
                }
                ,
                d[Symbol.iterator] = function() {
                    return e
                }
                ,
                d);
                return e
            }
            ;
            $jscomp.array.findInternal_ = function(a, b, c) {
                a instanceof String && (a = String(a));
                for (var d = a.length, e = 0; e < d; e++) {
                    var g = a[e];
                    if (b.call(c, g, e, a))
                        return {
                            i: e,
                            v: g
                        }
                }
                return {
                    i: -1,
                    v: void 0
                }
            }
            ;
            $jscomp.array.from = function(a, b, c) {
                b = void 0 === b ? function(a) {
                    return a
                }
                : b;
                var d = [];
                $jscomp.initSymbol();
                $jscomp.initSymbolIterator();
                if (a[Symbol.iterator]) {
                    $jscomp.initSymbol();
                    $jscomp.initSymbolIterator();
                    a = a[Symbol.iterator]();
                    for (var e; !(e = a.next()).done; )
                        d.push(b.call(c, e.value))
                } else {
                    e = a.length;
                    for (var g = 0; g < e; g++)
                        d.push(b.call(c, a[g]))
                }
                return d
            }
            ;
            $jscomp.array.of = function(a) {
                for (var b = [], c = 0; c < arguments.length; ++c)
                    b[c - 0] = arguments[c];
                return $jscomp.array.from(b)
            }
            ;
            $jscomp.array.entries = function() {
                return $jscomp.array.arrayIterator_(this, function(a, b) {
                    return [a, b]
                })
            }
            ;
            $jscomp.array.entries$install = function() {
                Array.prototype.entries || (Array.prototype.entries = $jscomp.array.entries)
            }
            ;
            $jscomp.array.keys = function() {
                return $jscomp.array.arrayIterator_(this, function(a) {
                    return a
                })
            }
            ;
            $jscomp.array.keys$install = function() {
                Array.prototype.keys || (Array.prototype.keys = $jscomp.array.keys)
            }
            ;
            $jscomp.array.values = function() {
                return $jscomp.array.arrayIterator_(this, function(a, b) {
                    return b
                })
            }
            ;
            $jscomp.array.values$install = function() {
                Array.prototype.values || (Array.prototype.values = $jscomp.array.values)
            }
            ;
            $jscomp.array.copyWithin = function(a, b, c) {
                var d = this.length;
                a = Number(a);
                b = Number(b);
                c = Number(null != c ? c : d);
                if (a < b)
                    for (c = Math.min(c, d); b < c; )
                        b in this ? this[a++] = this[b++] : (delete this[a++],
                        b++);
                else
                    for (c = Math.min(c, d + b - a),
                    a += c - b; c > b; )
                        --c in this ? this[--a] = this[c] : delete this[a];
                return this
            }
            ;
            $jscomp.array.copyWithin$install = function() {
                Array.prototype.copyWithin || (Array.prototype.copyWithin = $jscomp.array.copyWithin)
            }
            ;
            $jscomp.array.fill = function(a, b, c) {
                null != c && a.length || (c = this.length || 0);
                c = Number(c);
                for (b = Number((void 0 === b ? 0 : b) || 0); b < c; b++)
                    this[b] = a;
                return this
            }
            ;
            $jscomp.array.fill$install = function() {
                Array.prototype.fill || (Array.prototype.fill = $jscomp.array.fill)
            }
            ;
            $jscomp.array.find = function(a, b) {
                return $jscomp.array.findInternal_(this, a, b).v
            }
            ;
            $jscomp.array.find$install = function() {
                Array.prototype.find || (Array.prototype.find = $jscomp.array.find)
            }
            ;
            $jscomp.array.findIndex = function(a, b) {
                return $jscomp.array.findInternal_(this, a, b).i
            }
            ;
            $jscomp.array.findIndex$install = function() {
                Array.prototype.findIndex || (Array.prototype.findIndex = $jscomp.array.findIndex)
            }
            ;
            $jscomp.Map = function(a) {
                a = void 0 === a ? [] : a;
                this.data_ = {};
                this.head_ = $jscomp.Map.createHead_();
                this.size = 0;
                if (a) {
                    a = $jscomp.makeIterator(a);
                    for (var b = a.next(); !b.done; b = a.next())
                        b = b.value,
                        this.set(b[0], b[1])
                }
            }
            ;
            $jscomp.Map.checkBrowserConformance_ = function() {
                var a = $jscomp.global.Map;
                if (!a || !a.prototype.entries || !Object.seal)
                    return !1;
                try {
                    var b = Object.seal({
                        x: 4
                    })
                      , c = new a($jscomp.makeIterator([[b, "s"]]));
                    if ("s" != c.get(b) || 1 != c.size || c.get({
                        x: 4
                    }) || c.set({
                        x: 4
                    }, "t") != c || 2 != c.size)
                        return !1;
                    var d = c.entries()
                      , e = d.next();
                    if (e.done || e.value[0] != b || "s" != e.value[1])
                        return !1;
                    e = d.next();
                    return e.done || 4 != e.value[0].x || "t" != e.value[1] || !d.next().done ? !1 : !0
                } catch (g) {
                    return !1
                }
            }
            ;
            $jscomp.Map.createHead_ = function() {
                var a = {};
                return a.previous = a.next = a.head = a
            }
            ;
            $jscomp.Map.getId_ = function(a) {
                if (!(a instanceof Object))
                    return String(a);
                $jscomp.Map.key_ in a || a instanceof Object && Object.isExtensible && Object.isExtensible(a) && $jscomp.Map.defineProperty_(a, $jscomp.Map.key_, ++$jscomp.Map.index_);
                return $jscomp.Map.key_ in a ? a[$jscomp.Map.key_] : " " + a
            }
            ;
            $jscomp.Map.prototype.set = function(a, b) {
                var c = this.maybeGetEntry_(a)
                  , d = c.id
                  , e = c.list
                  , c = c.entry;
                e || (e = this.data_[d] = []);
                c ? c.value = b : (c = {
                    next: this.head_,
                    previous: this.head_.previous,
                    head: this.head_,
                    key: a,
                    value: b
                },
                e.push(c),
                this.head_.previous.next = c,
                this.head_.previous = c,
                this.size++);
                return this
            }
            ;
            $jscomp.Map.prototype["delete"] = function(a) {
                var b = this.maybeGetEntry_(a);
                a = b.id;
                var c = b.list
                  , d = b.index;
                return (b = b.entry) && c ? (c.splice(d, 1),
                c.length || delete this.data_[a],
                b.previous.next = b.next,
                b.next.previous = b.previous,
                b.head = null,
                this.size--,
                !0) : !1
            }
            ;
            $jscomp.Map.prototype.clear = function() {
                this.data_ = {};
                this.head_ = this.head_.previous = $jscomp.Map.createHead_();
                this.size = 0
            }
            ;
            $jscomp.Map.prototype.has = function(a) {
                return !!this.maybeGetEntry_(a).entry
            }
            ;
            $jscomp.Map.prototype.get = function(a) {
                return (a = this.maybeGetEntry_(a).entry) && a.value
            }
            ;
            $jscomp.Map.prototype.maybeGetEntry_ = function(a) {
                var b = $jscomp.Map.getId_(a)
                  , c = this.data_[b];
                if (c)
                    for (var d = 0; d < c.length; d++) {
                        var e = c[d];
                        if (a !== a && e.key !== e.key || a === e.key)
                            return {
                                id: b,
                                list: c,
                                index: d,
                                entry: e
                            }
                    }
                return {
                    id: b,
                    list: c,
                    index: -1,
                    entry: void 0
                }
            }
            ;
            $jscomp.Map.prototype.entries = function() {
                return this.iter_(function(a) {
                    return [a.key, a.value]
                })
            }
            ;
            $jscomp.Map.prototype.keys = function() {
                return this.iter_(function(a) {
                    return a.key
                })
            }
            ;
            $jscomp.Map.prototype.values = function() {
                return this.iter_(function(a) {
                    return a.value
                })
            }
            ;
            $jscomp.Map.prototype.forEach = function(a, b) {
                for (var c = $jscomp.makeIterator(this.entries()), d = c.next(); !d.done; d = c.next())
                    d = d.value,
                    a.call(b, d[1], d[0], this)
            }
            ;
            $jscomp.Map.prototype.iter_ = function(a) {
                var b = this
                  , c = this.head_;
                $jscomp.initSymbol();
                $jscomp.initSymbolIterator();
                var d = {};
                return d.next = function() {
                    if (c) {
                        for (; c.head != b.head_; )
                            c = c.previous;
                        for (; c.next != c.head; )
                            return c = c.next,
                            {
                                done: !1,
                                value: a(c)
                            };
                        c = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                }
                ,
                d[Symbol.iterator] = function() {
                    return this
                }
                ,
                d
            }
            ;
            $jscomp.Map.index_ = 0;
            $jscomp.Map.defineProperty_ = Object.defineProperty ? function(a, b, c) {
                Object.defineProperty(a, b, {
                    value: String(c)
                })
            }
            : function(a, b, c) {
                a[b] = String(c)
            }
            ;
            $jscomp.Map.Entry_ = function() {}
            ;
            $jscomp.Map.ASSUME_NO_NATIVE = !1;
            $jscomp.Map$install = function() {
                $jscomp.initSymbol();
                $jscomp.initSymbolIterator();
                !$jscomp.Map.ASSUME_NO_NATIVE && $jscomp.Map.checkBrowserConformance_() ? $jscomp.Map = $jscomp.global.Map : ($jscomp.initSymbol(),
                $jscomp.initSymbolIterator(),
                $jscomp.Map.prototype[Symbol.iterator] = $jscomp.Map.prototype.entries,
                $jscomp.initSymbol(),
                $jscomp.Map.key_ = Symbol("map-id-key"));
                $jscomp.Map$install = function() {}
            }
            ;
            $jscomp.math = $jscomp.math || {};
            $jscomp.math.clz32 = function(a) {
                a = Number(a) >>> 0;
                if (0 === a)
                    return 32;
                var b = 0;
                0 === (a & 4294901760) && (a <<= 16,
                b += 16);
                0 === (a & 4278190080) && (a <<= 8,
                b += 8);
                0 === (a & 4026531840) && (a <<= 4,
                b += 4);
                0 === (a & 3221225472) && (a <<= 2,
                b += 2);
                0 === (a & 2147483648) && b++;
                return b
            }
            ;
            $jscomp.math.imul = function(a, b) {
                a = Number(a);
                b = Number(b);
                var c = a & 65535
                  , d = b & 65535;
                return c * d + ((a >>> 16 & 65535) * d + c * (b >>> 16 & 65535) << 16 >>> 0) | 0
            }
            ;
            $jscomp.math.sign = function(a) {
                a = Number(a);
                return 0 === a || isNaN(a) ? a : 0 < a ? 1 : -1
            }
            ;
            $jscomp.math.log10 = function(a) {
                return Math.log(a) / Math.LN10
            }
            ;
            $jscomp.math.log2 = function(a) {
                return Math.log(a) / Math.LN2
            }
            ;
            $jscomp.math.log1p = function(a) {
                a = Number(a);
                if (.25 > a && -.25 < a) {
                    for (var b = a, c = 1, d = a, e = 0, g = 1; e != d; )
                        b *= a,
                        g *= -1,
                        d = (e = d) + g * b / ++c;
                    return d
                }
                return Math.log(1 + a)
            }
            ;
            $jscomp.math.expm1 = function(a) {
                a = Number(a);
                if (.25 > a && -.25 < a) {
                    for (var b = a, c = 1, d = a, e = 0; e != d; )
                        b *= a / ++c,
                        d = (e = d) + b;
                    return d
                }
                return Math.exp(a) - 1
            }
            ;
            $jscomp.math.cosh = function(a) {
                a = Number(a);
                return (Math.exp(a) + Math.exp(-a)) / 2
            }
            ;
            $jscomp.math.sinh = function(a) {
                a = Number(a);
                return 0 === a ? a : (Math.exp(a) - Math.exp(-a)) / 2
            }
            ;
            $jscomp.math.tanh = function(a) {
                a = Number(a);
                if (0 === a)
                    return a;
                var b = Math.exp(2 * -Math.abs(a))
                  , b = (1 - b) / (1 + b);
                return 0 > a ? -b : b
            }
            ;
            $jscomp.math.acosh = function(a) {
                a = Number(a);
                return Math.log(a + Math.sqrt(a * a - 1))
            }
            ;
            $jscomp.math.asinh = function(a) {
                a = Number(a);
                if (0 === a)
                    return a;
                var b = Math.log(Math.abs(a) + Math.sqrt(a * a + 1));
                return 0 > a ? -b : b
            }
            ;
            $jscomp.math.atanh = function(a) {
                a = Number(a);
                return ($jscomp.math.log1p(a) - $jscomp.math.log1p(-a)) / 2
            }
            ;
            $jscomp.math.hypot = function(a, b, c) {
                for (var d = [], e = 2; e < arguments.length; ++e)
                    d[e - 2] = arguments[e];
                a = Number(a);
                b = Number(b);
                for (var g = Math.max(Math.abs(a), Math.abs(b)), k = $jscomp.makeIterator(d), e = k.next(); !e.done; e = k.next())
                    g = Math.max(g, Math.abs(e.value));
                if (1E100 < g || 1E-100 > g) {
                    a /= g;
                    b /= g;
                    k = a * a + b * b;
                    d = $jscomp.makeIterator(d);
                    for (e = d.next(); !e.done; e = d.next())
                        e = e.value,
                        e = Number(e) / g,
                        k += e * e;
                    return Math.sqrt(k) * g
                }
                g = a * a + b * b;
                d = $jscomp.makeIterator(d);
                for (e = d.next(); !e.done; e = d.next())
                    e = e.value,
                    g += e * e;
                return Math.sqrt(g)
            }
            ;
            $jscomp.math.trunc = function(a) {
                a = Number(a);
                if (isNaN(a) || Infinity === a || -Infinity === a || 0 === a)
                    return a;
                var b = Math.floor(Math.abs(a));
                return 0 > a ? -b : b
            }
            ;
            $jscomp.math.cbrt = function(a) {
                if (0 === a)
                    return a;
                a = Number(a);
                var b = Math.pow(Math.abs(a), 1 / 3);
                return 0 > a ? -b : b
            }
            ;
            $jscomp.number = $jscomp.number || {};
            $jscomp.number.isFinite = function(a) {
                return "number" !== typeof a ? !1 : !isNaN(a) && Infinity !== a && -Infinity !== a
            }
            ;
            $jscomp.number.isInteger = function(a) {
                return $jscomp.number.isFinite(a) ? a === Math.floor(a) : !1
            }
            ;
            $jscomp.number.isNaN = function(a) {
                return "number" === typeof a && isNaN(a)
            }
            ;
            $jscomp.number.isSafeInteger = function(a) {
                return $jscomp.number.isInteger(a) && Math.abs(a) <= $jscomp.number.MAX_SAFE_INTEGER
            }
            ;
            $jscomp.number.EPSILON = Math.pow(2, -52);
            $jscomp.number.MAX_SAFE_INTEGER = 9007199254740991;
            $jscomp.number.MIN_SAFE_INTEGER = -9007199254740991;
            $jscomp.object = $jscomp.object || {};
            $jscomp.object.assign = function(a, b) {
                for (var c = [], d = 1; d < arguments.length; ++d)
                    c[d - 1] = arguments[d];
                c = $jscomp.makeIterator(c);
                for (d = c.next(); !d.done; d = c.next()) {
                    var d = d.value, e;
                    for (e in d)
                        Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
                }
                return a
            }
            ;
            $jscomp.object.is = function(a, b) {
                return a === b ? 0 !== a || 1 / a === 1 / b : a !== a && b !== b
            }
            ;
            $jscomp.Set = function(a) {
                a = void 0 === a ? [] : a;
                this.map_ = new $jscomp.Map;
                if (a) {
                    a = $jscomp.makeIterator(a);
                    for (var b = a.next(); !b.done; b = a.next())
                        this.add(b.value)
                }
                this.size = this.map_.size
            }
            ;
            $jscomp.Set.checkBrowserConformance_ = function() {
                var a = $jscomp.global.Set;
                if (!a || !a.prototype.entries || !Object.seal)
                    return !1;
                var b = Object.seal({
                    x: 4
                })
                  , a = new a($jscomp.makeIterator([b]));
                if (a.has(b) || 1 != a.size || a.add(b) != a || 1 != a.size || a.add({
                    x: 4
                }) != a || 2 != a.size)
                    return !1;
                var a = a.entries()
                  , c = a.next();
                if (c.done || c.value[0] != b || c.value[1] != b)
                    return !1;
                c = a.next();
                return c.done || c.value[0] == b || 4 != c.value[0].x || c.value[1] != c.value[0] ? !1 : a.next().done
            }
            ;
            $jscomp.Set.prototype.add = function(a) {
                this.map_.set(a, a);
                this.size = this.map_.size;
                return this
            }
            ;
            $jscomp.Set.prototype["delete"] = function(a) {
                a = this.map_["delete"](a);
                this.size = this.map_.size;
                return a
            }
            ;
            $jscomp.Set.prototype.clear = function() {
                this.map_.clear();
                this.size = 0
            }
            ;
            $jscomp.Set.prototype.has = function(a) {
                return this.map_.has(a)
            }
            ;
            $jscomp.Set.prototype.entries = function() {
                return this.map_.entries()
            }
            ;
            $jscomp.Set.prototype.values = function() {
                return this.map_.values()
            }
            ;
            $jscomp.Set.prototype.forEach = function(a, b) {
                var c = this;
                this.map_.forEach(function(d) {
                    return a.call(b, d, d, c)
                })
            }
            ;
            $jscomp.Set.ASSUME_NO_NATIVE = !1;
            $jscomp.Set$install = function() {
                !$jscomp.Set.ASSUME_NO_NATIVE && $jscomp.Set.checkBrowserConformance_() ? $jscomp.Set = $jscomp.global.Set : ($jscomp.Map$install(),
                $jscomp.initSymbol(),
                $jscomp.initSymbolIterator(),
                $jscomp.Set.prototype[Symbol.iterator] = $jscomp.Set.prototype.values);
                $jscomp.Set$install = function() {}
            }
            ;
            $jscomp.string = $jscomp.string || {};
            $jscomp.string.noRegExp_ = function(a, b) {
                if (a instanceof RegExp)
                    throw new TypeError("First argument to String.prototype." + b + " must not be a regular expression");
            }
            ;
            $jscomp.string.fromCodePoint = function(a) {
                for (var b = [], c = 0; c < arguments.length; ++c)
                    b[c - 0] = arguments[c];
                for (var c = "", b = $jscomp.makeIterator(b), d = b.next(); !d.done; d = b.next()) {
                    d = d.value;
                    d = +d;
                    if (0 > d || 1114111 < d || d !== Math.floor(d))
                        throw new RangeError("invalid_code_point " + d);
                    65535 >= d ? c += String.fromCharCode(d) : (d -= 65536,
                    c += String.fromCharCode(d >>> 10 & 1023 | 55296),
                    c += String.fromCharCode(d & 1023 | 56320))
                }
                return c
            }
            ;
            $jscomp.string.repeat = function(a) {
                var b = this.toString();
                if (0 > a || 1342177279 < a)
                    throw new RangeError("Invalid count value");
                a |= 0;
                for (var c = ""; a; )
                    if (a & 1 && (c += b),
                    a >>>= 1)
                        b += b;
                return c
            }
            ;
            $jscomp.string.repeat$install = function() {
                String.prototype.repeat || (String.prototype.repeat = $jscomp.string.repeat)
            }
            ;
            $jscomp.string.codePointAt = function(a) {
                var b = this.toString()
                  , c = b.length;
                a = Number(a) || 0;
                if (0 <= a && a < c) {
                    a |= 0;
                    var d = b.charCodeAt(a);
                    if (55296 > d || 56319 < d || a + 1 === c)
                        return d;
                    a = b.charCodeAt(a + 1);
                    return 56320 > a || 57343 < a ? d : 1024 * (d - 55296) + a + 9216
                }
            }
            ;
            $jscomp.string.codePointAt$install = function() {
                String.prototype.codePointAt || (String.prototype.codePointAt = $jscomp.string.codePointAt)
            }
            ;
            $jscomp.string.includes = function(a, b) {
                b = void 0 === b ? 0 : b;
                $jscomp.string.noRegExp_(a, "includes");
                return -1 !== this.toString().indexOf(a, b)
            }
            ;
            $jscomp.string.includes$install = function() {
                String.prototype.includes || (String.prototype.includes = $jscomp.string.includes)
            }
            ;
            $jscomp.string.startsWith = function(a, b) {
                b = void 0 === b ? 0 : b;
                $jscomp.string.noRegExp_(a, "startsWith");
                var c = this.toString();
                a += "";
                for (var d = c.length, e = a.length, g = Math.max(0, Math.min(b | 0, c.length)), k = 0; k < e && g < d; )
                    if (c[g++] != a[k++])
                        return !1;
                return k >= e
            }
            ;
            $jscomp.string.startsWith$install = function() {
                String.prototype.startsWith || (String.prototype.startsWith = $jscomp.string.startsWith)
            }
            ;
            $jscomp.string.endsWith = function(a, b) {
                $jscomp.string.noRegExp_(a, "endsWith");
                var c = this.toString();
                a += "";
                void 0 === b && (b = c.length);
                for (var d = Math.max(0, Math.min(b | 0, c.length)), e = a.length; 0 < e && 0 < d; )
                    if (c[--d] != a[--e])
                        return !1;
                return 0 >= e
            }
            ;
            $jscomp.string.endsWith$install = function() {
                String.prototype.endsWith || (String.prototype.endsWith = $jscomp.string.endsWith)
            }
            ;
            var Hero = function() {
                function a() {
                    v = 16;
                    l.style.fontSize = v + "px";
                    l.style.height = n + "px";
                    h.style.height = n + "px";
                    b()
                }
                function b() {
                    5 < v && (C.offsetHeight > l.offsetHeight || C.offsetWidth > l.offsetWidth) && (l.style.fontSize = --v + "px",
                    b())
                }
                function c() {
                    return w > 480 + (m ? m.offsetLeft : 0) ? "desktop" : "mobile"
                }
                function d(a) {
                    var b = new Image
                      , f = document.body.classList.contains("sw-activated") ? 0 : 600;
                    b.onload = function() {
                        document.body.classList.remove("loading");
                        setTimeout(function() {
                            h.querySelector(".mobileThumbnail") && h.removeChild(h.querySelector(".mobileThumbnail"));
                            h.querySelector(".desktopThumbnail") && h.removeChild(h.querySelector(".desktopThumbnail"));
                            h.style.backgroundImage = "";
                            g()
                        }, f)
                    }
                    ;
                    b.src = a
                }
                function e(a) {
                    if (a) {
                        var b = !!document.querySelector(".hero").classList.contains("empty");
                        b ? (a.style.backgroundSize = "auto",
                        a.style.backgroundRepeat = "repeat",
                        a.style.visibility = "visible") : (a.style.backgroundSize = "",
                        a.style.backgroundRepeat = "");
                        if ("mobile" == c() && 0 < u.w && !b)
                            k(a, u);
                        else if ("desktop" == c() && 0 < f.w && !b)
                            k(a, f);
                        else {
                            var d = new Image;
                            d.onload = function() {
                                var e;
                                e = "naturalHeight"in d ? {
                                    w: d.naturalWidth,
                                    h: d.naturalHeight
                                } : {
                                    w: d.width,
                                    h: d.height
                                };
                                "mobile" == c() ? u = e : f = e;
                                b || k(a, e)
                            }
                            ;
                            if (a) {
                                var e = q(a);
                                "none" !== e && (d.src = e)
                            }
                        }
                    }
                }
                function g() {
                    f = {
                        w: 0,
                        h: 0
                    };
                    u = {
                        w: 0,
                        h: 0
                    }
                }
                function k(a, b) {
                    var f = a.offsetWidth
                      , c = a.offsetHeight
                      , d = b.w / b.h
                      , e = 0
                      , n = 0
                      , p = 0
                      , h = 0;
                    d < f / c ? (p = f,
                    h = f / d,
                    n = m ? m.offsetLeft : 0,
                    e = (c - f / d) / 2) : (p = c * d,
                    h = c,
                    n = (m ? m.offsetLeft : 0) + (f - c * d) / 2,
                    e = 0);
                    a.style.backgroundSize = p + "px " + h + "px";
                    a.style.backgroundPosition = n + "px " + e + "px";
                    a.style.visibility = "visible"
                }
                function q(a) {
                    try {
                        var b = getComputedStyle(a).backgroundImage;
                        return b ? b.match(/url[\("']+(.*?)["'\)]+$/)[1] : "none"
                    } catch (f) {
                        return console.error(f),
                        "none"
                    }
                }
                function x() {
                    var a = h.querySelector(".video");
                    if (a)
                        a.addEventListener("load", function() {
                            document.body.classList.remove("loading")
                        }, !1);
                    else if (a = h.querySelector("." + c() + "Picture"))
                        a = q(a),
                        "none" !== a && d(a)
                }
                function y() {
                    window.addEventListener("resize", function() {
                        var a = document.documentElement.clientWidth
                          , b = document.documentElement.clientHeight;
                        if ("undefined" == typeof window.orientation || a != w)
                            w = a,
                            n = b,
                            n >= 1.8 * w && (n = 768);
                        t()
                    })
                }
                function t() {
                    a();
                    window.sseditmode && (e(h.querySelector("." + c() + "Picture")),
                    e(h.querySelector("." + c() + "Thumbnail")))
                }
                var v = 16
                  , l = document.querySelector(".hero")
                  , h = l.querySelector(".background")
                  , C = l.querySelector(".layout")
                  , m = document.querySelector(".overlay-main")
                  , w = document.documentElement.clientWidth
                  , n = document.documentElement.clientHeight
                  , f = {
                    w: 0,
                    h: 0
                }
                  , u = {
                    w: 0,
                    h: 0
                };
                this.init = function() {
                    y();
                    0 > navigator.userAgent.indexOf("Page Speed") && (window.sseditmode ? e(h.querySelector("." + c() + "Thumbnail")) : h.style.backgroundImage = h.querySelector("." + c() + "Thumbnail").style.backgroundImage,
                    x());
                    t()
                }
                ;
                this.render = a;
                this.getDevice = c;
                this.fitBackground = function() {
                    e(h.querySelector("." + c() + "Picture"));
                    e(h.querySelector("." + c() + "Thumbnail"))
                }
                ;
                this.setBGImageSize = k;
                this.clearCacheBGImageSize = g
            };
            if (document.querySelector(".hero")) {
                var hero = new Hero;
                hero.init()
            }
            !function(a) {
                function b(d) {
                    if (c[d])
                        return c[d].exports;
                    var e = c[d] = {
                        i: d,
                        l: !1,
                        exports: {}
                    };
                    return a[d].call(e.exports, e, e.exports, b),
                    e.l = !0,
                    e.exports
                }
                var c = {};
                b.m = a;
                b.c = c;
                b.d = function(a, c, g) {
                    b.o(a, c) || Object.defineProperty(a, c, {
                        enumerable: !0,
                        get: g
                    })
                }
                ;
                b.r = function(a) {
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(a, Symbol.toStringTag, {
                        value: "Module"
                    });
                    Object.defineProperty(a, "__esModule", {
                        value: !0
                    })
                }
                ;
                b.t = function(a, c) {
                    if ((1 & c && (a = b(a)),
                    8 & c) || 4 & c && "object" == typeof a && a && a.__esModule)
                        return a;
                    var g = Object.create(null);
                    if (b.r(g),
                    Object.defineProperty(g, "default", {
                        enumerable: !0,
                        value: a
                    }),
                    2 & c && "string" != typeof a)
                        for (var k in a)
                            b.d(g, k, function(b) {
                                return a[b]
                            }
                            .bind(null, k));
                    return g
                }
                ;
                b.n = function(a) {
                    var c = a && a.__esModule ? function() {
                        return a["default"]
                    }
                    : function() {
                        return a
                    }
                    ;
                    return b.d(c, "a", c),
                    c
                }
                ;
                b.o = function(a, b) {
                    return Object.prototype.hasOwnProperty.call(a, b)
                }
                ;
                b.p = "";
                b(b.s = 10)
            }([, , function(a, b) {
                a.exports = function(a) {
                    "complete" === document.readyState || "interactive" === document.readyState ? a.call() : document.attachEvent ? document.attachEvent("onreadystatechange", function() {
                        "interactive" === document.readyState && a.call()
                    }) : document.addEventListener && document.addEventListener("DOMContentLoaded", a)
                }
            }
            , function(a, b, c) {
                b = c(4);
                a.exports = "undefined" != typeof window ? window : void 0 !== b ? b : "undefined" != typeof self ? self : {}
            }
            , function(a, b) {
                function c(a) {
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    $jscomp.initSymbolIterator();
                    return (c = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(a) {
                        return typeof a
                    }
                    : function(a) {
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        return a && "function" == typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
                    }
                    )(a)
                }
                var d = function() {
                    return this
                }();
                try {
                    d = d || (new Function("return this"))()
                } catch (e) {
                    "object" === ("undefined" == typeof window ? "undefined" : c(window)) && (d = window)
                }
                a.exports = d
            }
            , , , , , , function(a, b, c) {
                a.exports = c(11)
            }
            , function(a, b, c) {
                function d(a) {
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    $jscomp.initSymbolIterator();
                    return (d = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(a) {
                        return typeof a
                    }
                    : function(a) {
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        return a && "function" == typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
                    }
                    )(a)
                }
                c.r(b);
                a = c(2);
                a = c.n(a);
                var e = c(3), g = c(12), k, q, x = e.window.jarallax;
                e.window.jarallax = g["default"];
                e.window.jarallax.noConflict = function() {
                    return e.window.jarallax = x,
                    this
                }
                ;
                void 0 !== e.jQuery && ((k = function() {
                    for (var a = arguments.length, b = Array(a), c = 0; c < a; c++)
                        b[c] = arguments[c];
                    Array.prototype.unshift.call(b, this);
                    a = g["default"].apply(e.window, b);
                    return "object" !== d(a) ? a : this
                }
                ).constructor = g["default"].constructor,
                q = e.jQuery.fn.jarallax,
                e.jQuery.fn.jarallax = k,
                e.jQuery.fn.jarallax.noConflict = function() {
                    return e.jQuery.fn.jarallax = q,
                    this
                }
                );
                a()(function() {
                    Object(g["default"])(document.querySelectorAll("[data-jarallax]"))
                })
            }
            , function(a, b, c) {
                function d(a, b) {
                    var f;
                    if (!(f = function(a) {
                        if (Array.isArray(a))
                            return a
                    }(a) || function(a, b) {
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        $jscomp.initSymbolIterator();
                        if ("undefined" != typeof Symbol && Symbol.iterator in Object(a)) {
                            var f = []
                              , c = !0
                              , d = !1
                              , e = void 0;
                            try {
                                $jscomp.initSymbol();
                                $jscomp.initSymbolIterator();
                                for (var n, h = a[Symbol.iterator](); !(c = (n = h.next()).done) && (f.push(n.value),
                                !b || f.length !== b); c = !0)
                                    ;
                            } catch (E) {
                                d = !0,
                                e = E
                            } finally {
                                try {
                                    c || null == h["return"] || h["return"]()
                                } finally {
                                    if (d)
                                        throw e;
                                }
                            }
                            return f
                        }
                    }(a, b) || function(a, b) {
                        if (a) {
                            if ("string" == typeof a)
                                return e(a, b);
                            var f = Object.prototype.toString.call(a).slice(8, -1);
                            "Object" === f && a.constructor && (f = a.constructor.name);
                            if ("Map" === f || "Set" === f)
                                return Array.from(a);
                            if ("Arguments" === f || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(f))
                                return e(a, b)
                        }
                    }(a, b)))
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                    return f
                }
                function e(a, b) {
                    (null == b || b > a.length) && (b = a.length);
                    for (var f = 0, c = Array(b); f < b; f++)
                        c[f] = a[f];
                    return c
                }
                function g(a) {
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    $jscomp.initSymbolIterator();
                    return (g = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(a) {
                        return typeof a
                    }
                    : function(a) {
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        return a && "function" == typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
                    }
                    )(a)
                }
                function k(a, b) {
                    for (var f = 0; f < b.length; f++) {
                        var c = b[f];
                        c.enumerable = c.enumerable || !1;
                        c.configurable = !0;
                        "value"in c && (c.writable = !0);
                        Object.defineProperty(a, c.key, c)
                    }
                }
                function q() {
                    l = m ? (!v && document.body && ((v = document.createElement("div")).style.cssText = "position: fixed; top: -9999px; left: 0; height: 100vh; width: 0;",
                    document.body.appendChild(v)),
                    (v ? v.clientHeight : 0) || t.window.innerHeight || document.documentElement.clientHeight) : t.window.innerHeight || document.documentElement.clientHeight
                }
                function x() {
                    n.length && (n.forEach(function(a, b) {
                        var f = a.instance
                          , c = a.oldData
                          , d = f.$item.getBoundingClientRect()
                          , d = {
                            width: d.width,
                            height: d.height,
                            top: d.top,
                            bottom: d.bottom,
                            wndW: t.window.innerWidth,
                            wndH: l
                        }
                          , e = !c || c.wndW !== d.wndW || c.wndH !== d.wndH || c.width !== d.width || c.height !== d.height
                          , c = e || !c || c.top !== d.top || c.bottom !== d.bottom;
                        n[b].oldData = d;
                        e && f.onResize();
                        c && f.onScroll()
                    }),
                    t.window.requestAnimationFrame(x))
                }
                function y(a, b) {
                    ("object" === ("undefined" == typeof HTMLElement ? "undefined" : g(HTMLElement)) ? a instanceof HTMLElement : a && "object" === g(a) && null !== a && 1 === a.nodeType && "string" == typeof a.nodeName) && (a = [a]);
                    for (var f, c = a.length, d = 0, e = arguments.length, n = Array(2 < e ? e - 2 : 0), p = 2; p < e; p++)
                        n[p - 2] = arguments[p];
                    for (; d < c; d += 1)
                        if ("object" === g(b) || void 0 === b ? a[d].jarallax || (a[d].jarallax = new u(a[d],b)) : a[d].jarallax && (f = a[d].jarallax[b].apply(a[d].jarallax, n)),
                        void 0 !== f)
                            return f;
                    return a
                }
                c.r(b);
                a = c(2);
                a = c.n(a);
                var t = c(3), v, l, h = t.window.navigator, C = -1 < h.userAgent.indexOf("MSIE ") || -1 < h.userAgent.indexOf("Trident/") || -1 < h.userAgent.indexOf("Edge/"), m = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(h.userAgent), w = function() {
                    for (var a = ["transform", "WebkitTransform", "MozTransform"], b = document.createElement("div"), f = 0; f < a.length; f += 1)
                        if (b && void 0 !== b.style[a[f]])
                            return a[f];
                    return !1
                }();
                q();
                t.window.addEventListener("resize", q);
                t.window.addEventListener("orientationchange", q);
                t.window.addEventListener("load", q);
                a()(function() {
                    q()
                });
                var n = []
                  , f = 0
                  , u = function() {
                    function a(b, c) {
                        if (!(this instanceof a))
                            throw new TypeError("Cannot call a class as a function");
                        !0;
                        var e = this;
                        e.instanceID = f;
                        f += 1;
                        e.$item = b;
                        e.defaults = {
                            type: "scroll",
                            speed: .5,
                            imgSrc: null,
                            imgElement: ".jarallax-img",
                            imgSize: "cover",
                            imgPosition: "50% 50%",
                            imgRepeat: "no-repeat",
                            keepImg: !1,
                            elementInViewport: null,
                            zIndex: -100,
                            disableParallax: !1,
                            disableVideo: !1,
                            videoSrc: null,
                            videoStartTime: 0,
                            videoEndTime: 0,
                            videoVolume: 0,
                            videoLoop: !0,
                            videoPlayOnlyVisible: !0,
                            videoLazyLoading: !0,
                            onScroll: null,
                            onInit: null,
                            onDestroy: null,
                            onCoverImage: null
                        };
                        var n, l, p = e.$item.dataset || {}, k = {};
                        Object.keys(p).forEach(function(a) {
                            var b = a.substr(0, 1).toLowerCase() + a.substr(1);
                            b && void 0 !== e.defaults[b] && (k[b] = p[a])
                        });
                        e.options = e.extend({}, e.defaults, k, c);
                        e.pureOptions = e.extend({}, e.options);
                        Object.keys(e.options).forEach(function(a) {
                            "true" === e.options[a] ? e.options[a] = !0 : "false" === e.options[a] && (e.options[a] = !1)
                        });
                        e.options.speed = Math.min(2, Math.max(-1, parseFloat(e.options.speed)));
                        "string" == typeof e.options.disableParallax && (e.options.disableParallax = new RegExp(e.options.disableParallax));
                        e.options.disableParallax instanceof RegExp && (n = e.options.disableParallax,
                        e.options.disableParallax = function() {
                            return n.test(h.userAgent)
                        }
                        );
                        "function" != typeof e.options.disableParallax && (e.options.disableParallax = function() {
                            return !1
                        }
                        );
                        "string" == typeof e.options.disableVideo && (e.options.disableVideo = new RegExp(e.options.disableVideo));
                        e.options.disableVideo instanceof RegExp && (l = e.options.disableVideo,
                        e.options.disableVideo = function() {
                            return l.test(h.userAgent)
                        }
                        );
                        "function" != typeof e.options.disableVideo && (e.options.disableVideo = function() {
                            return !1
                        }
                        );
                        var m = e.options.elementInViewport;
                        m && "object" === g(m) && void 0 !== m.length && (m = d(m, 1)[0]);
                        m instanceof Element || (m = null);
                        e.options.elementInViewport = m;
                        e.image = {
                            src: e.options.imgSrc || null,
                            $container: null,
                            useImgTag: !1,
                            position: /iPad|iPhone|iPod|Android/.test(h.userAgent) ? "absolute" : "fixed"
                        };
                        e.initImg() && e.canInitParallax() && e.init()
                    }
                    var b;
                    return b = [{
                        key: "css",
                        value: function(a, b) {
                            return "string" == typeof b ? t.window.getComputedStyle(a).getPropertyValue(b) : (b.transform && w && (b[w] = b.transform),
                            Object.keys(b).forEach(function(f) {
                                a.style[f] = b[f]
                            }),
                            a)
                        }
                    }, {
                        key: "extend",
                        value: function(a) {
                            for (var b = arguments.length, f = Array(1 < b ? b - 1 : 0), c = 1; c < b; c++)
                                f[c - 1] = arguments[c];
                            return a = a || {},
                            Object.keys(f).forEach(function(b) {
                                f[b] && Object.keys(f[b]).forEach(function(c) {
                                    a[c] = f[b][c]
                                })
                            }),
                            a
                        }
                    }, {
                        key: "getWindowData",
                        value: function() {
                            return {
                                width: t.window.innerWidth || document.documentElement.clientWidth,
                                height: l,
                                y: document.documentElement.scrollTop
                            }
                        }
                    }, {
                        key: "initImg",
                        value: function() {
                            var a = this.options.imgElement;
                            return a && "string" == typeof a && (a = this.$item.querySelector(a)),
                            a instanceof Element || (this.options.imgSrc ? (a = new Image).src = this.options.imgSrc : a = null),
                            a && (this.options.keepImg ? this.image.$item = a.cloneNode(!0) : (this.image.$item = a,
                            this.image.$itemParent = a.parentNode),
                            this.image.useImgTag = !0),
                            !!this.image.$item || (null === this.image.src && (this.image.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
                            this.image.bgImage = this.css(this.$item, "background-image")),
                            !(!this.image.bgImage || "none" === this.image.bgImage))
                        }
                    }, {
                        key: "canInitParallax",
                        value: function() {
                            return w && !this.options.disableParallax()
                        }
                    }, {
                        key: "init",
                        value: function() {
                            var a, b, f, c = {
                                position: "absolute",
                                top: 0,
                                left: 0,
                                width: "100%",
                                height: "100%",
                                overflow: "hidden"
                            }, d = {
                                pointerEvents: "none",
                                transformStyle: "preserve-3d",
                                backfaceVisibility: "hidden",
                                willChange: "transform,opacity"
                            };
                            this.options.keepImg || ((a = this.$item.getAttribute("style")) && this.$item.setAttribute("data-jarallax-original-styles", a),
                            !this.image.useImgTag || (b = this.image.$item.getAttribute("style")) && this.image.$item.setAttribute("data-jarallax-original-styles", b));
                            "static" === this.css(this.$item, "position") && this.css(this.$item, {
                                position: "relative"
                            });
                            "auto" === this.css(this.$item, "z-index") && this.css(this.$item, {
                                zIndex: 0
                            });
                            this.image.$container = document.createElement("div");
                            this.css(this.image.$container, c);
                            this.css(this.image.$container, {
                                "z-index": this.options.zIndex
                            });
                            C && this.css(this.image.$container, {
                                opacity: .9999
                            });
                            this.image.$container.setAttribute("id", "jarallax-container-".concat(this.instanceID));
                            this.$item.appendChild(this.image.$container);
                            this.image.useImgTag ? d = this.extend({
                                "object-fit": this.options.imgSize,
                                "object-position": this.options.imgPosition,
                                "font-family": "object-fit: ".concat(this.options.imgSize, "; object-position: ").concat(this.options.imgPosition, ";"),
                                "max-width": "none"
                            }, c, d) : (this.image.$item = document.createElement("div"),
                            this.image.src && (d = this.extend({
                                "background-position": this.options.imgPosition,
                                "background-size": this.options.imgSize,
                                "background-repeat": this.options.imgRepeat,
                                "background-image": this.image.bgImage || 'url("'.concat(this.image.src, '")')
                            }, c, d)));
                            "opacity" !== this.options.type && "scale" !== this.options.type && "scale-opacity" !== this.options.type && 1 !== this.options.speed || (this.image.position = "absolute");
                            "fixed" === this.image.position && (f = function(a) {
                                for (var b = []; null !== a.parentElement; )
                                    1 === (a = a.parentElement).nodeType && b.push(a);
                                return b
                            }(this.$item).filter(function(a) {
                                a = t.window.getComputedStyle(a);
                                var b = a["-webkit-transform"] || a["-moz-transform"] || a.transform;
                                return b && "none" !== b || /(auto|scroll)/.test(a.overflow + a["overflow-y"] + a["overflow-x"])
                            }),
                            this.image.position = f.length ? "absolute" : "fixed");
                            d.position = this.image.position;
                            this.css(this.image.$item, d);
                            this.image.$container.appendChild(this.image.$item);
                            this.onResize();
                            this.onScroll(!0);
                            this.options.onInit && this.options.onInit.call(this);
                            "none" !== this.css(this.$item, "background-image") && this.css(this.$item, {
                                "background-image": "none"
                            });
                            this.addToParallaxList()
                        }
                    }, {
                        key: "addToParallaxList",
                        value: function() {
                            n.push({
                                instance: this
                            });
                            1 === n.length && t.window.requestAnimationFrame(x)
                        }
                    }, {
                        key: "removeFromParallaxList",
                        value: function() {
                            var a = this;
                            n.forEach(function(b, f) {
                                b.instance.instanceID === a.instanceID && n.splice(f, 1)
                            })
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this.removeFromParallaxList();
                            var a, b = this.$item.getAttribute("data-jarallax-original-styles");
                            this.$item.removeAttribute("data-jarallax-original-styles");
                            b ? this.$item.setAttribute("style", b) : this.$item.removeAttribute("style");
                            this.image.useImgTag && (a = this.image.$item.getAttribute("data-jarallax-original-styles"),
                            this.image.$item.removeAttribute("data-jarallax-original-styles"),
                            a ? this.image.$item.setAttribute("style", b) : this.image.$item.removeAttribute("style"),
                            this.image.$itemParent && this.image.$itemParent.appendChild(this.image.$item));
                            this.$clipStyles && this.$clipStyles.parentNode.removeChild(this.$clipStyles);
                            this.image.$container && this.image.$container.parentNode.removeChild(this.image.$container);
                            this.options.onDestroy && this.options.onDestroy.call(this);
                            delete this.$item.jarallax
                        }
                    }, {
                        key: "clipContainer",
                        value: function() {
                            var a, b, f, c;
                            "fixed" === this.image.position && (b = (a = this.image.$container.getBoundingClientRect()).width,
                            f = a.height,
                            this.$clipStyles || (this.$clipStyles = document.createElement("style"),
                            this.$clipStyles.setAttribute("type", "text/css"),
                            this.$clipStyles.setAttribute("id", "jarallax-clip-".concat(this.instanceID)),
                            (document.head || document.getElementsByTagName("head")[0]).appendChild(this.$clipStyles)),
                            c = "#jarallax-container-".concat(this.instanceID, " {\n            clip: rect(0 ").concat(b, "px ").concat(f, "px 0);\n            clip: rect(0, ").concat(b, "px, ").concat(f, "px, 0);\n            -webkit-clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);\n            clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);\n        }"),
                            this.$clipStyles.styleSheet ? this.$clipStyles.styleSheet.cssText = c : this.$clipStyles.innerHTML = c)
                        }
                    }, {
                        key: "coverImage",
                        value: function() {
                            var a = this.image.$container.getBoundingClientRect()
                              , b = a.height
                              , f = this.options.speed
                              , c = "scroll" === this.options.type || "scroll-opacity" === this.options.type
                              , d = 0
                              , e = b
                              , n = 0;
                            return c && (0 > f ? (d = f * Math.max(b, l),
                            l < b && (d -= f * (b - l))) : d = f * (b + l),
                            1 < f ? e = Math.abs(d - l) : 0 > f ? e = d / f + Math.abs(d) : e += (l - b) * (1 - f),
                            d /= 2),
                            this.parallaxScrollDistance = d,
                            n = c ? (l - e) / 2 : (b - e) / 2,
                            this.css(this.image.$item, {
                                height: "".concat(e, "px"),
                                marginTop: "".concat(n, "px"),
                                left: "fixed" === this.image.position ? "".concat(a.left, "px") : "0",
                                width: "".concat(a.width, "px")
                            }),
                            this.options.onCoverImage && this.options.onCoverImage.call(this),
                            {
                                image: {
                                    height: e,
                                    marginTop: n
                                },
                                container: a
                            }
                        }
                    }, {
                        key: "isVisible",
                        value: function() {
                            return this.isElementInViewport || !1
                        }
                    }, {
                        key: "onScroll",
                        value: function(a) {
                            var b, f, c, d, e, n, h, g, k, m, w = this.$item.getBoundingClientRect(), u = w.top, A = w.height, B = {}, q = w;
                            this.options.elementInViewport && (q = this.options.elementInViewport.getBoundingClientRect());
                            this.isElementInViewport = 0 <= q.bottom && 0 <= q.right && q.top <= l && q.left <= t.window.innerWidth;
                            (a || this.isElementInViewport) && (b = Math.max(0, u),
                            f = Math.max(0, A + u),
                            c = Math.max(0, -u),
                            d = Math.max(0, u + A - l),
                            e = Math.max(0, A - (u + A - l)),
                            n = Math.max(0, -u + l - A),
                            h = 1 - (l - u) / (l + A) * 2,
                            g = 1,
                            A < l ? g = 1 - (c || d) / A : f <= l ? g = f / l : e <= l && (g = e / l),
                            "opacity" !== this.options.type && "scale-opacity" !== this.options.type && "scroll-opacity" !== this.options.type || (B.transform = "translate3d(0,0,0)",
                            B.opacity = g),
                            "scale" !== this.options.type && "scale-opacity" !== this.options.type || (k = 1,
                            0 > this.options.speed ? k -= this.options.speed * g : k += this.options.speed * (1 - g),
                            B.transform = "scale(".concat(k, ") translate3d(0,0,0)")),
                            "scroll" !== this.options.type && "scroll-opacity" !== this.options.type || (m = this.parallaxScrollDistance * h,
                            "absolute" === this.image.position && (m -= u),
                            B.transform = "translate3d(0,".concat(m, "px,0)")),
                            this.css(this.image.$item, B),
                            this.options.onScroll && this.options.onScroll.call(this, {
                                section: w,
                                beforeTop: b,
                                beforeTopEnd: f,
                                afterTop: c,
                                beforeBottom: d,
                                beforeBottomEnd: e,
                                afterBottom: n,
                                visiblePercent: g,
                                fromViewportCenter: h
                            }))
                        }
                    }, {
                        key: "onResize",
                        value: function() {
                            this.coverImage();
                            this.clipContainer()
                        }
                    }],
                    k(a.prototype, b),
                    a
                }();
                y.constructor = u;
                b["default"] = y
            }
            ]);
            !function(a) {
                function b(d) {
                    if (c[d])
                        return c[d].exports;
                    var e = c[d] = {
                        i: d,
                        l: !1,
                        exports: {}
                    };
                    return a[d].call(e.exports, e, e.exports, b),
                    e.l = !0,
                    e.exports
                }
                var c = {};
                b.m = a;
                b.c = c;
                b.d = function(a, c, g) {
                    b.o(a, c) || Object.defineProperty(a, c, {
                        enumerable: !0,
                        get: g
                    })
                }
                ;
                b.r = function(a) {
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(a, Symbol.toStringTag, {
                        value: "Module"
                    });
                    Object.defineProperty(a, "__esModule", {
                        value: !0
                    })
                }
                ;
                b.t = function(a, c) {
                    if ((1 & c && (a = b(a)),
                    8 & c) || 4 & c && "object" == typeof a && a && a.__esModule)
                        return a;
                    var g = Object.create(null);
                    if (b.r(g),
                    Object.defineProperty(g, "default", {
                        enumerable: !0,
                        value: a
                    }),
                    2 & c && "string" != typeof a)
                        for (var k in a)
                            b.d(g, k, function(b) {
                                return a[b]
                            }
                            .bind(null, k));
                    return g
                }
                ;
                b.n = function(a) {
                    var c = a && a.__esModule ? function() {
                        return a["default"]
                    }
                    : function() {
                        return a
                    }
                    ;
                    return b.d(c, "a", c),
                    c
                }
                ;
                b.o = function(a, b) {
                    return Object.prototype.hasOwnProperty.call(a, b)
                }
                ;
                b.p = "";
                b(b.s = 6)
            }([, , function(a, b) {
                a.exports = function(a) {
                    "complete" === document.readyState || "interactive" === document.readyState ? a.call() : document.attachEvent ? document.attachEvent("onreadystatechange", function() {
                        "interactive" === document.readyState && a.call()
                    }) : document.addEventListener && document.addEventListener("DOMContentLoaded", a)
                }
            }
            , function(a, b, c) {
                b = c(4);
                a.exports = "undefined" != typeof window ? window : void 0 !== b ? b : "undefined" != typeof self ? self : {}
            }
            , function(a, b) {
                function c(a) {
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    $jscomp.initSymbolIterator();
                    return (c = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(a) {
                        return typeof a
                    }
                    : function(a) {
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        return a && "function" == typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
                    }
                    )(a)
                }
                var d;
                d = function() {
                    return this
                }();
                try {
                    d = d || (new Function("return this"))()
                } catch (e) {
                    "object" === ("undefined" == typeof window ? "undefined" : c(window)) && (d = window)
                }
                a.exports = d
            }
            , , function(a, b, c) {
                a.exports = c(7)
            }
            , function(a, b, c) {
                c.r(b);
                a = c(8);
                b = c(3);
                var d = c.n(b);
                b = c(2);
                b = c.n(b);
                c = c(9);
                d.a.VideoWorker = d.a.VideoWorker || a["default"];
                Object(c["default"])();
                b()(function() {
                    void 0 !== d.a.jarallax && d.a.jarallax(document.querySelectorAll("[data-jarallax-video]"))
                })
            }
            , function(a, b, c) {
                function d(a) {
                    $jscomp.initSymbol();
                    $jscomp.initSymbol();
                    $jscomp.initSymbolIterator();
                    return (d = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(a) {
                        return typeof a
                    }
                    : function(a) {
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        $jscomp.initSymbol();
                        return a && "function" == typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
                    }
                    )(a)
                }
                function e(a, b) {
                    for (var c = 0; c < b.length; c++) {
                        var f = b[c];
                        f.enumerable = f.enumerable || !1;
                        f.configurable = !0;
                        "value"in f && (f.writable = !0);
                        Object.defineProperty(a, f.key, f)
                    }
                }
                function g() {
                    this.doneCallbacks = [];
                    this.failCallbacks = []
                }
                c.r(b);
                c.d(b, "default", function() {
                    return C
                });
                a = c(3);
                var k = c.n(a);
                g.prototype = {
                    execute: function(a, b) {
                        var c = a.length;
                        for (b = Array.prototype.slice.call(b); c; )
                            a[--c].apply(null, b)
                    },
                    resolve: function() {
                        for (var a = arguments.length, b = Array(a), c = 0; c < a; c++)
                            b[c] = arguments[c];
                        this.execute(this.doneCallbacks, b)
                    },
                    reject: function() {
                        for (var a = arguments.length, b = Array(a), c = 0; c < a; c++)
                            b[c] = arguments[c];
                        this.execute(this.failCallbacks, b)
                    },
                    done: function(a) {
                        this.doneCallbacks.push(a)
                    },
                    fail: function(a) {
                        this.failCallbacks.push(a)
                    }
                };
                var q = 0
                  , x = 0
                  , y = 0
                  , t = 0
                  , v = 0
                  , l = new g
                  , h = new g
                  , C = function() {
                    function a(b, f) {
                        if (!(this instanceof a))
                            throw new TypeError("Cannot call a class as a function");
                        !0;
                        this.url = b;
                        this.options_default = {
                            autoplay: !1,
                            loop: !1,
                            mute: !1,
                            volume: 100,
                            showContols: !0,
                            startTime: 0,
                            endTime: 0
                        };
                        this.options = this.extend({}, this.options_default, f);
                        (this.videoID = this.parseURL(b)) && (this.ID = q,
                        q += 1,
                        this.loadAPI(),
                        this.init())
                    }
                    var b;
                    return b = [{
                        key: "extend",
                        value: function() {
                            for (var a = arguments.length, b = Array(a), c = 0; c < a; c++)
                                b[c] = arguments[c];
                            var d = b[0] || {};
                            return Object.keys(b).forEach(function(a) {
                                b[a] && Object.keys(b[a]).forEach(function(c) {
                                    d[c] = b[a][c]
                                })
                            }),
                            d
                        }
                    }, {
                        key: "parseURL",
                        value: function(a) {
                            var b, c, d, e, h = !(!(b = a.match(/.*(?:youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=)([^#\&\?]*).*/)) || 11 !== b[1].length) && b[1];
                            b = function(a) {
                                a = a.match(/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/);
                                return !(!a || !a[3]) && a[3]
                            }(a);
                            a = (c = a.split(/,(?=mp4\:|webm\:|ogv\:|ogg\:)/),
                            d = {},
                            e = 0,
                            c.forEach(function(a) {
                                (a = a.match(/^(mp4|webm|ogv|ogg)\:(.*)/)) && a[1] && a[2] && (d["ogv" === a[1] ? "ogg" : a[1]] = a[2],
                                e = 1)
                            }),
                            !!e && d);
                            return h ? (this.type = "youtube",
                            h) : b ? (this.type = "vimeo",
                            b) : !!a && (this.type = "local",
                            a)
                        }
                    }, {
                        key: "isValid",
                        value: function() {
                            return !!this.videoID
                        }
                    }, {
                        key: "on",
                        value: function(a, b) {
                            this.userEventsList = this.userEventsList || [];
                            (this.userEventsList[a] || (this.userEventsList[a] = [])).push(b)
                        }
                    }, {
                        key: "off",
                        value: function(a, b) {
                            var c = this;
                            this.userEventsList && this.userEventsList[a] && (b ? this.userEventsList[a].forEach(function(d, e) {
                                d === b && (c.userEventsList[a][e] = !1)
                            }) : delete this.userEventsList[a])
                        }
                    }, {
                        key: "fire",
                        value: function(a) {
                            for (var b = this, c = arguments.length, d = Array(1 < c ? c - 1 : 0), e = 1; e < c; e++)
                                d[e - 1] = arguments[e];
                            this.userEventsList && void 0 !== this.userEventsList[a] && this.userEventsList[a].forEach(function(a) {
                                a && a.apply(b, d)
                            })
                        }
                    }, {
                        key: "play",
                        value: function(a) {
                            var b = this;
                            b.player && ("youtube" === b.type && b.player.playVideo && (void 0 !== a && b.player.seekTo(a || 0),
                            k.a.YT.PlayerState.PLAYING !== b.player.getPlayerState() && b.player.playVideo()),
                            "vimeo" === b.type && (void 0 !== a && b.player.setCurrentTime(a),
                            b.player.getPaused().then(function(a) {
                                a && b.player.play()
                            })),
                            "local" === b.type && (void 0 !== a && (b.player.currentTime = a),
                            b.player.paused && b.player.play()))
                        }
                    }, {
                        key: "pause",
                        value: function() {
                            var a = this;
                            a.player && ("youtube" === a.type && a.player.pauseVideo && k.a.YT.PlayerState.PLAYING === a.player.getPlayerState() && a.player.pauseVideo(),
                            "vimeo" === a.type && a.player.getPaused().then(function(b) {
                                b || a.player.pause()
                            }),
                            "local" === a.type && (a.player.paused || a.player.pause()))
                        }
                    }, {
                        key: "mute",
                        value: function() {
                            this.player && ("youtube" === this.type && this.player.mute && this.player.mute(),
                            "vimeo" === this.type && this.player.setVolume && this.player.setVolume(0),
                            "local" === this.type && (this.$video.muted = !0))
                        }
                    }, {
                        key: "unmute",
                        value: function() {
                            this.player && ("youtube" === this.type && this.player.mute && this.player.unMute(),
                            "vimeo" === this.type && this.player.setVolume && this.player.setVolume(this.options.volume),
                            "local" === this.type && (this.$video.muted = !1))
                        }
                    }, {
                        key: "setVolume",
                        value: function() {
                            var a = 0 < arguments.length && void 0 !== arguments[0] && arguments[0];
                            this.player && a && ("youtube" === this.type && this.player.setVolume && this.player.setVolume(a),
                            "vimeo" === this.type && this.player.setVolume && this.player.setVolume(a),
                            "local" === this.type && (this.$video.volume = a / 100))
                        }
                    }, {
                        key: "getVolume",
                        value: function(a) {
                            this.player ? ("youtube" === this.type && this.player.getVolume && a(this.player.getVolume()),
                            "vimeo" === this.type && this.player.getVolume && this.player.getVolume().then(function(b) {
                                a(b)
                            }),
                            "local" === this.type && a(100 * this.$video.volume)) : a(!1)
                        }
                    }, {
                        key: "getMuted",
                        value: function(a) {
                            this.player ? ("youtube" === this.type && this.player.isMuted && a(this.player.isMuted()),
                            "vimeo" === this.type && this.player.getVolume && this.player.getVolume().then(function(b) {
                                a(!!b)
                            }),
                            "local" === this.type && a(this.$video.muted)) : a(null)
                        }
                    }, {
                        key: "getImageURL",
                        value: function(a) {
                            var b = this;
                            if (b.videoImage)
                                a(b.videoImage);
                            else {
                                if ("youtube" === b.type) {
                                    var c = ["maxresdefault", "sddefault", "hqdefault", "0"]
                                      , d = 0
                                      , e = new Image;
                                    e.onload = function() {
                                        120 !== (this.naturalWidth || this.width) || d === c.length - 1 ? (b.videoImage = "https://img.youtube.com/vi/".concat(b.videoID, "/").concat(c[d], ".jpg"),
                                        a(b.videoImage)) : (d += 1,
                                        this.src = "https://img.youtube.com/vi/".concat(b.videoID, "/").concat(c[d], ".jpg"))
                                    }
                                    ;
                                    e.src = "https://img.youtube.com/vi/".concat(b.videoID, "/").concat(c[d], ".jpg")
                                }
                                "vimeo" === b.type && (e = new XMLHttpRequest,
                                e.open("GET", "https://vimeo.com/api/v2/video/".concat(b.videoID, ".json"), !0),
                                e.onreadystatechange = function() {
                                    if (4 === this.readyState && 200 <= this.status && 400 > this.status) {
                                        var c = JSON.parse(this.responseText);
                                        b.videoImage = c[0].thumbnail_large;
                                        a(b.videoImage)
                                    }
                                }
                                ,
                                e.send(),
                                e = null)
                            }
                        }
                    }, {
                        key: "getIframe",
                        value: function(a) {
                            this.getVideo(a)
                        }
                    }, {
                        key: "getVideo",
                        value: function(a) {
                            var b = this;
                            b.$video ? a(b.$video) : b.onAPIready(function() {
                                var c, d;
                                if (b.$video || ((c = document.createElement("div")).style.display = "none"),
                                "youtube" === b.type) {
                                    var e, h;
                                    b.playerOptions = {
                                        host: "https://www.youtube-nocookie.com",
                                        videoId: b.videoID,
                                        playerVars: {
                                            autohide: 1,
                                            rel: 0,
                                            autoplay: 0,
                                            playsinline: 1
                                        }
                                    };
                                    b.options.showContols || (b.playerOptions.playerVars.iv_load_policy = 3,
                                    b.playerOptions.playerVars.modestbranding = 1,
                                    b.playerOptions.playerVars.controls = 0,
                                    b.playerOptions.playerVars.showinfo = 0,
                                    b.playerOptions.playerVars.disablekb = 1);
                                    b.playerOptions.events = {
                                        onReady: function(a) {
                                            if (b.options.mute ? a.target.mute() : b.options.volume && a.target.setVolume(b.options.volume),
                                            b.options.autoplay && b.play(b.options.startTime),
                                            b.fire("ready", a),
                                            b.options.loop && !b.options.endTime)
                                                b.options.endTime = b.player.getDuration() - .1;
                                            setInterval(function() {
                                                b.getVolume(function(c) {
                                                    b.options.volume !== c && (b.options.volume = c,
                                                    b.fire("volumechange", a))
                                                })
                                            }, 150)
                                        },
                                        onStateChange: function(a) {
                                            b.options.loop && a.data === k.a.YT.PlayerState.ENDED && b.play(b.options.startTime);
                                            e || a.data !== k.a.YT.PlayerState.PLAYING || (e = 1,
                                            b.fire("started", a));
                                            a.data === k.a.YT.PlayerState.PLAYING && b.fire("play", a);
                                            a.data === k.a.YT.PlayerState.PAUSED && b.fire("pause", a);
                                            a.data === k.a.YT.PlayerState.ENDED && b.fire("ended", a);
                                            a.data === k.a.YT.PlayerState.PLAYING ? h = setInterval(function() {
                                                b.fire("timeupdate", a);
                                                b.options.endTime && b.player.getCurrentTime() >= b.options.endTime && (b.options.loop ? b.play(b.options.startTime) : b.pause())
                                            }, 150) : clearInterval(h)
                                        },
                                        onError: function(a) {
                                            b.fire("error", a)
                                        }
                                    };
                                    var g = !b.$video;
                                    if (g) {
                                        var l = document.createElement("div");
                                        l.setAttribute("id", b.playerID);
                                        c.appendChild(l);
                                        document.body.appendChild(c)
                                    }
                                    b.player = b.player || new k.a.YT.Player(b.playerID,b.playerOptions);
                                    g && (b.$video = document.getElementById(b.playerID),
                                    b.videoWidth = parseInt(b.$video.getAttribute("width"), 10) || 1280,
                                    b.videoHeight = parseInt(b.$video.getAttribute("height"), 10) || 720)
                                }
                                if ("vimeo" === b.type) {
                                    if (b.playerOptions = {
                                        dnt: 1,
                                        id: b.videoID,
                                        autopause: 0,
                                        transparent: 0,
                                        autoplay: b.options.autoplay ? 1 : 0,
                                        loop: b.options.loop ? 1 : 0,
                                        muted: b.options.mute ? 1 : 0
                                    },
                                    b.options.volume && (b.playerOptions.volume = b.options.volume),
                                    b.options.showContols || (b.playerOptions.badge = 0,
                                    b.playerOptions.byline = 0,
                                    b.playerOptions.portrait = 0,
                                    b.playerOptions.title = 0,
                                    b.playerOptions.background = 1),
                                    !b.$video) {
                                        var m = "";
                                        Object.keys(b.playerOptions).forEach(function(a) {
                                            "" !== m && (m += "&");
                                            m += "".concat(a, "=").concat(encodeURIComponent(b.playerOptions[a]))
                                        });
                                        b.$video = document.createElement("iframe");
                                        b.$video.setAttribute("id", b.playerID);
                                        b.$video.setAttribute("src", "https://player.vimeo.com/video/".concat(b.videoID, "?").concat(m));
                                        b.$video.setAttribute("frameborder", "0");
                                        b.$video.setAttribute("mozallowfullscreen", "");
                                        b.$video.setAttribute("allowfullscreen", "");
                                        c.appendChild(b.$video);
                                        document.body.appendChild(c)
                                    }
                                    var q;
                                    b.player = b.player || new k.a.Vimeo.Player(b.$video,b.playerOptions);
                                    b.options.startTime && b.options.autoplay && b.player.setCurrentTime(b.options.startTime);
                                    b.player.getVideoWidth().then(function(a) {
                                        b.videoWidth = a || 1280
                                    });
                                    b.player.getVideoHeight().then(function(a) {
                                        b.videoHeight = a || 720
                                    });
                                    b.player.on("timeupdate", function(a) {
                                        q || (b.fire("started", a),
                                        q = 1);
                                        b.fire("timeupdate", a);
                                        b.options.endTime && b.options.endTime && a.seconds >= b.options.endTime && (b.options.loop ? b.play(b.options.startTime) : b.pause())
                                    });
                                    b.player.on("play", function(a) {
                                        b.fire("play", a);
                                        b.options.startTime && 0 === a.seconds && b.play(b.options.startTime)
                                    });
                                    b.player.on("pause", function(a) {
                                        b.fire("pause", a)
                                    });
                                    b.player.on("ended", function(a) {
                                        b.fire("ended", a)
                                    });
                                    b.player.on("loaded", function(a) {
                                        b.fire("ready", a)
                                    });
                                    b.player.on("volumechange", function(a) {
                                        b.fire("volumechange", a)
                                    });
                                    b.player.on("error", function(a) {
                                        b.fire("error", a)
                                    })
                                }
                                "local" === b.type && (b.$video || (b.$video = document.createElement("video"),
                                b.options.showContols && (b.$video.controls = !0),
                                b.options.mute ? b.$video.muted = !0 : b.$video.volume && (b.$video.volume = b.options.volume / 100),
                                b.options.loop && (b.$video.loop = !0),
                                b.$video.setAttribute("playsinline", ""),
                                b.$video.setAttribute("webkit-playsinline", ""),
                                b.$video.setAttribute("id", b.playerID),
                                c.appendChild(b.$video),
                                document.body.appendChild(c),
                                Object.keys(b.videoID).forEach(function(a) {
                                    var c, d, e;
                                    c = b.$video;
                                    d = b.videoID[a];
                                    a = "video/".concat(a);
                                    (e = document.createElement("source")).src = d;
                                    e.type = a;
                                    c.appendChild(e)
                                })),
                                b.player = b.player || b.$video,
                                b.player.addEventListener("playing", function(a) {
                                    d || b.fire("started", a);
                                    d = 1
                                }),
                                b.player.addEventListener("timeupdate", function(a) {
                                    b.fire("timeupdate", a);
                                    b.options.endTime && b.options.endTime && this.currentTime >= b.options.endTime && (b.options.loop ? b.play(b.options.startTime) : b.pause())
                                }),
                                b.player.addEventListener("play", function(a) {
                                    b.fire("play", a)
                                }),
                                b.player.addEventListener("pause", function(a) {
                                    b.fire("pause", a)
                                }),
                                b.player.addEventListener("ended", function(a) {
                                    b.fire("ended", a)
                                }),
                                b.player.addEventListener("loadedmetadata", function() {
                                    b.videoWidth = this.videoWidth || 1280;
                                    b.videoHeight = this.videoHeight || 720;
                                    b.fire("ready");
                                    b.options.autoplay && b.play(b.options.startTime)
                                }),
                                b.player.addEventListener("volumechange", function(a) {
                                    b.getVolume(function(a) {
                                        b.options.volume = a
                                    });
                                    b.fire("volumechange", a)
                                }),
                                b.player.addEventListener("error", function(a) {
                                    b.fire("error", a)
                                }));
                                a(b.$video)
                            })
                        }
                    }, {
                        key: "init",
                        value: function() {
                            this.playerID = "VideoWorker-".concat(this.ID)
                        }
                    }, {
                        key: "loadAPI",
                        value: function() {
                            if (!x || !y) {
                                var a = "";
                                if ("youtube" !== this.type || x || (x = 1,
                                a = "https://www.youtube.com/iframe_api"),
                                "vimeo" === this.type && !y) {
                                    if (y = 1,
                                    void 0 !== k.a.Vimeo)
                                        return;
                                    a = "https://player.vimeo.com/api/player.js"
                                }
                                if (a) {
                                    var b = document.createElement("script")
                                      , c = document.getElementsByTagName("head")[0];
                                    b.src = a;
                                    c.appendChild(b)
                                }
                            }
                        }
                    }, {
                        key: "onAPIready",
                        value: function(a) {
                            if ("youtube" === this.type && (void 0 !== k.a.YT && 0 !== k.a.YT.loaded || t ? "object" === d(k.a.YT) && 1 === k.a.YT.loaded ? a() : l.done(function() {
                                a()
                            }) : (t = 1,
                            window.onYouTubeIframeAPIReady = function() {
                                window.onYouTubeIframeAPIReady = null;
                                l.resolve("done");
                                a()
                            }
                            )),
                            "vimeo" === this.type)
                                if (void 0 !== k.a.Vimeo || v)
                                    void 0 !== k.a.Vimeo ? a() : h.done(function() {
                                        a()
                                    });
                                else {
                                    v = 1;
                                    var b = setInterval(function() {
                                        void 0 !== k.a.Vimeo && (clearInterval(b),
                                        h.resolve("done"),
                                        a())
                                    }, 20)
                                }
                            "local" === this.type && a()
                        }
                    }],
                    e(a.prototype, b),
                    a
                }()
            }
            , function(a, b, c) {
                function d() {
                    var a = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : g.a.jarallax;
                    if (void 0 !== a) {
                        var a = a.constructor
                          , b = a.prototype.onScroll;
                        a.prototype.onScroll = function() {
                            var a = this;
                            b.apply(a);
                            a.isVideoInserted || !a.video || a.options.videoLazyLoading && !a.isElementInViewport || a.options.disableVideo() || (a.isVideoInserted = !0,
                            a.video.getVideo(function(b) {
                                var c = b.parentNode;
                                a.css(b, {
                                    position: a.image.position,
                                    top: "0px",
                                    left: "0px",
                                    right: "0px",
                                    bottom: "0px",
                                    width: "100%",
                                    height: "100%",
                                    maxWidth: "none",
                                    maxHeight: "none",
                                    pointerEvents: "none",
                                    transformStyle: "preserve-3d",
                                    backfaceVisibility: "hidden",
                                    willChange: "transform,opacity",
                                    margin: 0,
                                    zIndex: -1
                                });
                                a.$video = b;
                                "local" === a.video.type && (a.image.src ? a.$video.setAttribute("poster", a.image.src) : a.image.$item && "IMG" === a.image.$item.tagName && a.image.$item.src && a.$video.setAttribute("poster", a.image.$item.src));
                                a.image.$container.appendChild(b);
                                c.parentNode.removeChild(c)
                            }))
                        }
                        ;
                        var c = a.prototype.coverImage;
                        a.prototype.coverImage = function() {
                            var a = c.apply(this)
                              , b = !!this.image.$item && this.image.$item.nodeName;
                            if (a && this.video && b && ("IFRAME" === b || "VIDEO" === b)) {
                                var d = a.image.height
                                  , e = d * this.image.width / this.image.height
                                  , g = (a.container.width - e) / 2
                                  , k = a.image.marginTop;
                                a.container.width > e && (d = (e = a.container.width) * this.image.height / this.image.width,
                                g = 0,
                                k += (a.image.height - d) / 2);
                                "IFRAME" === b && (d += 400,
                                k -= 200);
                                this.css(this.$video, {
                                    width: "".concat(e, "px"),
                                    marginLeft: "".concat(g, "px"),
                                    height: "".concat(d, "px"),
                                    marginTop: "".concat(k, "px")
                                })
                            }
                            return a
                        }
                        ;
                        var d = a.prototype.initImg;
                        a.prototype.initImg = function() {
                            var a = d.apply(this);
                            return this.options.videoSrc || (this.options.videoSrc = this.$item.getAttribute("data-jarallax-video") || null),
                            this.options.videoSrc ? (this.defaultInitImgResult = a,
                            !0) : a
                        }
                        ;
                        var t = a.prototype.canInitParallax;
                        a.prototype.canInitParallax = function() {
                            function a() {
                                b.image.$default_item && (b.image.$item = b.image.$default_item,
                                b.image.$item.style.display = "block",
                                b.coverImage(),
                                b.clipContainer(),
                                b.onScroll())
                            }
                            var b = this
                              , c = t.apply(b);
                            if (!b.options.videoSrc)
                                return c;
                            var d = new e["default"](b.options.videoSrc,{
                                autoplay: !0,
                                loop: b.options.videoLoop,
                                showContols: !1,
                                startTime: b.options.videoStartTime || 0,
                                endTime: b.options.videoEndTime || 0,
                                mute: b.options.videoVolume ? 0 : 1,
                                volume: b.options.videoVolume || 0
                            });
                            if (d.isValid())
                                if (this.options.disableParallax() && (c = !0,
                                b.image.position = "absolute",
                                b.options.type = "scroll",
                                b.options.speed = 1),
                                c) {
                                    if (d.on("ready", function() {
                                        if (b.options.videoPlayOnlyVisible) {
                                            var a = b.onScroll;
                                            b.onScroll = function() {
                                                a.apply(b);
                                                b.videoError || !b.options.videoLoop && (b.options.videoLoop || b.videoEnded) || (b.isVisible() ? d.play() : d.pause())
                                            }
                                        } else
                                            d.play()
                                    }),
                                    d.on("started", function() {
                                        b.image.$default_item = b.image.$item;
                                        b.image.$item = b.$video;
                                        b.image.width = b.video.videoWidth || 1280;
                                        b.image.height = b.video.videoHeight || 720;
                                        b.coverImage();
                                        b.clipContainer();
                                        b.onScroll();
                                        b.image.$default_item && (b.image.$default_item.style.opacity = "0",
                                        setTimeout(function() {
                                            b.image.$default_item.style.display = "none";
                                            b.css(b.$video, {
                                                opacity: 1
                                            })
                                        }, 1E3))
                                    }),
                                    d.on("ended", function() {
                                        b.videoEnded = !0;
                                        b.options.videoLoop || a()
                                    }),
                                    d.on("error", function() {
                                        b.videoError = !0;
                                        a()
                                    }),
                                    b.video = d,
                                    !b.defaultInitImgResult && (b.image.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
                                    "local" !== d.type))
                                        return d.getImageURL(function(a) {
                                            b.image.bgImage = 'url("'.concat(a, '")');
                                            b.init()
                                        }),
                                        !1
                                } else
                                    b.defaultInitImgResult || d.getImageURL(function(a) {
                                        var c = b.$item.getAttribute("style");
                                        c && b.$item.setAttribute("data-jarallax-original-styles", c);
                                        b.css(b.$item, {
                                            "background-image": 'url("'.concat(a, '")'),
                                            "background-position": "center",
                                            "background-size": "cover"
                                        })
                                    });
                            return c
                        }
                        ;
                        var v = a.prototype.destroy;
                        a.prototype.destroy = function() {
                            this.image.$default_item && (this.image.$item = this.image.$default_item,
                            delete this.image.$default_item);
                            v.apply(this)
                        }
                    }
                }
                c.r(b);
                c.d(b, "default", function() {
                    return d
                });
                var e = c(8);
                a = c(3);
                var g = c.n(a)
            }
            ]);
            var Cover = function() {
                function a(a) {
                    if (a) {
                        if ("transparent" === a.toLowerCase())
                            return [0, 0, 0, 0];
                        if ("#" === a[0])
                            return 7 > a.length && (a = "#" + a[1] + a[1] + a[2] + a[2] + a[3] + a[3] + (4 < a.length ? a[4] + a[4] : "")),
                            [parseInt(a.substr(1, 2), 16), parseInt(a.substr(3, 2), 16), parseInt(a.substr(5, 2), 16), 7 < a.length ? parseInt(a.substr(7, 2), 16) / 255 : 1];
                        if (-1 === a.indexOf("rgb")) {
                            var b = document.body.appendChild(document.createElement("fictum"));
                            b.style.color = "rgb(1, 2, 3)";
                            if ("rgb(1, 2, 3)" !== b.style.color)
                                return;
                            b.style.color = a;
                            if ("rgb(1, 2, 3)" === b.style.color || "" === b.style.color)
                                return;
                            a = getComputedStyle(b).color;
                            document.body.removeChild(b)
                        }
                        if (0 === a.indexOf("rgb"))
                            return -1 === a.indexOf("rgba") && (a += ",1"),
                            a.match(/[\.\d]+/g).map(function(a) {
                                return +a
                            })
                    }
                }
                function b(b) {
                    b = a(b);
                    return !!(200 < Math.sqrt(.299 * b[0] * b[0] + .587 * b[1] * b[1] + .114 * b[2] * b[2]))
                }
                function c(a) {
                    var c;
                    ("undefined" !== typeof a ? [a] : ".header .cover__menu;.header .cover-title;.header .header__item:last-child;.cover__title h1;.cover__subtitle h2;.cover__button;.cover__body .cover__phone;.cover__body .cover__social;.cover__footer .forward".split(";")).forEach(function(a) {
                        a = document.querySelectorAll(a);
                        [].forEach.call(a, function(a) {
                            c = "BUTTON" !== a.nodeName ? getComputedStyle(a).color : getComputedStyle(a).backgroundColor;
                            b(c) ? a.classList.add("shadow") : a.classList.remove("shadow")
                        })
                    })
                }
                function d(a, b, c) {
                    c ? a.classList.contains(b) || a.classList.add(b) : a.classList.remove(b)
                }
                function e() {
                    r.header.el.className = r.header.el.className.replace(RegExp("\\b(header--[\\w\\-]+)", "g"), "");
                    y()
                }
                function g(a) {
                    var b = window.getComputedStyle(r[a].el);
                    return r[a].el.offsetWidth + parseInt(b.marginLeft) + parseInt(b.marginRight)
                }
                function k() {
                    return D.className.match("cover-layout--([\\w]+)")[1].toUpperCase()
                }
                function q(a) {
                    var b = 0;
                    if (null === a)
                        return b;
                    if (a = a.querySelector(".content")) {
                        var c = a.cloneNode(!0);
                        c.classList.add("clone");
                        c.setAttribute("style", "display: inline-block !important");
                        a.parentNode.insertBefore(c, a.nextSibling);
                        style = getComputedStyle(c);
                        b = c.offsetWidth + parseInt(style.marginLeft) + parseInt(style.marginRight);
                        c.parentNode.removeChild(c)
                    }
                    return b
                }
                function x(a) {
                    var b = 0
                      , c = a.querySelector(".content");
                    c && (a = c.cloneNode(!0),
                    a.classList.add("clone"),
                    a.setAttribute("style", "display: block !important;"),
                    c.parentNode.insertBefore(a, c.nextSibling),
                    b = a.offsetHeight,
                    a.setAttribute("style", "display: block !important;position: absolute !important;width: 10000px"),
                    b = Math.round(b / a.offsetHeight),
                    a.parentNode.removeChild(a));
                    return b
                }
                function y() {
                    var a = window.getComputedStyle(r.header.el);
                    r.header.width = r.header.el.offsetWidth - parseInt(a.paddingLeft) - parseInt(a.paddingRight);
                    var b = k()
                      , c = D.className.match("cover-align--([\\w]+)")[1].toUpperCase()
                      , e = !("MENU" != b || "CENTER" != c);
                    d(z, "header--hide-icon-text", e);
                    var f = document.querySelector(".header__item:nth-child(2)")
                      , h = document.querySelector(".header__item:nth-child(3)")
                      , m = !D.classList.contains("cover-logo--hide")
                      , l = m ? document.querySelector(".header .cover__logo") : document.querySelector(".header .cover__title")
                      , n = q(l)
                      , a = window.getComputedStyle(z)
                      , p = z.offsetWidth - parseInt(a.paddingLeft) - parseInt(a.paddingRight)
                      , l = [".cover__phone", ".cover__directions", ".cover__hours", ".cover__cart", ".cover__social"]
                      , a = 0;
                    if ("MENU" == b && "CENTER" == c)
                        for (e = m ? (p - n) / p / 2 * 100 - .5 : Math.floor(n > .4 * p ? 30 : (p - n) / p / 2 * 100) - .5,
                        f.style.flexBasis = e + "%",
                        h.style.flexBasis = e + "%",
                        f = document.querySelector(".cover__menu"),
                        2 < x(f) ? z.classList.contains("header--hide-menu") || z.classList.add("header--hide-menu") : z.classList.remove("header--hide-menu"),
                        f = h.offsetWidth,
                        h = 0; h < l.length; h++)
                            b = l[h],
                            a += q(document.querySelector(b)),
                            e = "header--hide-" + b.replace(/(.cover__)/g, ""),
                            a < f ? z.classList.remove(e) : z.classList.contains(e) || z.classList.add(e);
                    else
                        for (f.style.flexBasis = "",
                        h.style.flexBasis = "",
                        h = 1; h < Object.keys(r).length; h++) {
                            a: {
                                l = void 0;
                                for (l in r)
                                    if (r[l].priority == h) {
                                        b = l;
                                        break a
                                    }
                                b = !1
                            }
                            if (l = r[b].el)
                                c = q(l),
                                f = document.querySelector(".cover__menu"),
                                m = x(f),
                                f = r.header.width,
                                a += c,
                                1 < m && !r.header.el.classList.contains("header--hide-icon-text") && r.header.el.classList.add("header--hide-icon-text"),
                                a > f ? "phone" == b || "directions" == b || "hours" == b ? (z.classList.add("header--hide-icon-text"),
                                e = !0,
                                r.phone.width && (a -= r.phone.width,
                                a += g("phone")),
                                r.directions.width && (a -= r.directions.width,
                                a += g("directions")),
                                r.hours.width && (a -= r.hours.width,
                                a += g("hours"))) : z.classList.contains("header--hide-icon-text") ? "menu" !== b ? (d(r.header.el, "header--hide-" + b, a > r.header.width),
                                a -= q(l)) : (d(r.header.el, "header--hide-" + b, 2 < m),
                                2 < m && (a -= q(l))) : (z.classList.add("header--hide-icon-text"),
                                e = !0) : "hours" != b || e ? "menu" == b ? d(r.header.el, "header--hide-" + b, 2 < m) : r.header.el.classList.remove("header--hide-" + b) : r.header.el.classList.remove("header--hide-icon-text")
                        }
                    z.classList.add("header--show");
                    a = !!window.MSInputMethodContext && !!document.documentMode;
                    document.querySelector(".cover") && a && /cover-layout--full|cover-layout\u2014left|cover-layout\u2014right/.test(D.className) && (e = document.querySelector(".cover__container"),
                    a = document.querySelector(".cover__content"),
                    l = document.querySelector(".cover__header"),
                    h = document.querySelector(".cover__footer"),
                    e.offsetHeight && (e = Math.round((e.offsetHeight - l.offsetHeight - h.offsetHeight) / e.offsetHeight * 100) + "vh",
                    a.style.msGridRows = "minmax(" + e + ", 1fr)"))
                }
                function t(a) {
                    document.querySelector(".cover");
                    if (!(-1 < D.className.indexOf("cover-logo--hide"))) {
                        if ("undefined" === typeof a)
                            if (-1 < D.className.indexOf("cover-layout--menu"))
                                a = document.querySelector(".cover__header .logo img");
                            else
                                return;
                        var b = a.naturalWidth
                          , c = a.naturalHeight;
                        -1 < D.className.indexOf("cover-logo--circle") ? (a.parentNode.style.width = 50 > c && 200 > b ? "62px" : 75 <= c || 75 > c && 200 < b ? "87px" : c + 12 + "px",
                        a.parentNode.style.height = a.parentNode.style.width,
                        a.style.minHeight = "0") : (a.style.minHeight = 50 > c && 200 > b ? "62px" : "0",
                        a.parentNode.style.width = "auto",
                        a.parentNode.style.height = "auto")
                    }
                }
                function v() {
                    document.querySelector(".cover");
                    var a = -1 < D.className.indexOf("cover-layout--menu") ? document.querySelector(".cover__header .logo img") : -1 < D.className.indexOf("cover-layout--half") ? document.querySelector(".cover__body .logo img") : null;
                    a && a.addEventListener("load", function() {
                        t(this)
                    })
                }
                function l(a) {
                    var b = !1;
                    a.split(" ").reverse().forEach(function(a, c) {
                        1 >= c && a.includes("</a>") && (b = !0)
                    });
                    return b
                }
                function h(a) {
                    a = a.replace(/\s\s+/g, " ");
                    l(a) || (a = a.replace(/(\w+\s[^\s]+)$/, "<span>$1</span>"));
                    for (var b = a.length, c = /(\s|^)(([a-zA-Z-_(]{1,2}('|\u2019)*[a-zA-Z-_,;]{0,1}?\s)+)/gi; 0 < b--; )
                        a = a.replace(c, function(a, b, c) {
                            return b + c.replace(/\s/g, "&#160;")
                        });
                    return a
                }
                function C(a) {
                    a.innerHTML = h(a.innerHTML);
                    a.classList.toggle("cover-title--long", 60 < a.innerHTML.length)
                }
                function m() {
                    return G > 480 + (F ? F.offsetLeft : 0) ? "desktop" : "mobile"
                }
                function w(a) {
                    var b = new Image
                      , c = document.body.classList.contains("sw-activated") ? 0 : 600;
                    b.onload = function() {
                        document.body.classList.remove("loading");
                        setTimeout(function() {
                            p.removeChild(p.querySelector(".mobileThumbnail"));
                            p.removeChild(p.querySelector(".desktopThumbnail"));
                            p.style.backgroundImage = "";
                            u()
                        }, c)
                    }
                    ;
                    b.src = a
                }
                function n() {
                    var a = document.querySelectorAll(".tile")
                      , a = a ? a[0].classList.contains("tile-cover") : !0;
                    "FULL" == k() && a ? (f(p.querySelector("." + m() + "Picture")),
                    f(p.querySelector("." + m() + "Thumbnail"))) : (p.querySelector("." + m() + "Picture").style.backgroundSize = "",
                    p.querySelector("." + m() + "Picture").style.backgroundPosition = "")
                }
                function f(a) {
                    if (a) {
                        var b = !!H.classList.contains("empty");
                        b ? (a.style.backgroundSize = "auto",
                        a.style.backgroundRepeat = "repeat",
                        a.style.visibility = "visible") : (a.style.backgroundSize = "",
                        a.style.backgroundRepeat = "");
                        if ("mobile" == m() && 0 < K.w && !b)
                            B(a, K);
                        else if ("desktop" == m() && 0 < J.w && !b)
                            B(a, J);
                        else {
                            var c = new Image;
                            c.onload = function() {
                                var d;
                                d = "naturalHeight"in c ? {
                                    w: c.naturalWidth,
                                    h: c.naturalHeight
                                } : {
                                    w: c.width,
                                    h: c.height
                                };
                                "mobile" == m() ? K = d : J = d;
                                b || B(a, d)
                            }
                            ;
                            if (a) {
                                var d = A(a);
                                "none" !== d && (c.src = d)
                            }
                        }
                    }
                }
                function u() {
                    J = {
                        w: 0,
                        h: 0
                    };
                    K = {
                        w: 0,
                        h: 0
                    }
                }
                function B(a, b) {
                    if ("FULL" !== k())
                        a.style.backgroundSize = "",
                        a.style.backgroundPosition = "";
                    else {
                        var c = a.offsetWidth
                          , d = a.offsetHeight
                          , e = b.w / b.h
                          , f = 0
                          , g = 0
                          , h = 0
                          , l = 0;
                        e < c / d ? (h = c,
                        l = c / e,
                        g = F ? F.offsetLeft : 0,
                        f = (d - c / e) / 2) : (h = d * e,
                        l = d,
                        g = (F ? F.offsetLeft : 0) + (c - d * e) / 2,
                        f = 0);
                        a.style.backgroundSize = h + "px " + l + "px";
                        a.style.backgroundPosition = g + "px " + f + "px";
                        a.style.visibility = "visible"
                    }
                }
                function A(a) {
                    try {
                        var b = getComputedStyle(a).backgroundImage;
                        return b ? b.match(/url[\("']+(.*?)["'\)]+$/)[1] : "none"
                    } catch (c) {
                        return console.error(c),
                        "none"
                    }
                }
                function E() {
                    var a = document.documentElement.clientWidth;
                    a !== G && (M(),
                    G = a);
                    "FULL" == k() ? H.style.height = I + "px" : H.style.height = "";
                    Q.style.height = I + "px"
                }
                function M() {
                    document.documentElement.style.setProperty("--vh", .01 * window.innerHeight + "px")
                }
                function P() {
                    window.addEventListener("resize", function() {
                        var a = document.documentElement.clientWidth
                          , b = document.documentElement.clientHeight;
                        if ("undefined" == typeof window.orientation || a != G)
                            G = a,
                            I = b,
                            I >= 1.8 * G && (I = 768),
                            E(),
                            window.sseditmode && n(),
                            y()
                    })
                }
                var D = document.querySelector(".tiles")
                  , H = document.querySelector(".cover__background")
                  , p = document.querySelector(".cover__image")
                  , F = document.querySelector(".overlay-main")
                  , z = document.querySelector(".header")
                  , N = "MENU" == k() ? document.querySelector(".cover__header .cover-title") : document.querySelector(".cover__body .cover-title")
                  , O = document.querySelector(".cover__body .cover__subtitle")
                  , L = document.querySelector(".cover__body .cover__subtitle .cover-text")
                  , Q = document.querySelector(".parallax-container")
                  , r = {
                    header: {
                        el: document.querySelector(".cover__header"),
                        priority: 0
                    },
                    logo: {
                        el: document.querySelector(".cover__logo"),
                        priority: 1
                    },
                    title: {
                        el: document.querySelector(".cover__title"),
                        priority: 2
                    },
                    menu: {
                        el: document.querySelector(".cover__menu"),
                        priority: 8
                    },
                    phone: {
                        el: document.querySelector(".cover__phone"),
                        priority: 4
                    },
                    directions: {
                        el: document.querySelector(".cover__directions"),
                        priority: 5
                    },
                    hours: {
                        el: document.querySelector(".cover__hours"),
                        priority: 6
                    },
                    social: {
                        el: document.querySelector(".cover__social"),
                        priority: 7
                    },
                    cart: {
                        el: document.querySelector(".cover__cart"),
                        priority: 3
                    }
                }
                  , G = document.documentElement.clientWidth
                  , I = document.documentElement.clientHeight
                  , J = {
                    w: 0,
                    h: 0
                }
                  , K = {
                    w: 0,
                    h: 0
                };
                this.init = function() {
                    P();
                    if (0 > navigator.userAgent.indexOf("Page Speed") && (window.sseditmode ? f(p.querySelector("." + m() + "Thumbnail")) : null !== p && (p.style.backgroundImage = p.querySelector("." + m() + "Thumbnail").style.backgroundImage),
                    E(),
                    H.getAttribute("data-video-src") && jarallax(H),
                    null !== p)) {
                        var a = p.querySelector("." + m() + "Picture");
                        a && (a = A(a),
                        "none" !== a && w(a))
                    }
                    N && C(N);
                    L && (O.classList.toggle("cover-title--long", 60 < O.innerHTML.length),
                    L.innerHTML = h(L.innerHTML));
                    e();
                    v();
                    c();
                    M();
                    E();
                    window.sseditmode && n();
                    y()
                }
                ;
                this.getColor = a;
                this.setShadow = c;
                this.isColorLight = b;
                this.initHeader = e;
                this.updateHeader = y;
                this.updateLogo = t;
                this.getDevice = m;
                this.render = E;
                this.fitBackground = n;
                this.setBGImageSize = B;
                this.clearCacheBGImageSize = u;
                this.formatTypo = h;
                this.formatElement = C
            };
            if (document.querySelector(".cover")) {
                var cover = new Cover;
                cover.init()
            }
            ;</script>
        <script>
            if (window.performance && window.performance.mark) {
                window.performance.mark('instantSiteStaticHomePageLoaded');
            }
        </script>
        <script data-cfasync="false">
            var abTestNewFeatures = ""
            var ecwidDomain = "company.site";
            var channelId = "ecwid_e48c";
            var ecwid_no_body_height = true;
            var ecwidStoreURL = "https://app.ecwid.com"
              , ecwidStoreID = "83623760"
              , ecwidStoreParams = "data_platform=startersite_v2"
              , ecwidStoreName = "NK-Store Online"
              , ecwidStoreSettings = {
                categoriesPerRow: 3,
                gridViewRows: 20,
                gridViewCols: 3,
                listViewRows: 60,
                tableViewRows: 60,
                customMaxProductsPerPage: ""
            };

            var navigationEnabled = true;

            window.Ecwid = window.Ecwid || {};
            window.Ecwid.restoreCartData = undefined;

            window.ec = window.ec || {};
            window.ec.config = window.ec.config || {};
            window.ec.config.enable_canonical_urls = true;
            window.ec.config.interactive = true;
            window.ec.config.facebookWebView = false;
            window.ec.config.scroll_indent = 32;
            window.ec.storefront = window.ec.storefront || {};
            window.ec.storefront.sharing_button_link = "DIRECT_PAGE_URL";
            window.ec.storefront.enable_navigation = navigationEnabled;

            window.ec.config.canonical_base_url = "https://nakhin.company.site/";

            window.ec.config.chameleon = window.ec.config.chameleon || {};
            window.ec.config.chameleon.colors = window.ec.config.chameleon.colors || {
                "color-foreground": "#191919",
                "color-background": "#fff",
                "color-link": "#1a7ac4",
                "color-button": "#333",
                "color-price": "#191919"
            };

            window.ec.config.storefrontUrls = window.ec.config.storefrontUrls || {};
            window.ec.config.storefrontUrls.cleanUrls = true;

            document.body.classList.add((!!('ontouchstart'in window)) ? 'touchable' : 'no-touch');

            function animateScroll(tile) {
                if (typeof $ == 'undefined') {
                    document.querySelector(tile).scrollIntoView({
                        behavior: 'smooth'
                    });
                } else {
                    $('html, body').animate({
                        'scrollTop': $(tile).offset().top
                    }, 300);
                }
            }

            function scrollToTile(tile, isReloaded) {
                var isReloaded = isReloaded || false;
                animateScroll(tile);
                if (isReloaded) {
                    window.ec.config.navigation_scrolling = 'CUSTOM';
                    window.ec.config.custom_scroller = function() {
                        delete window.ec.config.navigation_scrolling;
                        delete window.ec.config.custom_scroller;
                    }
                }
            }

            function getQueryParams(qs) {
                qs = qs.split('+').join(' ');
                var params = {}, tokens, re = /[?&]?([^=]+)=([^&]*)/g;

                while (tokens = re.exec(qs)) {
                    params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
                }
                return params;
            }

            // get query params
            var query = getQueryParams(document.location.search);

            // hide header
            if (query.hide_header == 'true') {
                document.body.classList.add('hide-header');
            }

            /* get hash params */
            function getParams(h) {
                var r = {};
                if (h) {
                    h = decodeURIComponent(h.replace(/\?|\#/g, "")).split(/\&/);
                    h.forEach(function(c, i) {
                        c = c.split("=");
                        var key = c[0].toLowerCase();
                        var value = c[1];
                        if (/^(null|false|true|[0-9]+)$/.test(value)) {
                            value = JSON.parse(value);
                        }
                        if (key.match(/\[\]/g)) {
                            key = key.replace(/\[\]/g, "");
                            if (!r[key]) {
                                r[key] = [];
                            }
                            r[key].push(value);
                        } else {
                            r[key] = value;
                        }
                    });
                }
                return r;
            }
            ;
            var params = getParams(document.location.hash);
            if (params.mode == 'preview' && window.innerWidth < 768) {
                document.body.classList.add('preview-mode');
            }
        </script>
        <script data-cfasync="false" src="https://d34ikvsdm2rlij.cloudfront.net/startersite/static/2023/2023-8756-gd2473c8129b35d/js/store.bundle.js" defer></script>
        <script>
            window.ec.storefront.staticPages.switchToDynamicCallback = function() {
                var scrollElement = document.getElementById("featured-products-anchor") || document.getElementById("ecwid_product_browser_scroller") || document.querySelectorAll(".ecwid-productBrowser-TermsAndConditionsPage")[0];
                if (scrollElement) {
                    scrollElement.scrollIntoView();
                }
                window.ec.config.navigation_scrolling = null;
            }
            ;
        </script>
        <script>
            if ('serviceWorker'in navigator) {
                var isOffline = false;
                function XMLHttpRequestConnection(no, yes) {
                    if (window.XMLHttpRequest) {
                        var xhr = new XMLHttpRequest();
                        xhr.onload = function() {
                            if (yes instanceof Function) {
                                yes();
                            }
                        }
                        ;
                        xhr.onerror = function() {
                            if (no instanceof Function) {
                                no();
                            }
                        }
                        ;
                        xhr.open("GET", "sitemap.xml", true);
                        xhr.send();
                    }
                }
                window.addEventListener('load', function() {
                    navigator.serviceWorker.register('/service-worker.js');
                    var offLine = function() {
                        // Before going offline we check if we appeared online to be on the safe side
                        if (navigator.onLine) {
                            return;
                        }

                        if (!document.body.classList.contains('offline')) {
                            isOffline = true;
                            addOfflineBlock();
                            document.body.classList.add('offline');
                        }
                    }
                    var onLine = function() {
                        document.body.classList.remove('offline');
                        if (isOffline && typeof Ecwid !== 'undefined') {
                            var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
                            var isEdge = /Edge/.test(navigator.userAgent);
                            if (isSafari || isEdge)
                                location.reload();
                            var menu = document.querySelector('.menu .container');
                            if (menu)
                                menu.innerHTML = '';
                            var pushmenu = document.querySelector('.pushmenu .container');
                            if (pushmenu)
                                pushmenu.innerHTML = '';
                            insertStore();
                            var timer = setInterval(function() {
                                var placeholder = document.getElementById('ecwidStorefrontPlaceholder');
                                if (placeholder)
                                    placeholder.parentNode.removeChild(placeholder);
                            }, 200);
                            setTimeout(function() {
                                clearInterval(timer);
                            }, 2000);
                            if (typeof (Event) === 'function') {
                                window.dispatchEvent(new Event('resize'));
                            } else {
                                var evt = window.document.createEvent('UIEvents');
                                evt.initUIEvent('resize', true, false, window, 0);
                                window.dispatchEvent(evt);
                            }
                            isOffline = false;
                        }

                    }
                    function handleNetworkChange(event) {
                        if (!!navigator.userAgent.match(/Trident\/7\./)) {
                            // for IE 11
                            XMLHttpRequestConnection(offLine, onLine);
                        } else {
                            if (navigator.onLine) {
                                onLine();
                            } else {
                                // If offline status is caught, we wait for 5 seconds before going offline
                                setTimeout(function() {
                                    offLine();
                                }, 5000)
                            }
                        }
                    }
                    function addOfflineBlock() {
                        if (document.querySelector('.block-offline') == null) {
                            var div = document.createElement('div');
                            div.className = 'block-offline';
                            div.innerHTML = '<div class="block-offline__panel"><div class="block-offline__panel-title">You are offline</div><div class="block-offline__panel-text">Connect to the Internet to browse and shop our products.</div></div>';
                            var bodyDiv = document.querySelector('.body');
                            var parentDiv = bodyDiv.parentNode;
                            parentDiv.insertBefore(div, bodyDiv);
                        }
                    }
                    window.addEventListener("online", handleNetworkChange);
                    window.addEventListener("offline", handleNetworkChange);
                    handleNetworkChange();
                });
            }
        </script>
    </body>
</html>

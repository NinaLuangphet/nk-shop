<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>
<body>
<?php  
$user ="nakhin";
$arr = array("Home","Member","About","Contact");
?>

  
    
    <?php if($user == "nakhin"): ?>
    <h1 style="font-family: saysettha OT;">>ຍີນດີຕ້ອນຮັບແອັດມີນ <?php echo e($user); ?></h1>
<?php else: ?>
<h1 style="font-family: saysettha OT;">>ຜູ້ໃຊ້ຄົນນີ້ບໍ່ໄດ້ເປັນແອັດມີນ</h1>
<?php endif; ?>



<ul>
<?php for($i=1;$i<=5;$i++): ?>
<li><p><?php echo e($i); ?></p></li>
<?php endfor; ?>
</ul>


<?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href=""><?php echo e($menu); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\laravel9crud\resources\views/addmin/addmin.blade.php ENDPATH**/ ?>